#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

import numpy as np
import pandas as pd
import math
from scipy.optimize import fsolve

############################ utils for first-Order algorithm for solving equilbrium in Bertrand-Nash Equilibrium ############################
def projection(p1, p2, pmax):

     p1_clip = np.clip(p1, 0, pmax)
     p2_clip = np.clip(p2, 0, pmax)

     return p1_clip, p2_clip

def firstOrderEq_givenXi_linearDemand(xi_hat, theta_1, theta_2, pmax):
    # Initial guess for p1 and p2#
    initial_guess = [1, 1]
    def equations(prices):
        p1, p2 = prices
        f1 = 2 * theta_1[0] * p1 + theta_1[1] * p2 + theta_1[2] * xi_hat + theta_1[3]
        f2 = theta_2[0] * p1 + 2 * theta_2[1] * p2 + theta_2[2] * xi_hat + theta_2[3]

        return [f1, f2]

    # Solve the system of equations
    solution = fsolve(equations, initial_guess)
    p1, p2 = solution

    p1_new, p2_new = projection(p1, p2, pmax)

    return np.array([p1_new, p2_new])

def FirstOrder_Equilibrium_LinearDemand(N, xi_mean, xi_std, theta_1, theta_2, pmax):
    # Demand function: D_{i}\left(p_1, p_2, \xi ; \bm\theta_{i}\right) = \theta_{i1}p_{1} + \theta_{i2}p_{2} + \theta_{i3}\xi +\theta_{i4};
    dataset = []
    for i in range(N):
        xi = np.random.normal(xi_mean, xi_std)  # context feature xi
        # Initial guess for p1 and p2
        equilibrium = firstOrderEq_givenXi_linearDemand(xi, theta_1, theta_2, pmax)

        # Output the results
        print("xi: {} ".format(xi))
        print("Equilibrium prices:", equilibrium)
        dataset.append(list(equilibrium) + [xi])

    dataset_np = np.array(dataset)
    assert dataset_np.shape[1] == 3

    return dataset_np

def firstOrderEq_givenXi_NonlinearDemand(xi_hat, theta_1, theta_2, pmax):
    # Initial guess for p1 and p2
    initial_guess = [1, 1]
    def equations(prices):
        p1, p2 = prices
        f1 = 2 * theta_1[0] * p1 + theta_1[1] * p2 + theta_1[2] * xi_hat + theta_1[3] * (math.log(p1) + 2)
        f2 = theta_2[0] * p1 + 2 * theta_2[1] * p2 + theta_2[2] * xi_hat + theta_2[3] * (math.log(p2) + 2)

        return [f1, f2]

    # Solve the system of equations
    solution = fsolve(equations, initial_guess)
    p1, p2 = solution

    p1_new, p2_new = projection(p1, p2, pmax)

    return np.array([p1_new, p2_new])

def FirstOrder_Equilibrium_NonlinearDemand(N, xi_mean, xi_std, theta_1, theta_2, pmax):
    # nonlinear demand: D_{i}\left(p_1, p_2, \xi ; \bm\theta_{i}\right) = \theta_{i1}p_{1} + \theta_{i2}p_{2} + \theta_{i3}\xi + \theta_{i4}\left(1+\log\left(p_{i}\right)\right).
    dataset = []
    for i in range(N):
        xi = np.random.normal(xi_mean, xi_std)  # context feature xi
        # xi = 7.103118816110717 #p1: 0.28084204566429966 p2: 0.28247229724063677
        # xi = 4.47280490841968: For nonlinear, it is the same as VI-Nonlinear computation!
        # xi = 5.747857565009743
        # xi = 7.571791866569243
        # xi = 2.8830277360265706 Equilibrium prices: p1: 2.087649320444393; p2: 2.2546612660799443
        # Initial guess for p1 and p2
        equilibrium = firstOrderEq_givenXi_NonlinearDemand(xi, theta_1, theta_2, pmax)
        print("xi: {} ".format(xi))
        print("Equilibrium prices:", equilibrium)
        dataset.append(list(equilibrium) + [xi])

    # Projection algorithm# xi is 2.8830277360265706# Equilibrium prices (p1, p2): (2.0876493548504795, 2.2546613098346007)
    # First-Order algorithm:# xi = 2.8830277360265706 Equilibrium prices: p1: 2.087649320444393; p2: 2.2546612660799443
    dataset_np = np.array(dataset)
    return dataset_np


def firstOrderEq_givenXi_NonlinearDemand_2(xi_hat, theta_1, theta_2, pmax):
    # Initial guess for p1 and p2
    initial_guess = [pmax/2, pmax/2]
    def equations(prices):
        p1, p2 = prices
        f1 = 2 * theta_1[0] * p1 + theta_1[1] * p2 + theta_1[2] * xi_hat + theta_1[3] + theta_1[4] * (math.log(p1) + 1)
        f2 = theta_2[0] * p1 + 2 * theta_2[1] * p2 + theta_2[2] * xi_hat + theta_2[3] + theta_2[4] * (math.log(p2) + 1)

        return [f1, f2]

    # Solve the system of equations
    solution = fsolve(equations, initial_guess)
    p1, p2 = solution

    p1_new, p2_new = projection(p1, p2, pmax)

    return np.array([p1_new, p2_new])

def firstOrderEq_givenXi_NonlinearDemand_3(xi_hat, theta_1, theta_2, pmax):
    # Initial guess for p1 and p2
    initial_guess = [pmax/2, pmax/2]
    def equations(prices):
        p1, p2 = prices
        f1 = 2 * theta_1[0] * p1 + theta_1[1] * p2 + theta_1[2] * xi_hat + theta_1[3] * (math.log(p1) + 1)
        f2 = theta_2[0] * p1 + 2 * theta_2[1] * p2 + theta_2[2] * xi_hat + theta_2[3] * (math.log(p2) + 1)

        return [f1, f2]

    # Solve the system of equations
    solution = fsolve(equations, initial_guess)
    p1, p2 = solution

    p1_new, p2_new = projection(p1, p2, pmax)

    return np.array([p1_new, p2_new])

def FirstOrder_Equilibrium_NonlinearDemand_2(N, xi_mean, xi_std, theta_1, theta_2, pmax):
    #demand function: D_{i}\left(p_1, p_2, \xi ; \bm\theta_{i}\right) = \theta_{i1}p_{1} + \theta_{i2}p_{2} + \theta_{i3}\xi +\theta_{i4} + \theta_{i5}\log\left(p_{i}\right).
    dataset= []
    for i in range(N):
        xi = np.random.normal(xi_mean, xi_std)  # context feature xi
        equilibrium = firstOrderEq_givenXi_NonlinearDemand_2(xi, theta_1, theta_2, pmax)
        # Output the results
        print("xi: {} ".format(xi))
        print("Equilibrium prices:", equilibrium)
        dataset.append(list(equilibrium) + [xi])

    dataset_np = np.array(dataset)

    return dataset_np


def FirstOrder_Equilibrium_NonlinearDemand_3(N, xi_mean, xi_std, theta_1, theta_2, pmax):
    #demand function: D_{i}\left(p_1, p_2, \xi ; \bm\theta_{i}\right) = \theta_{i1}p_{1} + \theta_{i2}p_{2} + \theta_{i3}\xi +\theta_{i4} + \theta_{i5}\log\left(p_{i}\right).
    dataset= []
    for i in range(N):
        xi = np.random.normal(xi_mean, xi_std)  # context feature xi
        equilibrium = firstOrderEq_givenXi_NonlinearDemand_3(xi, theta_1, theta_2, pmax)
        # Output the results
        print("xi: {} ".format(xi))
        print("Equilibrium prices:", equilibrium)
        dataset.append(list(equilibrium) + [xi])

    dataset_np = np.array(dataset)

    return dataset_np

################################## utils for projection algorithm for solving equilbrium  #####################################

def ProjectAlgEq_givenXi_linearDemand(xi, theta1, theta2, pmax, max_Iter, tau, epsilon):
    # global p1, p2, xi
    prices = np.full(2, pmax / 2.0)
    p1, p2 = prices[0], prices[1]

    for iter in range(max_Iter):
        # Calculate profit gradients
        grad_p1 = 2 * theta1[0] * p1 + theta1[1] * p2 + theta1[2] * xi + theta1[3]
        grad_p2 = theta2[0] * p1 + 2 * theta2[1] * p2 + theta2[2] * xi + theta2[3]

        # Update prices using gradient descent
        p1_iter = p1 + tau * grad_p1
        p2_iter = p2 + tau * grad_p2

        p1_new, p2_new  = projection(p1_iter, p2_iter, pmax)
        # Check convergence

        if np.linalg.norm(np.array([p1_new, p2_new]) - np.array([p1, p2])) <= epsilon:
            print('find the {}-equilibrium after iteration-{} '.format(epsilon, iter))
            p1, p2 = p1_new, p2_new
            return p1, p2

        # Update prices
        p1, p2 = p1_new, p2_new

    return np.array([p1, p2])


def ProjectAlg_Equilibrium_NonLinearDemand(xi, theta1, theta2, pmax, max_Iter, tau, epsilon):
    # global p1, p2, xi
    prices = np.full(2, pmax / 2.0)
    # prices = np.full(2, pmax)
    p1, p2 = prices[0], prices[1]
    for iter in range(max_Iter):
        # print('iteration: {}'.format(iter))
        # Calculate profit gradients
        grad_p1 = 2 * theta1[0] * p1 + theta1[1] * p2 + theta1[2] * xi + theta1[3]*(math.log(p1) + 2)
        grad_p2 = theta2[0] * p1 + 2 * theta2[1] * p2 + theta2[2] * xi + theta2[3]*(math.log(p2) + 2)

        # Update prices using gradient descent
        p1_iter = p1 + tau * grad_p1
        p2_iter = p2 + tau * grad_p2
        p1_new, p2_new  = projection(p1_iter, p2_iter, pmax)

        # Check convergence
        # if np.linalg.norm(p1_new - p1) < epsilon and np.linalg.norm(p2_new - p2) < epsilon:
        if np.linalg.norm(np.array([p1_new, p2_new]) - np.array([p1, p2])) <= epsilon:
            # if iterations > 10:  # Ensure stability in stochastic scenario
            p1, p2 = p1_new, p2_new
            print('After iter {}, find the {}-approx equilibrium prices.'.format(iter, epsilon))
            print(p1, p2)
            print(np.linalg.norm(np.array([p1_new, p2_new]) - np.array([p1, p2])))
            return p1, p2

        # Update prices
        p1, p2 = p1_new, p2_new

    return p1, p2

def ProjectAlg_Equilibrium_NonLinearDemand_2(xi, theta1, theta2, pmax, max_Iter, tau, epsilon):
    # global p1, p2, xi
    prices = np.full(2, pmax / 2.0)
    p1, p2 = prices[0], prices[1]
    for iter in range(max_Iter):
        # Calculate profit gradients
        grad_p1 = 2 * theta1[0] * p1 + theta1[1] * p2 + theta1[2] * xi + theta1[3] + theta1[4] * (math.log(p1)  + 1)
        grad_p2 = theta2[0] * p1 + 2 * theta2[1] * p2 + theta2[2] * xi + theta2[3] + theta2[4] * (math.log(p2) + 1)

        # Update prices using gradient descent
        p1_iter = p1 + tau * grad_p1
        p2_iter = p2 + tau * grad_p2
        p1_new, p2_new = projection(p1_iter, p2_iter, pmax)

        # Check convergence
        if np.linalg.norm(np.array([p1_new, p2_new]) - np.array([p1, p2])) <= epsilon:
            # if iterations > 10:  # Ensure stability in stochastic scenario
            p1, p2 = p1_new, p2_new
            return p1, p2

        p1, p2 = p1_new, p2_new

    return p1, p2

def ProjectAlg_Equilibrium_NonLinearDemand_3(xi, theta1, theta2, pmax, max_Iter, tau, epsilon):
    # global p1, p2, xi
    prices = np.full(2, pmax / 2.0)
    p1, p2 = prices[0], prices[1]
    for iter in range(max_Iter):
        # Calculate profit gradients
        grad_p1 = 2 * theta1[0] * p1 + theta1[1] * p2 + theta1[2] * xi + theta1[3] * (math.log(p1)  + 1)
        grad_p2 = theta2[0] * p1 + 2 * theta2[1] * p2 + theta2[2] * xi + theta2[3] * (math.log(p2) + 1)

        # Update prices using gradient descent
        p1_iter = p1 + tau * grad_p1
        p2_iter = p2 + tau * grad_p2
        p1_new, p2_new = projection(p1_iter, p2_iter, pmax)

        # Check convergence
        if np.linalg.norm(np.array([p1_new, p2_new]) - np.array([p1, p2])) <= epsilon:
            # if iterations > 10:  # Ensure stability in stochastic scenario
            p1, p2 = p1_new, p2_new
            return p1, p2

        p1, p2 = p1_new, p2_new

    return p1, p2

