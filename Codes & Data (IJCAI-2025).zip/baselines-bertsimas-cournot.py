#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

import pandas as pd
import numpy as np
import gurobipy as gp
import os, sys
import _pickle as pickle
from gurobipy import GRB, quicksum
from scipy.optimize import fsolve
import argparse

from utils_cournot import firstOrderEq_givenXi_linearDemand
from utils_cournot import ProjectAlgEq_givenXi_linearDemand_Cournot

def setUpFitting():
    # Create a new model #
    model = gp.Model("fitting_model")

    # Define variables
    vthetas1 = model.addVars(4, name="vthetas1")
    vthetas2 = model.addVars(4, name="vthetas2")
    vthetas3 = model.addVars(4, name="vthetas3")

    return model, vthetas1, vthetas2, vthetas3

def MargRevenue_Function(thetas, prices, xi, ID):
    sum_prices = prices[0] + prices[1] + prices[2]

    if ID == 0: #player 1
        return thetas[1] + thetas[2]  * xi  -  thetas[0] * (sum_prices + prices[0]) - thetas[3] * prices[0]
    elif ID == 1: #player 2
        return  thetas[1] + thetas[2]  * xi  -  thetas[0] * (sum_prices + prices[1]) - thetas[3] * prices[1]
    elif ID ==2:
        return thetas[1] + thetas[2]  * xi  -  thetas[0] * (sum_prices + prices[2]) - thetas[3] * prices[2]
    else:
        assert 1 == 0

def MargRevenue_Function_Corr(thetas, prices, xi, ID):
    features = prices + [xi, 1]
    assert len(features) == len(thetas)
    # if ID == 0: #player 1
    #     return sum(thetas[i] * features[i] for i in range(len(thetas))) + prices[ID] * thetas[ID]
    # elif ID == 1: #player 2
    #     return sum(thetas[i] * features[i] for i in range(len(thetas))) + prices[ID] * thetas[ID]
    # else:
    #     assert 1 == 0
    return sum(thetas[i] * features[i] for i in range(len(thetas))) + prices[ID] * thetas[ID]

def utility_inference_func_cournot(df_train, pmax, true_thetas1, true_thetas2, true_thetas3):
    N = df_train.shape[0]
    # Compute the absolute difference between each element in the third column and the median
    absolute_differences = np.abs(df_train['xi'] - np.median(df_train['xi']))
    # Find all indices where the absolute difference is less than or equal to 1e-2
    indices = np.where(absolute_differences <= 1e-2)[0]
    # Get the first index
    if len(indices) > 0:
        indx = indices[0]
    else:
        indx = None  # Handle the case where no index is found
    print(indx)
    # Set up the fitting model
    model, vthetas1, vthetas2, vthetas3 = setUpFitting()

    ### normalization  constraint ###
    # MR_1: Marginal Revenue function for player 1
    # MR_1 = 2 * min(df_train['p1']) * true_thetas1[0] + df_train.loc[indx, 'p2'] * true_thetas1[1] + df_train.loc[indx, 'xi'] * true_thetas1[2] + true_thetas1[3]
    MR_1 = MargRevenue_Function(true_thetas1, [min(df_train['q1']), df_train.loc[indx, 'q2'], df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'], 0)
    model.addConstr(MargRevenue_Function(vthetas1, [min(df_train['q1']), df_train.loc[indx, 'q2'], df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'], 0) == MR_1)
    # model.addConstr(MR_1 == MargRevenue_Function_Corr(vthetas1, [min(df_train['p1']), df_train.loc[indx, 'p2']],
    #                                              df_train.loc[indx, 'xi'], 0))

    # MR_2: Marginal Revenue function for player 2
    # MR_2 = df_train.loc[indx, 'p1'] * true_thetas2[0] + 2 * min(df_train['p2']) * true_thetas2[1] + df_train.loc[indx, 'xi'] * true_thetas2[2] + true_thetas2[3]
    MR_2 = MargRevenue_Function(true_thetas2, [df_train.loc[indx, 'q1'], min(df_train['q2']), df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'],1)
    model.addConstr(MargRevenue_Function(vthetas2, [df_train.loc[indx, 'q1'], min(df_train['q2']), df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'],1) == MR_2)

    MR_3 = MargRevenue_Function(true_thetas3, [df_train.loc[indx, 'q1'], df_train.loc[indx, 'q2'], min(df_train['q3'])], df_train.loc[indx, 'xi'], 2)
    model.addConstr(MargRevenue_Function(vthetas3, [df_train.loc[indx, 'q1'], df_train.loc[indx,'q2'], min(df_train['q3'])], df_train.loc[indx, 'xi'], 2) == MR_3)

    # List to store residuals
    resids = []
    maxVal = model.addVar(lb=0, name="maxVal") # Add maxVal variable
    # Add residuals and constraints for each run
    for iRun in range(N):
        inPrices = df_train.loc[iRun, ['q1', 'q2', 'q3']]
        assert len(inPrices) == n_player
        errors = df_train.loc[iRun, ['xi']]

        prices_j = np.array(inPrices)
        GDP_j= errors[0]

        y = model.addVars(3, lb=0, name=f"y_{iRun}")
        resid = model.addVar(lb=0, name=f"resid_{iRun}")
        MR = model.addVars(3, name=f"MR_{iRun}") # Add supplementary variables MR

        # model.addConstr(MR[0] == 2 * prices_j[0] * vthetas1[0] + prices_j[1] * vthetas1[1] + GDP_j * vthetas1[2] + vthetas1[3], name=f"MR1_constraint_{iRun}")
        # model.addConstr(MR[1] == prices_j[0] * vthetas2[0] + 2 * prices_j[1] * vthetas2[1] + GDP_j * vthetas2[2] + vthetas2[3], name=f"MR2_constraint_{iRun}")
        model.addConstr(MR[0] == MargRevenue_Function(vthetas1, list(prices_j), GDP_j, 0), name=f"MR1_constraint_{iRun}")
        model.addConstr(MR[1] == MargRevenue_Function(vthetas2, list(prices_j), GDP_j, 1), name=f"MR2_constraint_{iRun}")
        model.addConstr(MR[2] == MargRevenue_Function(vthetas2, list(prices_j), GDP_j, 2), name=f"MR3_constraint_{iRun}")

        model.addConstr(y[0] >= MR[0], f"y1_{iRun}")
        model.addConstr(y[1] >= MR[1], f"y2_{iRun}")
        model.addConstr(y[2] >= MR[2], f"y3_{iRun}")
        # Adding the main constraint
        # model.addConstr(pmax * (y[0] + y[1]) - prices_t[0] * d[0] - prices_t[1] * d[1] -
        #                 prices_t[0] ** 2 * thetas1[0] - prices_t[1] ** 2 * thetas2[1] <= resid, f"main_{iRun}")
        model.addConstr(pmax * (y[0] + y[1] + y[2]) - prices_j[0] * MR[0] - prices_j[1] * MR[1]- prices_j[2] * MR[2] <= resid, f"main_{iRun}")

        resids.append(resid)
        model.addConstr(maxVal >= resid, f"maxVal_constr_{iRun}")

    # Assume vlambdas1 and vlambdas2 are already defined as lists of Gurobi variables
    num_features = len(vthetas1)  # theta dimension
    # Define supplementary variables t1 and t2
    t1 = model.addVars(num_features, lb=0, name="t1")
    t2 = model.addVars(num_features, lb=0, name="t2")
    t3 = model.addVars(num_features, lb=0, name="t3")
    # Add constraints to enforce the 1-norm bounds on vlambdas1 and vlambdas2
    for i in range(num_features):
        model.addConstr(t1[i] >= vthetas1[i], name=f"t1_pos_{i}")
        model.addConstr(t1[i] >= -vthetas1[i], name=f"t1_neg_{i}")
        model.addConstr(t2[i] >= vthetas2[i], name=f"t2_pos_{i}")
        model.addConstr(t2[i] >= -vthetas2[i], name=f"t2_neg_{i}")
        model.addConstr(t3[i] >= vthetas3[i], name=f"t2_pos_{i}")
        model.addConstr(t3[i] >= -vthetas3[i], name=f"t2_neg_{i}")
    ## add positivity
    # model.addConstr(2 * min(df_train['p1']) * vthetas1[0] + df_train.loc[indx, 'p2'] * vthetas1[1] + df_train.loc[indx, 'xi'] * vthetas1[2] + vthetas1[3] >= 0, name="positivity_constraint_1")
    # model.addConstr(df_train.loc[indx, 'p1'] * vthetas2[0] + 2 * min(df_train['p2']) * vthetas2[1] + df_train.loc[indx, 'xi'] * vthetas2[2] + vthetas2[3] >= 0, name="positivity_constraint_2")
    model.addConstr(MargRevenue_Function(vthetas1, [min(df_train['q1']), df_train.loc[indx, 'q2'], df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'], 0) >= 0, name="positivity_constraint_1")
    model.addConstr(MargRevenue_Function(vthetas2, [df_train.loc[indx, 'q1'], min(df_train['q2']), df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'], 1) >= 0, name="positivity_constraint_2")
    model.addConstr(MargRevenue_Function(vthetas3, [df_train.loc[indx, 'q1'], df_train.loc[indx, 'q2'], min(df_train['q3'])], df_train.loc[indx, 'xi'], 2) >= 0, name="positivity_constraint_3")

    #### add non-decreasing constraints for p1 ######
    price_data_1 = sorted(np.array(df_train['q1'])) #ascending order
    for j in range(len(price_data_1) - 1):
        lhs = MargRevenue_Function(vthetas1, [price_data_1[j], df_train.loc[indx, 'q2'], df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'], 0)
        rhs = MargRevenue_Function(vthetas1, [price_data_1[j + 1], df_train.loc[indx, 'q2'], df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'], 0)
        model.addConstr(lhs >= rhs, name=f"decreasing_constraint_p1_{j}")
    # Add one last constraint for pmax
    lhs = MargRevenue_Function(vthetas1, [price_data_1[len(price_data_1) - 1], df_train.loc[indx, 'q2'], df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'], 0)
    rhs = MargRevenue_Function(vthetas1, [pmax, df_train.loc[indx, 'q2'], df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'], 0)
    model.addConstr(lhs >= rhs, name="decreasing_constraint_p1_pmax")

    #### add non-decreasing constraints for p2 ######
    price_data_2 = sorted(np.array(df_train['q2']))
    for j in range(len(price_data_2) - 1):
        lhs = MargRevenue_Function(vthetas2, [df_train.loc[indx, 'q1'], price_data_2[j], df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'], 1)
        rhs = MargRevenue_Function(vthetas2, [df_train.loc[indx, 'q1'], price_data_2[j + 1], df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'], 1)
        model.addConstr(lhs >= rhs, name=f"decreasing_constraint_p2_{j}")
    # Add one last constraint for pmax
    lhs = MargRevenue_Function(vthetas2, [df_train.loc[indx, 'q1'], price_data_2[len(price_data_2) - 1], df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'], 1)
    rhs = MargRevenue_Function(vthetas2, [df_train.loc[indx, 'q1'], pmax, df_train.loc[indx, 'q3']], df_train.loc[indx, 'xi'], 1)
    model.addConstr(lhs >= rhs, name="decreasing_constraint_p2_pmax")


    #### add non-decreasing constraints for p3 ######
    price_data_2 = sorted(np.array(df_train['q3']))
    for j in range(len(price_data_2) - 1):
        lhs = MargRevenue_Function(vthetas2, [df_train.loc[indx, 'q1'], df_train.loc[indx, 'q2'], price_data_2[j]], df_train.loc[indx, 'xi'], 2)
        rhs = MargRevenue_Function(vthetas2, [df_train.loc[indx, 'q1'], df_train.loc[indx, 'q2'], price_data_2[j + 1]], df_train.loc[indx, 'xi'], 2)
        model.addConstr(lhs >= rhs, name=f"decreasing_constraint_p2_{j}")
    # Add one last constraint for pmax
    lhs = MargRevenue_Function(vthetas2, [df_train.loc[indx, 'q1'], df_train.loc[indx, 'q2'], price_data_2[len(price_data_2) - 1]], df_train.loc[indx, 'xi'], 2)
    rhs = MargRevenue_Function(vthetas2, [df_train.loc[indx, 'q1'], df_train.loc[indx, 'q2'], pmax], df_train.loc[indx, 'xi'], 2)
    model.addConstr(lhs >= rhs, name="decreasing_constraint_p3_pmax")

    # Define and add the regularization term
    lambda_reg = .01
    reg_term = model.addVar(name="reg_term")
    model.addConstr(reg_term == sum(t1[i] for i in range(num_features)) + sum(t2[i] for i in range(num_features))+ sum(t3[i] for i in range(num_features)),name="reg_term_sum")
    # Set the primary objective to minimize maxVal

    model.setObjective(maxVal + lambda_reg * reg_term, GRB.MINIMIZE)
    model.optimize()

    # Retrieve values of maxVal and reg_term
    target_val = model.getVarByName("maxVal").X
    ball_size = model.getVarByName("reg_term").X
    print(f"target_val: {target_val}")
    print(f"ball_size: {ball_size}")

    # model.addConstr(maxVal + lambda_reg * (gp.quicksum(t1) + gp.quicksum(t2)) <= model.objVal + 1e-6,name="NewConstraint")
    # model.setObjective(gp.quicksum(resids), GRB.MINIMIZE)
    # # Optimize the model
    # model.optimize()

    # Check and print the results
    if model.status == GRB.OPTIMAL:
        print("Optimal solution found.")
        print("maxVal:", maxVal.X)
        print("Residuals:", [resid.X for resid in resids])
        print("theta_1", [vthetas1[i].X for i in range(len(vthetas1))])
        print("theta_2", [vthetas2[i].X for i in range(len(vthetas2))])
        print("theta_3", [vthetas3[i].X for i in range(len(vthetas3))])
        # return theta_1 + theta_2
    else:
        print('model status is ', model.status) #The Gurobi status code 3 indicates that the model is infeasible
        model.computeIIS() #Cannot compute IIS on a feasible model
        model.write("model_Bertsimas.ilp")
        print("IIS written to 'model.ilp'")
        print("No optimal solution found.")

        print('The model is infeasible; relaxing the bounds')
        orignumvars = model.NumVars
        # relaxing only variable bounds #m.feasRelaxS(0, False, True, False)
        model.feasRelaxS(0, False, True, False)
        # for relaxing variable bounds and constraint bounds use
        # m.feasRelaxS(0, False, True, True)
        model.optimize()

        status = model.Status
        if status in (gp.GRB.INF_OR_UNBD, gp.GRB.INFEASIBLE, gp.GRB.UNBOUNDED):
            print('The relaxed model cannot be solved \
                      because it is infeasible or unbounded')
            sys.exit(1)
        if status != gp.GRB.OPTIMAL:
            print('Optimization was stopped with status %d' % status)
            sys.exit(1)

        # print the values of the artificial variables of the relaxation
        print('\nSlack values:')
        slacks = model.getVars()[orignumvars:]
        for sv in slacks:
            if sv.X > 1e-9:
                print('%s = %g' % (sv.VarName, sv.X))

    theta_1 = [vthetas1[i].X for i in range(len(vthetas1))]
    theta_2 = [vthetas2[i].X for i in range(len(vthetas2))]
    theta_3 = [vthetas3[i].X for i in range(len(vthetas3))]
    print('Estimated Theta is ', theta_1 + theta_2 + theta_3)

    return theta_1,  theta_2, theta_3

# Example usage
args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/', help = 'the root of data', type = str)
args_parser.add_argument('--u_type', default = 'linear', help = 'the type of demand function', type = str)
# args_parser.add_argument('--seed', default = 0, help = 'the random index of dataset', type = int)
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args_parser.add_argument('--pmax', default = 6, help = 'upper bound of price', type = float)
args_parser.add_argument('--nPlayer', default = 3, help = 'the number of players', type = int)
args = args_parser.parse_args()

file_path  = args.file_root
utility_type = args.u_type
n_player = args.nPlayer
pmax = args.pmax
N_train = args.N
print("pmax is {}".format(pmax))

save_path = './results/cournot/aaai_Baseline0/'
if not os.path.exists(save_path):
    os.makedirs(save_path)

seeds_theta_estimated = []
seeds_theta_estimated_normed = []
seeds_err_normed = []
seeds_equilibrium = []
seeds_equilibrium_approx = []
epsilon = 0.0001
for seed in range(10):

    Theta_true_normed = np.load(file_path + 'parameter_' + str(seed) + '_n_' + str(n_player) + '.npy',
                                allow_pickle=True)
    theta_1 = list(Theta_true_normed[:3]) + [Theta_true_normed[3]]
    theta_2 = list(Theta_true_normed[:3]) + [Theta_true_normed[4]]
    theta_3 = list(Theta_true_normed[:3]) + [Theta_true_normed[5]]

    assert len(theta_1) == 4

    train_file_path = file_path + 'dataset_seed_' + str(seed) + '_train_n_' + str(n_player) + '_N_' + str(N_train) + '_firstOrder' + '.csv'
    dataset_train_df = pd.read_csv(train_file_path)
    test_file_path = file_path + 'dataset_seed_' + str(seed) + '_test_n_' + str(n_player) + '_N_' + str(N_train) + '_firstOrder' + '.csv'
    dataset_test_df = pd.read_csv(test_file_path)

    ######## start to estimate thetas ########
    Theta_estimated_1, Theta_estimated_2, Theta_estimated_3 = utility_inference_func_cournot(dataset_train_df, pmax, theta_1, theta_2, theta_3)
    # error = np.linalg.norm(np.array(Theta_true_normed) - np.array(Theta_estimated))
    # # Estimated Theta is  [0.0, 0.6805791473995495, 0.0, 2.48023119594616, 1.3519388303126407, 0.0, 0.0, 0.0]
    # print('True theas is ', Theta_true_normed)
    # print('Estimated error is {}'.format(error)) #Estimated error is 2.9614639158104348
    c_set = [Theta_estimated_1[-1], Theta_estimated_2[-1], Theta_estimated_3[-1]]
    common_pars_set = list((np.array(Theta_estimated_1[:-1]) + np.array(Theta_estimated_2[:-1]) + np.array(Theta_estimated_3[:-1]))/3)
    Theta_estimated_equlib =  common_pars_set + c_set
    # print('Theta_estimated is ', Theta_estimated)
    Theta_estimated = Theta_estimated_1 + Theta_estimated_2 + Theta_estimated_3

    Theta_estimated_normed = Theta_estimated / np.linalg.norm(Theta_estimated)
    Theta_true_normed = theta_1 + theta_2 + theta_3
    error_normed = np.linalg.norm(np.array(Theta_true_normed) - np.array(Theta_estimated_normed))
    print('Estimated error (all normalize to l2-norm) is {}'.format(error_normed)) #Estimated error (all normalize to l2-norm) is 1.0710639067698995

    seeds_theta_estimated.append(Theta_estimated)
    seeds_theta_estimated_normed.append(Theta_estimated_normed)
    seeds_err_normed.append(error_normed)

    # ######## to evaluate the \| x_esti - x_true \|_{2} on out-of samples, i.e., testing dataset #######
    difference_set_test = []
    difference_set_test_approx = []
    dataset_test = np.array(dataset_test_df)
    for j in range(dataset_test.shape[0]):
        p_hat = dataset_test[j, 0:-1]
        assert len(p_hat) == dataset_test.shape[1] - 1
        xi_hat = dataset_test[j, -1]

        p_solution = firstOrderEq_givenXi_linearDemand(xi_hat, Theta_estimated_equlib, pmax)
        p_solution_approx1 = ProjectAlgEq_givenXi_linearDemand_Cournot(xi_hat, Theta_estimated_equlib, pmax, 1000, 0.01, epsilon)
        # print('Exact solution is {}'.format(p_solution))
        # print("Approximate {}-solution is {}".format(epsilon, p_solution_approximate))

        difference_j = np.linalg.norm(p_solution - p_hat)
        difference_set_test.append(difference_j)

        difference_j_approxi = np.linalg.norm(p_solution_approx1 - p_hat)
        difference_set_test_approx.append(difference_j_approxi)

    # print(difference_set_test)
    # print(np.mean(difference_set_test))
    # print(difference_set_test_approx)
    # print(np.mean(difference_set_test_approx))
    seeds_equilibrium.append(np.mean(difference_set_test))
    seeds_equilibrium_approx.append(np.mean(difference_set_test_approx))

#### save the results
result_dict = {
               'l2-norm-error-set': seeds_err_normed,
               'l2-norm-error-mean': np.mean(seeds_err_normed),
               'l2-norm-error-std': np.std(seeds_err_normed),
               'error-equilibrium': seeds_equilibrium,
               'error-equilibrium-mean': np.mean(seeds_equilibrium),
               'error-equilibrium-std': np.std(seeds_equilibrium),
               str(epsilon) +'-equilibrium-approx-mean': np.mean(seeds_equilibrium_approx),
               str(epsilon) +'-equilibrium-approx-std': np.std(seeds_equilibrium_approx),
               }

with open(save_path + 'Bertsimas_u_' + utility_type +'_N_'+str(N_train)+'.txt', 'w') as f:
    print(result_dict, file = f)
    print(result_dict)


