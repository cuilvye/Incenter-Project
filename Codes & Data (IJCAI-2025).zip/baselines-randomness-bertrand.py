#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""
import pandas as pd
import numpy as np
import gurobipy as gp
import os, sys
import time
from gurobipy import GRB, quicksum
from scipy.optimize import fsolve
import argparse
import itertools

from utils_bertrand_incenter import phi_func
from utils_bertrand import firstOrderEq_givenXi_linearDemand
from utils_bertrand import ProjectAlgEq_givenXi_linearDemand

# Example usage #
args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/', help = 'the root of data', type = str)
args_parser.add_argument('--u_type', default = 'linear', help = 'the type of demand function', type = str)
# args_parser.add_argument('--seed', default = 0, help = 'the random index of dataset', type = int)
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args_parser.add_argument('--pmax', default = 8, help = 'upper bound of price', type = float)
args_parser.add_argument('--nPlayer', default = 2, help = 'the number of players', type = int)
args = args_parser.parse_args()

file_path  = args.file_root
utility_type = args.u_type
# seed = args.seed
pmax = args.pmax
N_train = args.N
n_player = args.nPlayer
print("pmax is {}".format(pmax))

save_path = './results/bertrand/aaai_Baseline2/'
if not os.path.exists(save_path):
    os.makedirs(save_path)

seeds_theta_estimated = []
seeds_theta_estimated_normed = []
seeds_err_normed = []
seeds_equilibrium = []
seeds_equilibrium_approx = []
epsilon = 0.000001
for seed in range(10):
    Theta_true_normed =  np.load(file_path + 'Seed_' + str(seed) + '_parameters.npy', allow_pickle=True)
    theta_1 = Theta_true_normed[:4]
    theta_2 = Theta_true_normed[4:]

    train_file_path = file_path + 'Seed_' + str(seed) + '_SDP_train_u_' + utility_type + '_N_' + str(N_train) + '_firstOrder'+'.csv'
    dataset_train_df = pd.read_csv(train_file_path)
    test_file_path = file_path + 'Seed_' + str(seed) + '_SDP_test_u_' + utility_type + '_N_' + str(N_train) + '_firstOrder'+'.csv'
    dataset_test_df = pd.read_csv(test_file_path)

    ######## start to estimate thetas ########
    Theta_estimated = np.random.uniform(low = -10, high = 10, size= len(Theta_true_normed))

    # error = np.linalg.norm(np.array(Theta_true_normed) - np.array(Theta_estimated))
    # # Estimated Theta is  [0.0, 0.6805791473995495, 0.0, 2.48023119594616, 1.3519388303126407, 0.0, 0.0, 0.0]
    # print('True theas is ', Theta_true_normed)
    # print('Estimated error is {}'.format(error)) #Estimated error is 2.9614639158104348

    Theta_estimated_normed = Theta_estimated / np.linalg.norm(Theta_estimated)
    error_normed = np.linalg.norm(np.array(Theta_true_normed) - np.array(Theta_estimated_normed))
    print('Estimated error (all normalize to l2-norm) is {}'.format(error_normed)) #Estimated error (all normalize to l2-norm) is 1.0710639067698995

    seeds_theta_estimated.append(Theta_estimated)
    seeds_theta_estimated_normed.append(Theta_estimated_normed)
    seeds_err_normed.append(error_normed)

    # ######## to evaluate the \| x_esti - x_true \|_{2} on out-of samples, i.e., testing dataset #######
    difference_set_test = []
    difference_set_test_approx = []
    dataset_test = np.array(dataset_test_df)
    for j in range(dataset_test.shape[0]):
        p_hat = dataset_test[j, 0:2]
        assert len(p_hat) == 2
        xi_hat = dataset_test[j, 2]

        p_solution = firstOrderEq_givenXi_linearDemand(xi_hat, Theta_estimated_normed[:4], Theta_estimated_normed[4:], pmax)
        p_solution_approx1 = ProjectAlgEq_givenXi_linearDemand(xi_hat, Theta_estimated_normed[:4], Theta_estimated_normed[4:], pmax, 1000, 0.01, epsilon)
        # print('Exact solution is {}'.format(p_solution))
        # print("Approximate {}-solution is {}".format(epsilon, p_solution_approximate))

        difference_j = np.linalg.norm(p_solution - p_hat)
        difference_set_test.append(difference_j)

        difference_j_approxi = np.linalg.norm(p_solution_approx1 - p_hat)
        difference_set_test_approx.append(difference_j_approxi)

    # print(difference_set_test)
    # print(np.mean(difference_set_test))
    # print(difference_set_test_approx)
    # print(np.mean(difference_set_test_approx))
    seeds_equilibrium.append(np.mean(difference_set_test))
    seeds_equilibrium_approx.append(np.mean(difference_set_test_approx))

#### save the results
result_dict = {
               'l2-norm-error-set': seeds_err_normed,
               'l2-norm-error-mean': np.mean(seeds_err_normed),
               'l2-norm-error-std': np.std(seeds_err_normed),
               'error-equilibrium': seeds_equilibrium,
               'error-equilibrium-mean': np.mean(seeds_equilibrium),
               'error-equilibrium-std': np.std(seeds_equilibrium),
               str(epsilon) +'-equilibrium-approx-mean': np.mean(seeds_equilibrium_approx),
               str(epsilon) +'-equilibrium-approx-std': np.std(seeds_equilibrium_approx),
               }

with open(save_path + 'Randomness_u_' + utility_type +'_N_'+str(N_train)+'.txt', 'w') as f:
    print(result_dict, file = f)

print(result_dict)


