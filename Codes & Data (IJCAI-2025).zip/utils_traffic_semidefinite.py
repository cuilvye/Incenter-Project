#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

import numpy as np
import time
from scipy.linalg import issymmetric

from utils_traffic_incenter import FOP_game_Traffic
from utils_traffic_incenter import phi_func_traffic

def normalize_each_variable_traffic(Lambda0, Lambda1, Gamma0, Gamma1):

    Lambda0_nor = Lambda0 / np.linalg.norm(Lambda0, 'fro')
    Lambda1_nor = Lambda1 / np.linalg.norm(Lambda1, 'fro')

    Gamma0_nor = Gamma1 / np.linalg.norm(Gamma0, 'fro')
    Gamma1_nor = Gamma1 / np.linalg.norm(Gamma1, 'fro')

    return Lambda0_nor, Lambda1_nor, Gamma0_nor, Gamma1_nor

def compute_mu_k_traffic(Lambda0_k, Lambda1_k,Gamma0_k, Gamma1_k):

    mu_k_reci = (np.matrix.trace(Lambda0_k @ Gamma0_k)+ np.matrix.trace(Lambda1_k @ Gamma1_k)) / (Lambda0_k.shape[0] * 2)
    mu_k = 1 / mu_k_reci

    return mu_k

def callback(theta):
    """Store input and current time."""
    return theta, time.time()

def convert_lambdas_to_theta_traffic(Lambda_0, Lambda_1):

    thetas = []
    ## need to check this ##
    for i in range(Lambda_0.shape[0]):
        thetas.append(Lambda_0[i, i])
        thetas.append(Lambda_1[i, i])
    # print(thetas)
    # print(affff)
    return thetas

def is_semiPos_def(X):# ONLY FOR SYMMETRIC MATRIX
    # print(X)
    if issymmetric(X):
        return np.all(np.linalg.eigvals(X) >= 0)
    else:
        X_new = X + X.transpose()
        return np.all(np.linalg.eigvals(X_new) >= 0)

def compute_ASL_loss_traffic(Lambda_0, Lambda_1, samples, np_capacities, n_arcs, p_set, squaring_param, alpha):
    pmin, pmax = p_set[0], p_set[1]
    theta = convert_lambdas_to_theta_traffic(Lambda_0, Lambda_1)
    theta = theta / np.linalg.norm(theta)

    psi_0_j_set, psi_1_j_set, vec_v_j_norm_avg = compute_psi_j_set_using_data_traffic(samples, np_capacities, n_arcs, p_set, theta, squaring_param)


    mat_Psi_0 = np.mean(psi_0_j_set, axis=0)  # 1/N(\sum_{i=1}^{N}psi_j)
    mat_Psi_1 = np.mean(psi_1_j_set, axis=0)

    assert mat_Psi_0.shape[0] == n_arcs
    assert mat_Psi_1.shape[0] == n_arcs

    assert issymmetric(mat_Psi_0) == True
    assert issymmetric(mat_Psi_1) == True

    # ASL loss
    loss_ASL = ( 0.5 * alpha * (np.linalg.norm(Lambda_0, 'fro') ** 2) - np.matrix.trace(mat_Psi_0 @ Lambda_0)
                + 0.5 * alpha * (np.linalg.norm(Lambda_1, 'fro') ** 2) - np.matrix.trace(mat_Psi_1 @ Lambda_1)
                + vec_v_j_norm_avg)

    return loss_ASL, mat_Psi_0, mat_Psi_1, vec_v_j_norm_avg
def compute_psi_j_set_using_data_traffic(samples, np_capacities, n_arcs, p_set, theta_t, squaring_param):
    pmin, pmax = p_set[0], p_set[1]
    psi_0_j_set, psi_1_j_set = [], []
    vec_v_j_norm_set = []
    for i in range(len(samples)):
        # Check if the FOP is augmented
        # print(p1_hat, p2_hat, xi_hat)
        x_hat = samples[i]
        try:
            x_opt = FOP_game_Traffic(np_capacities, n_arcs, pmax, pmin, theta_t, x_hat, squaring_param)
            # print(x_opt)
            # print('distance between x and \hat{x} is', np.linalg.norm(x_opt - x_hat))
        except TypeError:
            print('there is sth wrong with the gradient computation..., please check them')


        phi_j = phi_func_traffic(np_capacities, x_hat)

        # n_player = 2
        each_theta_len = int(len(theta_t) / n_arcs)
        I_n = np.ones(each_theta_len)
        temp_m = np.kron(I_n, (x_opt - x_hat))

        # Need to modify the following codes
        vec_v_j = phi_j * temp_m.reshape(-1, order='F')# * means element-size multiplication


        psi_0_j = np.diag(list(vec_v_j)[0::2]) ## be careful! need to check again!!! even positions
        psi_1_j = np.diag(list(vec_v_j)[1::2]) ## need to check this
        assert len(list(vec_v_j)[0::2]) == len(list(vec_v_j)[1::2])
        assert len(list(vec_v_j)[0::2]) + len(list(vec_v_j)[1::2]) == len(list(vec_v_j))
        psi_0_j_set.append(psi_0_j)
        psi_1_j_set.append(psi_1_j)

        vec_v_j_norm_set.append(np.linalg.norm(vec_v_j, 2))

    vec_v_j_norm_avg = np.mean(vec_v_j_norm_set)

    return  psi_0_j_set, psi_1_j_set,  vec_v_j_norm_avg

def zero_to_nan(array):
    array[array == 0] = np.NaN
    return array