# Inverse Game Theory: An Incenter-Based Approach  

This repository is the specific implementation of our accepted paper for IJCAI-2025.

## Requirements

To install requirements:

```setup
pip install -r requirements.txt
```

## Utility Estimation for Bertrand-Nash Competition


To generate the synthetic data, run the command:

```data
python generate-data-bertrand-semidefinite.py  --seed 1 --N 500 --u_type 'linear' --file_root <save root path> 
```

To run the Algorithm 1, run the following command:

```learning
python mirror-descent-bertrand.py --file_root <the root path of data> --seed 1 --nPlayer 2 --step 'standard' --regularizer 'L2_squared' -- reg_param 0.01 
```

To run the Algorithm 2, run the following commands:

```learning
python semi-definite-PD-IP-bertrand.py --file_root <the root path of data> --seed 1 --nPlayer 2 --step 'newton' --regularizer 'L2_squared' -- reg_param 0.01 
```

To calculate the equilibrium using out-of samples, run the following commands:

```equilibrium
python mirror-descent-outSample-bertrand.py --file_root <the root path of data> --seed 1 --N 500 --nPlayer 2 --Epoch 500 --u_type 'linear' --step 'standard' 
```

```equilibrium
python semi-definite-outSample-bertrand.py --file_root <the root path of data> --seed 1 --N 500 --nPlayer 2 --Epoch 500 --u_type 'linear' --step 'newton' 
```


## Utility Estimation for Cournot Competition


To generate the synthetic data, run the command:

```data
python generate-data-cournot.py  --seed 1 --n_firm 3 --N_train 500 --q_max 6 --file_root <save root path> 
```

To run the Algorithm 1, run the following command:

```learning
python mirror-descent-cournot.py --file_root <the root path of data> --seed 1 --nPlayer 3 --qmax 6 --step 'standard' --regularizer 'L2_squared' -- reg_param 0.01 
```

To run the Algorithm 2, run the following commands:

```learning
python semi-definite-PD-IP-cournot.py --file_root <the root path of data> --seed 1 --nPlayer 3 --qmax 6 --step 'newton' --regularizer 'L2_squared' 
```

To calculate the equilibrium using out-of samples, run the following commands:

```equilibrium
python mirror-descent-outSample-cournot.py --file_root <the root path of data> --seed 1 --nPlayer 3 --N 500 --qmax 6  --step 'standard' 
```

```equilibrium
python semi-definite-outSample-cournot.py --file_root <the root path of data> --seed 1 --N 500 --nPlayer 3 --qmax 6 --step 'newton' 
```

## Cost Estimation for Traffic Game


To generate the synthetic data, run the command:

```data
python generate-data-traffic.py  
```

To run the Algorithm 1, run the following command:

```learning
python mirror-descent-traffic.py --file_root <the root path of data>  --N 500 --step 'standard' --regularizer 'L2_squared' -- reg_param 0.01 
```

To run the Algorithm 2, run the following commands:

```learning
python semi-definite-PD-IP-traffic.py --file_root <the root path of data> --N 500 --step 'newton' --regularizer 'L2_squared' 
```

To calculate the equilibrium using out-of samples, run the following commands:

```equilibrium
python mirror-descent-outSample-traffic.py --file_root <the root path of data> --r 0 --N 500 --Epoch 300  --step 'standard' 
```

```equilibrium
python semi-definite-outSample-traffic.py --file_root <the root path of data> --r 0 --N 500 --Epoch 50  --step 'newton' 
```