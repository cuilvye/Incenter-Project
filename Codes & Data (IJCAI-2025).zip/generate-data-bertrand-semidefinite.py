#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

import numpy as np
import pandas as pd
import argparse

from utils_bertrand import FirstOrder_Equilibrium_LinearDemand


args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/bertrand/', help = 'the root of data', type = str)
args_parser.add_argument('--u_type', default = 'linear', help = 'the type of demand function', type = str)
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args_parser.add_argument('--pmax', default = 8, help = 'upper bound of price', type = float)
args_parser.add_argument('--seed', default = 0, help = 'the random index of dataset', type = int)
args = args_parser.parse_args()

file_root = args.file_root
u_type = args.u_type
N_train = args.N
N_test = N_train
pmax = args.pmax
seed = args.seed
save_path = file_root


# Generate Theta, theta_1, and theta_2 satisfying the constraints
# Theta, theta_1, theta_2 = generate_theta_with_constraints()
# theta_1_org = [-1.2, 0.5, 1, 1]
# theta_2_org = [0.3, -1, 1, 1]

xi_mean = 5
xi_std = 1.5
paras_name = save_path + 'Seed_' + str(seed) + '_parameters.npy'
thetas_org = np.load(paras_name, allow_pickle=True)
theta_1_org = thetas_org[:4]
theta_2_org = thetas_org[4:]

# theta_11 = np.random.normal(-1.2, 0.5) #Standard deviation (spread or “width”) of the distribution.
# theta_12 = np.random.normal(0.5, 0.1)
# theta_13 = np.random.normal(1, 0.5)
# theta_14 = np.random.normal(1, 0.5)
#
# theta_21 = np.random.normal(0.3, 0.1) #Standard deviation (spread or “width”) of the distribution.
# theta_22 = np.random.normal(-1, 0.5)
# theta_23 = np.random.normal(1, 0.5)
# theta_24 = np.random.normal(1, 0.5)
# # theta_1 = [-1.2, 0.5, 1, 1]
# # theta_2 = [0.3, -1, 1, 1]
# theta_1_org = [theta_11, theta_12, theta_13, theta_14]
# theta_2_org = [theta_21, theta_22, theta_23, theta_24]

theta_1 = list(np.array(theta_1_org) / theta_1_org[1])
theta_2 = list(np.array(theta_2_org) / theta_2_org[0])
theta_2[2] = (theta_2[2] + theta_1[3])/2
theta_1[3] = (theta_2[2] + theta_1[3])/2
 # theta_2[2] = theta_1[3]
# theta_1[3] = theta_2[2]: only for seed = 4

Theta = theta_1 + theta_2
Theta_normed = Theta / np.linalg.norm(Theta)
# Theta = array([-0.37040644,  0.15433602,  0.30867203,  0.30867203,  0.15433602,
#        -0.51445339,  0.30867203,  0.51445339])
# Theta: [-2.4, 1.0, 2.0, 2.0, 1.0, -3.3333333333333335, 2.0, 3.3333333333333335]
theta_1_normed = Theta_normed[:4]
theta_2_normed = Theta_normed[4:]
# Sample x1 and x2 from the normal distribution
print("Theta:", Theta_normed)
print("theta_1:", theta_1_normed)
print("theta_2:", theta_2_normed)

# Define the profit functions' first-order conditions

paras_name = save_path + 'Seed_' + str(seed) + '_parameters_SDP.npy'
np.save(paras_name, np.array(Theta_normed, dtype=object), allow_pickle=True)

dataset_train_np = FirstOrder_Equilibrium_LinearDemand(N_train, xi_mean, xi_std, theta_1, theta_2, pmax)
print(dataset_train_np)
if np.any(dataset_train_np[:, 0:2] <= 0): ## is all p1-p2  >= 0
    print("The array contains elements less than or equal to zero.")
if np.any(dataset_train_np[:, 0:2] > pmax): ##=
    print("The array contains elements > pmax.")
dataset_train_df = pd.DataFrame(dataset_train_np, columns=['p1', 'p2', 'xi'])
dataset_train_df.to_csv(save_path + 'Seed_' + str(seed) + '_SDP_train_u_linear_N_' + str(N_train) + '_firstOrder.csv', index=False)


dataset_test_np = FirstOrder_Equilibrium_LinearDemand(N_test, xi_mean, xi_std, theta_1, theta_2, pmax)
print(dataset_test_np)
if np.any(dataset_test_np[:, 0:2] <= 0): ## is all p1-p2  >= 0
    print("The array contains elements less than or equal to zero.")
if np.any(dataset_test_np[:, 0:2] > pmax): ##=
    print("The array contains elements > pmax.")
dataset_test_df = pd.DataFrame(dataset_test_np, columns=['p1', 'p2', 'xi'])
dataset_test_df.to_csv(save_path + 'Seed_' + str(seed) + '_SDP_test_u_linear_N_' + str(N_test) + '_firstOrder.csv', index=False)