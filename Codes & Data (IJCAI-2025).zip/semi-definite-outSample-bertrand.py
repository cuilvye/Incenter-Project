#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import fsolve
import time, argparse

from utils_bertrand import firstOrderEq_givenXi_linearDemand
from utils_bertrand import ProjectAlgEq_givenXi_linearDemand
from utils_bertrand_semidefinite import convert_beth_to_theta

args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/bertrand/', help = 'the root of data', type = str)
args_parser.add_argument('--u_type', default = 'linear', help = 'the type of demand function', type = str)
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args_parser.add_argument('--seed', default = 0, help = 'random index', type = int)
args_parser.add_argument('--pmax', default = 8, help = 'upper bound of price', type = float)
args_parser.add_argument('--squaring', default = 1, help = 'random index', type = float)
args_parser.add_argument('--Epoch', default = 50, help = 'maximum of iterations in our algorithm', type = int)
args_parser.add_argument('--step', default = 'newton', help = 'the descent update method', type = str)
args_parser.add_argument('--regularizer', default = 'L2_squared', help = 'the regularizer term in our loss', type = str)
args = args_parser.parse_args()

file_path = args.file_root
utility_type = args.u_type
N_train = args.N
pmax = args.pmax
seed = args.seed
squaring_param = args.squaring
if squaring_param == 1.0:
    squaring_param = int(squaring_param)

epoch_max = args.Epoch
step = args.step #'exponentiated'
regularizer = args.regularizer

seeds_error_exact = []
seeds_error_approx1, seeds_error_approx2, seeds_error_approx3, seeds_error_approx4 = [], [], [], []
# for seed in range(10):
# Theta_true = np.load(file_path + 'Seed_' + str(seed) + '_parameters.npy', allow_pickle=True)
# Theta_norm = Theta_true / np.linalg.norm(Theta_true)

# dataset_train_df = pd.read_csv(file_path + 'Seed_' + str(seed) + '_dataset_train_u_'+ utility_type + '_N_' + str(N_train) + '_firstOrder.csv')
dataset_test_df = pd.read_csv(file_path + 'Seed_' + str(seed) + '_SDP_test_u_' + utility_type + '_N_' + str(N_train) + '_firstOrder.csv')
dataset_test = np.array(dataset_test_df)

thetas_path = './EstimatedThetas/bertrand/seed_' + str(seed)  # + '/' + step + '_' + regularizer

epsilon_1 = 1e-8
epsilon_2 = 1e-6
epsilon_3 = 1e-4
epsilon_4 = 1e-3

thetas_iter_name = thetas_path + '/SDP_thetas_run_0_' + utility_type+'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step +'.npy'
print('loading ' + thetas_iter_name)
callback_results = np.load(thetas_iter_name, allow_pickle=True)

err_x_T, err_x_T_approx1, err_x_T_approx2, err_x_T_approx3, err_x_T_approx4 = [], [], [], [], []
time_s = time.time()
for i in range(1, len(callback_results)):
    variables_t = callback_results[i][0]
    beth_t = variables_t[0]
    tilde_beth_t = variables_t[1]

    theta_t = convert_beth_to_theta(beth_t, tilde_beth_t)

    theta_t_norm = theta_t / np.linalg.norm(theta_t)
    theta_1 = theta_t_norm[:int(len(theta_t) / 2)]
    theta_2 = theta_t_norm[int(len(theta_t) / 2):]

    res_test, res_test_approx1, res_test_approx2, res_test_approx3, res_test_approx4 = [], [], [], [], []
    for j in range(0, dataset_test.shape[0]):
        print('i is {}, j is {}'.format(i, j))
        p_hat = dataset_test[j, 0:2]
        assert len(p_hat) == 2
        xi_hat = dataset_test[j, 2]
        # print('xi_hat is {}'.format(xi_hat))
        # print("p_hat is {}".format(p_hat))
        p_solution = firstOrderEq_givenXi_linearDemand(xi_hat, theta_1, theta_2, pmax)
        p_solution_approx1 = ProjectAlgEq_givenXi_linearDemand(xi_hat, theta_1, theta_2, pmax, 1000, 0.01, epsilon_1)
        p_solution_approx2 = ProjectAlgEq_givenXi_linearDemand(xi_hat, theta_1, theta_2, pmax, 1000,
                                                                   0.01, epsilon_2)
        p_solution_approx3 = ProjectAlgEq_givenXi_linearDemand(xi_hat, theta_1, theta_2, pmax, 1000,
                                                                   0.01, epsilon_3)
        p_solution_approx4 = ProjectAlgEq_givenXi_linearDemand(xi_hat, theta_1, theta_2, pmax, 1000,
                                                                   0.01, epsilon_4)
        # p_solution_approximate_2 = find_bertrand_nash_equilibrium(xi_hat, theta_t[:4], theta_t[4:], pmax, 1000, 0.01, 0.001)
        print('Exact solution is {}'.format(p_solution))
        print("Approximate {}-solution is {}".format(epsilon_1, p_solution_approx1))
        print("Approximate {}-solution is {}".format(epsilon_2, p_solution_approx2))
        print("Approximate {}-solution is {}".format(epsilon_3, p_solution_approx3))
        print("Approximate {}-solution is {}".format(epsilon_4, p_solution_approx4))

        res_test.append(np.linalg.norm(p_solution - p_hat))
        res_test_approx1.append(np.linalg.norm(p_solution_approx1 - p_hat))
        res_test_approx2.append(np.linalg.norm(p_solution_approx2 - p_hat))
        res_test_approx3.append(np.linalg.norm(p_solution_approx3 - p_hat))
        res_test_approx4.append(np.linalg.norm(p_solution_approx4 - p_hat))

    # print(difference_set_test)
    err_x_T.append(np.mean(res_test))
    err_x_T_approx1.append(np.mean(res_test_approx1))
    err_x_T_approx2.append(np.mean(res_test_approx2))
    err_x_T_approx3.append(np.mean(res_test_approx3))
    err_x_T_approx4.append(np.mean(res_test_approx4))

#### save each error list since it is spending ####
exact_name = thetas_path +'/SDP_run_0_PredictError_Exact_' + utility_type+'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy'
np.save(exact_name, np.array(err_x_T, dtype=object), allow_pickle=True)
approx1_name = thetas_path +'/SDP_run_0_PredictError_Approx_'+str(epsilon_1)+'_'+utility_type+'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy'
np.save(approx1_name, np.array(err_x_T_approx1, dtype=object), allow_pickle=True)
approx2_name = thetas_path + '/SDP_run_0_PredictError_Approx_'+str(epsilon_2)+'_'+utility_type+'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy'
np.save(approx2_name, np.array(err_x_T_approx2, dtype=object), allow_pickle=True)
approx3_name = thetas_path +  '/SDP_run_0_PredictError_Approx_'+str(epsilon_3)+'_'+utility_type+'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train)+ '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy'
np.save(approx3_name, np.array(err_x_T_approx3, dtype=object), allow_pickle=True)
approx4_name = thetas_path + '/SDP_run_0_PredictError_Approx_'+str(epsilon_4)+'_'+utility_type+'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy'
np.save(approx4_name, np.array(err_x_T_approx4, dtype=object), allow_pickle=True)

print('Time spent is {} minutes'.format((time.time() - time_s)/60))
seeds_error_exact.append(err_x_T)
seeds_error_approx1.append(err_x_T_approx1)
seeds_error_approx2.append(err_x_T_approx2)
seeds_error_approx3.append(err_x_T_approx3)
seeds_error_approx4.append(err_x_T_approx4)

colors = ['#e41a1c', '#377eb8', '#4daf4a', '#984ea3', '#ff7f00', '#808080',
          '#a65628', '#FFD700']
# plot for each  #
plt.rcParams["mathtext.fontset"] = 'cm'
plt.rcParams['font.family'] = 'serif'
plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]
plt.figure()
plt.plot(range(1, len(err_x_T) + 1), err_x_T,  '--', label='Nash Eq.', color=colors[0], marker='s', markevery=5, markersize=15, linewidth=2)
plt.plot(range(1, len(err_x_T_approx1) + 1), err_x_T_approx1, '--', label= str(epsilon_1)+'-Nash Eq.', color=colors[1], marker='o', markevery=5, markersize=15, linewidth=2)
plt.plot(range(1, len(err_x_T_approx2) + 1), err_x_T_approx2, label=str(epsilon_2)+'-Nash Eq.', color=colors[2], marker='^', markevery=5, markersize=15, linewidth=2)
plt.plot(range(1, len(err_x_T_approx3) + 1), err_x_T_approx3, label=str(epsilon_3)+'-Nash Eq.', color=colors[3], marker='v', markevery=5, markersize=15, linewidth=2)
plt.plot(range(1, len(err_x_T_approx4) + 1), err_x_T_approx4, label=str(epsilon_4)+'-Nash Eq.', color=colors[4], marker='*', markevery=5, markersize=15, linewidth=2)

plt.ylabel(
    r'$\| x_{\mathrm{esti}} - x_{\mathrm{true}} \|_2$', fontsize=18
)
plt.xlabel(r'Iterations', fontsize=14)
plt.xlim(0, len(err_x_T))
# plt.ylim(0, 7)
plt.grid(visible=True)
plt.legend(fontsize='16', loc='lower right')
plt.tight_layout()
# saving the figure.
plt.savefig(thetas_path + '/SDP_run_0_PredictionError_'+utility_type +'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max) +'.png')
plt.show()
plt.close()



