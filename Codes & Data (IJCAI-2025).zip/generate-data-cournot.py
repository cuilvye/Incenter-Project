#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

import os.path

import numpy as np
import pandas as pd
import argparse

from utils_cournot import FirstOrder_Equilibrium_LinearDemand_Cournot

# Generate parameters theta_1 and theta_2 ensuring constraints#


# Generate Theta, theta_1, and theta_2 satisfying the constraints
# Theta, theta_1, theta_2 = generate_theta_with_constraints()
args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/cournot/', help = 'the root of data', type = str)
args_parser.add_argument('--seed', default = 4, help = 'random index', type = int)
args_parser.add_argument('--N_train', default = 500, help = 'the number of training dataset', type = int)
args_parser.add_argument('--n_firm', default = 3, help = 'the number of firms', type = int)
args_parser.add_argument('--q_max', default = 6, help = 'the capacity that each firm can generate', type = int)
args_parser.add_argument('--xi_mean', default = 6, help = 'the mean of normal distribution', type = float)
args_parser.add_argument('--xi_std', default = 2, help = 'the std of normal distribution', type = float)
args = args_parser.parse_args()

save_path = args.file_root
seed = args.seed
n_firm = args.n_firm
N_train = args.N_train
N_test = N_train
q_max = args.q_max

if not os.path.exists(save_path):
    os.makedirs(save_path)

xi_mean = args.xi_mean
xi_std = args.xi_std

# xi = np.random.normal(xi_mean, xi_std)
# paras_array = np.random.uniform(low = 1, high = 3, size = n_firm + 3)
b = np.random.normal(50, 5, 1)# scale is the standard deviation of the normal distribution
a = np.random.uniform(low = 5, high = 10, size =1)
# a = np.random.normal(5, 0.5, size =1)
d = np.random.uniform(low = 5, high = 10, size =1)
# d = np.random.normal(1, 0.1, 1)#
c_set = np.random.uniform(low = 10, high = 20, size = n_firm)
paras_array = list(a) + list(b) + list(d) + list(c_set)
print(paras_array)
paras_array = paras_array / np.linalg.norm(paras_array)
print(paras_array)

#paras_set = (a,b,d,c1,c2,c3)
if n_firm == 5:
    c1, c2, c3, c4, c5 = c_set[0], c_set[1], c_set[2], c_set[3], c_set[4]
elif n_firm == 3:
    c1, c2, c3  = c_set[0], c_set[1], c_set[2]


# Define the profit functions' first-order conditions

dataset_train_np = FirstOrder_Equilibrium_LinearDemand_Cournot(N_train, xi_mean, xi_std, paras_array, q_max, n_firm)
print(dataset_train_np)
if np.any(dataset_train_np[:, 0:n_firm] <= 0): ## is all p1-p2  >= 0
    print("The array contains elements less than or equal to zero.")
if np.any(dataset_train_np[:, 0:n_firm] > q_max): ##=
    print("The array contains elements > qmax.")


paras_name = save_path + 'parameter_' + str(seed) + '_n_' + str(n_firm) + '.npy'
np.save(paras_name, np.array(paras_array, dtype=object), allow_pickle=True)

if n_firm == 5:
    dataset_train_df = pd.DataFrame(dataset_train_np, columns=['q1', 'q2', 'q3', 'q4', 'q5', 'xi'])
elif n_firm == 3:
    dataset_train_df = pd.DataFrame(dataset_train_np, columns=['q1', 'q2', 'q3', 'xi'])
dataset_train_df.to_csv(save_path + 'dataset_seed_'+str(seed)+'_train_n_' + str(n_firm)+'_N_' + str(N_train) + '_firstOrder.csv', index=False)


dataset_test_np = FirstOrder_Equilibrium_LinearDemand_Cournot(N_test, xi_mean, xi_std, paras_array, q_max, n_firm)
print(dataset_test_np)
if np.any(dataset_test_np[:, 0:n_firm] <= 0): ## is all p1-p2  >= 0
    print("The array contains elements less than or equal to zero.")
if np.any(dataset_test_np[:, 0:n_firm] > q_max): ##=
    print("The array contains elements > qmax.")
if n_firm == 5:
    dataset_test_df = pd.DataFrame(dataset_test_np, columns=['q1', 'q2', 'q3', 'q4', 'q5', 'xi'])
elif n_firm == 3:
    dataset_test_df = pd.DataFrame(dataset_test_np, columns=['q1', 'q2', 'q3', 'xi'])
dataset_test_df.to_csv(save_path + 'dataset_seed_' + str(seed) +'_test_n_'+ str(n_firm)+'_N_' + str(N_test) + '_firstOrder.csv', index=False)