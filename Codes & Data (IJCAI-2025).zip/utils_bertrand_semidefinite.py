#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

import numpy  as np
import pandas as pd
from scipy.linalg import issymmetric
import time

from utils_bertrand_incenter import FOP_game, phi_func

def convert_beth_to_theta(beth, tilde_beth):
    thetas_1 = [-beth[0, 0], -2 * beth[1, 0], tilde_beth[0, 0], tilde_beth[1, 0]]
    thetas_2 = [-2 * beth[0, 1], -beth[1, 1], tilde_beth[0, 1], tilde_beth[1, 1]]
    thetas = thetas_1 + thetas_2

    return thetas

def is_semiPos_def(X):# ONLY FOR SYMMETRIC MATRIX
    # print(X)
    if issymmetric(X):
        return np.all(np.linalg.eigvals(X) >= 0)
    else:
        X_new = X + X.transpose()
        return np.all(np.linalg.eigvals(X_new) >= 0)

def compute_asl_loss(beth, tilde_beth, samples, n_player, pmax, squaring_param, alpha):
    theta_1 = [-beth[0, 0], -2 * beth[1, 0], tilde_beth[0, 0], tilde_beth[1, 0]]
    theta_2 = [-2 * beth[0, 1], -beth[1, 1], tilde_beth[0, 1], tilde_beth[1, 1]]
    theta = theta_1 + theta_2
    theta = theta / np.linalg.norm(theta)
    psi_j_sym_set, psi2_j_sym_set, _, _, vec_v_j_norm_avg = compute_psi_j_set_using_data(samples, n_player,
                                                                                             pmax,
                                                                                             np.array(theta),
                                                                                             squaring_param)

    mat_Psi_s = np.mean(psi_j_sym_set, axis=0)  # 1/N(\sum_{i=1}^{N}psi_j)#
    mat_tilde_Psi_s = np.mean(psi2_j_sym_set, axis=0)

    assert issymmetric(mat_Psi_s) == True
    assert issymmetric(mat_tilde_Psi_s) == True

    # ASL loss
    loss_ASL = (0.5 * alpha * (np.linalg.norm(beth, 'fro') ** 2) - np.matrix.trace(mat_Psi_s @ beth)
                + 0.5 * alpha * (np.linalg.norm(tilde_beth, 'fro') ** 2) + np.matrix.trace(mat_tilde_Psi_s @ tilde_beth)
                + vec_v_j_norm_avg)

    return loss_ASL, mat_Psi_s, mat_tilde_Psi_s, vec_v_j_norm_avg

def normalize_each_variable(beth, tilde_beth, xi, tilde_xi, lambdas):

    beth_nor = beth / np.linalg.norm(beth, 'fro')
    tilde_beth_nor = tilde_beth / np.linalg.norm(tilde_beth, 'fro')
    xi_nor = xi / np.linalg.norm(xi, 'fro')
    tilde_xi_nor = tilde_xi / np.linalg.norm(tilde_xi, 'fro')
    lambdas_nor = lambdas / np.linalg.norm(lambdas, 2)

    return beth_nor, tilde_beth_nor, xi_nor, tilde_xi_nor, lambdas_nor


def callback(theta):
    """Store input and current time."""
    return theta, time.time()

def compute_psi_j_set_using_data(samples, n_player, pmax, theta_t, squaring_param):
    psi_j_set, psi2_j_set = [], []
    psi_j_sym_set, psi2_j_sym_set = [], []
    vec_v_j_norm_set = []
    for p1_hat, p2_hat, xi_hat in samples:
        # Check if the FOP is augmented
        # print(p1_hat, p2_hat, xi_hat)
        x_hat = np.array([p1_hat, p2_hat])
        try:
            x_opt = FOP_game(n_player, pmax, theta_t, p1_hat, p2_hat, xi_hat, squaring_param)
            # print(x_opt)
            # print('distance between x and \hat{x} is', np.linalg.norm(x_opt - x_hat))
        except TypeError:
            print('there is sth wrong with the gradient computation..., please check them')


        phi_j, _, _ = phi_func((p1_hat, p2_hat), xi_hat)

        # n_player = 2
        each_theta_len = int(len(theta_t) / n_player)
        I_n = np.ones(each_theta_len)
        temp_m = np.kron(I_n, (x_opt - x_hat))

        vec_v_j = phi_j * temp_m.reshape(-1, order='F')# * means element-size multiplication
        # print(vec_v_j)
        # print(vec_v_j[0])
        psi_j = np.array([[vec_v_j[0], 2 * vec_v_j[1]], [2 * vec_v_j[4], vec_v_j[5]]]) ## be careful! need to check again!!!
        psi2_j = np.array([[vec_v_j[2], vec_v_j[3]], [vec_v_j[6], vec_v_j[7]]])

        psi_j_sym = np.array([[vec_v_j[0], vec_v_j[1] + vec_v_j[4]], [vec_v_j[1] + vec_v_j[4], vec_v_j[5]]])
        psi2_j_sym = np.array([[vec_v_j[2], (vec_v_j[3] + vec_v_j[6])/2], [(vec_v_j[3] + vec_v_j[6])/2, vec_v_j[7]]])

        psi_j_set.append(psi_j)
        psi2_j_set.append(psi2_j)

        psi_j_sym_set.append(psi_j_sym)
        psi2_j_sym_set.append(psi2_j_sym)

        vec_v_j_norm_set.append(np.linalg.norm(vec_v_j, 2))

    vec_v_j_norm_avg = np.mean(vec_v_j_norm_set)

    return  psi_j_sym_set, psi2_j_sym_set, psi_j_set, psi2_j_set, vec_v_j_norm_avg

def zero_to_nan(array):
    array[array == 0] = np.NaN
    return array