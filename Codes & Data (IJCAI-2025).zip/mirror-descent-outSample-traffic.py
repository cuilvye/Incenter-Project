#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import fsolve
import time, argparse
import os
import pickle
import networkx as nx

from utils_traffic import frank_wolfe_outOf_sample
from utils_traffic import generate_arcs_from_network
from utils_traffic import add_costs_flows_to_dict_arcs


args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/traffic/', help = 'the root of data', type = str)
# args_parser.add_argument('--u_type', default = 'linear', help = 'the type of demand function', type = str）
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args_parser.add_argument('--r', default = 0, help = 'random index', type = int)
# args_parser.add_argument('--pmax', default = 8, help = 'upper bound of price', type = float)
args_parser.add_argument('--squaring', default = 10, help = 'random index', type = float)
args_parser.add_argument('--Epoch', default = 300, help = 'maximum of iterations in our algorithm', type = int)
args_parser.add_argument('--step', default = 'standard', help = 'the descent update method', type = str)
args_parser.add_argument('--regularizer', default = 'L2_squared', help = 'the regularizer term in our loss', type = str)
args = args_parser.parse_args()

file_path = args.file_root
# utility_type = args.u_type
N_train = args.N
# pmax = args.pmax
r_idx = args.r

squaring_param = args.squaring
if squaring_param == 1.0:
    squaring_param = int(squaring_param)

epoch_max = args.Epoch
step = args.step #'exponentiated'
regularizer = args.regularizer

Theta_true_file = pd.read_csv(os.path.join(file_path, 'thetas-true.csv'))
theta_true = np.array(Theta_true_file[['theta_0', 'theta_1']])
Theta_true = theta_true.flatten() #a=matrix([[1, 2],[3, 4]]), a.flatten() = matrix([[1, 2, 3, 4]])

np_capacities = np.array(Theta_true_file['capacity'])

dataset_test_df = pd.read_csv(file_path + "dataset_test_Flow_N_"+str(N_train)+".csv", header = 0)
# dataset_test_df = pd.read_csv(file_path + 'dataset_test_u_'+ utility_type +'_N_' + str(N_train) + '_firstOrder.csv')
dataset_test = np.array(dataset_test_df)
# dataset_test = np.array(dataset_test_df)

n_arcs = dataset_test.shape[1]
n_theta = 2

pmax = np.max(dataset_test)
pmin = np.min(dataset_test)

res_path  = './EstimatedThetas/traffic/' #+ step + '_' + regularizer
# np.save('./results/'+utility_type+'_ASL_MD_N_'+str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy', np.array(callback_results, dtype=object), allow_pickle=True)

with open(file_path + 'dataset_test_demands_N_'+ str(N_train) +'.pkl', 'rb') as f:
    demand_data = pickle.load(f)

# print(len(demand_data))
# print(demand_data)
# print(afff)

# n_runs = 5
runs_error_exact = []
# runs_error_approx1, runs_error_approx2, runs_error_approx3, runs_error_approx4 = [], [], [], []
# epsilon_1 = 1e-8
# epsilon_2 = 1e-6
# epsilon_3 = 1e-4
# epsilon_4 = 1e-3
colors = ['#e41a1c', '#377eb8', '#4daf4a', '#984ea3', '#ff7f00', '#808080',
          '#a65628', '#FFD700']
Theta_norm = Theta_true / np.linalg.norm(Theta_true)

################################### Read in the arc file #################################
file_path = "./data/traffic/SiouxFalls/"
file_net = file_path + "SiouxFalls_net.tntp"
dict_arcs = generate_arcs_from_network(file_net)
################################### Read in the true costs ##################################
file_flow = file_path + "SiouxFalls_flow.tntp"
dict_arcs, tot_cost, test_cost = add_costs_flows_to_dict_arcs(dict_arcs, file_flow)
for key, arc in dict_arcs.items():
    print(key, arc)
print('computed cost using cost function is :', tot_cost)
print('the actual cost is:', test_cost)
############################################################# Generate the simulated data #############################################################
# Create a directed graph
G = nx.DiGraph()
for idx, arc in enumerate(dict_arcs.values()):
    arc.obsflow = arc.trueflow
    G.add_edge(arc.start_node, arc.end_node, index=idx)

for r in [r_idx]: #[0, 4]
    thetas_iter_name = res_path + '/prior1_thetas_run_' + str(r) + '_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy'
    print('loading ' + thetas_iter_name)
    callback_results = np.load(thetas_iter_name, allow_pickle=True)
    ##### plot all theta_t ######
    err_x_T = []
    # err_x_T, err_x_T_approx1, err_x_T_approx2, err_x_T_approx3, err_x_T_approx4 = [], [], [], [], []
    time_s = time.time()
    for i in range(0, len(callback_results)):#
        theta_t = callback_results[i][0]

        theta_t_norm = theta_t/np.linalg.norm(theta_t)
        v_arcs_i = []
        for idx, arc in enumerate(dict_arcs.values()):
            arc.thetas_estimated = (theta_t_norm[2 * idx], theta_t_norm[2 * idx + 1])
            v_arcs_i.append(arc)

        res_test = []
        # res_test_approx1, res_test_approx2, res_test_approx3, res_test_approx4= [], [], [], []
        for j in range(0, dataset_test.shape[0]):
            print('i is {}, j is {}'.format(i, j))

            x_hat = dataset_test[j]
            #### the reason that why there is a line is because when we compute the equilibrium, we did not use the theta_t ####
            conv_tol, flow_solution = frank_wolfe_outOf_sample(G, v_arcs_i, demand_data, j)

            p_solution = flow_solution
            # p_solution = firstOrderEq_givenXi_linearDemand(xi_hat, theta_1, theta_2, pmax)
            # p_solution_approx1 = ProjectAlgEq_givenXi_linearDemand(xi_hat, theta_1, theta_2, pmax, 1000, 0.01, epsilon_1)
            # p_solution_approx2 = ProjectAlgEq_givenXi_linearDemand(xi_hat, theta_1, theta_2, pmax, 1000,
            #                                                            0.01, epsilon_2)
            # p_solution_approx3 = ProjectAlgEq_givenXi_linearDemand(xi_hat, theta_1, theta_2, pmax, 1000,
            #                                                            0.01, epsilon_3)
            # p_solution_approx4 = ProjectAlgEq_givenXi_linearDemand(xi_hat, theta_1, theta_2, pmax, 1000,
            #                                                            0.01, epsilon_4)
            # p_solution_approximate_2 = find_bertrand_nash_equilibrium(xi_hat, theta_t[:4], theta_t[4:], pmax, 1000, 0.01, 0.001)
            print('Exact solution is {}'.format(p_solution))
            # print("Approximate {}-solution is {}".format(epsilon_1, p_solution_approx1))
            # print("Approximate {}-solution is {}".format(epsilon_2, p_solution_approx2))
            # print("Approximate {}-solution is {}".format(epsilon_3, p_solution_approx3))
            # print("Approximate {}-solution is {}".format(epsilon_4, p_solution_approx4))

            res_test.append(np.linalg.norm(p_solution - x_hat))
            # res_test_approx1.append(np.linalg.norm(p_solution_approx1 - p_hat))
            # res_test_approx2.append(np.linalg.norm(p_solution_approx2 - p_hat))
            # res_test_approx3.append(np.linalg.norm(p_solution_approx3 - p_hat))
            # res_test_approx4.append(np.linalg.norm(p_solution_approx4 - p_hat))

        # print(difference_set_test)
        err_x_T.append(np.mean(res_test))
        # err_x_T_approx1.append(np.mean(res_test_approx1))
        # err_x_T_approx2.append(np.mean(res_test_approx2))
        # err_x_T_approx3.append(np.mean(res_test_approx3))
        # err_x_T_approx4.append(np.mean(res_test_approx4))

    #### save each error list since it is spending ####
    exact_name = res_path + '/Prior1_run_'+str(r)+'_PredictError_Exact_' + str(r) + '_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy'
    np.save(exact_name, np.array(err_x_T, dtype=object), allow_pickle=True)
    # approx1_name = res_path + '/Prior1_run_' + str(r) + '_PredictError_Approx_'+str(epsilon_1)+'_'+utility_type+'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy'
    # np.save(approx1_name, np.array(err_x_T_approx1, dtype=object), allow_pickle=True)
    # approx2_name = res_path + '/Prior1_run_' + str(r) + '_PredictError_Approx_'+str(epsilon_2)+'_'+utility_type+'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy'
    # np.save(approx2_name, np.array(err_x_T_approx2, dtype=object), allow_pickle=True)
    # approx3_name = res_path + '/Prior1_run_' + str(r) + '_PredictError_Approx_'+str(epsilon_3)+'_'+utility_type+'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train)+ '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy'
    # np.save(approx3_name, np.array(err_x_T_approx3, dtype=object), allow_pickle=True)
    # approx4_name = res_path + '/Prior1_run_' + str(r) + '_PredictError_Approx_'+str(epsilon_4)+'_'+utility_type+'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy'
    # np.save(approx4_name, np.array(err_x_T_approx4, dtype=object), allow_pickle=True)

    print('Time spent is {} minutes'.format((time.time() - time_s)/60))
    runs_error_exact.append(err_x_T)
    # runs_error_approx1.append(err_x_T_approx1)
    # runs_error_approx2.append(err_x_T_approx2)
    # runs_error_approx3.append(err_x_T_approx3)
    # runs_error_approx4.append(err_x_T_approx4)

    # plot for each  #
    plt.rcParams["mathtext.fontset"] = 'cm'
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]
    plt.figure()
    plt.plot(range(1, len(err_x_T) + 1), err_x_T, label='FirstOrder', color=colors[0], linewidth=2)
    # plt.plot(range(1, len(err_x_T_approx1) + 1), err_x_T_approx1, label=str(epsilon_1)+'-Approx-Eq', color=colors[1], linewidth=2)
    # plt.plot(range(1, len(err_x_T_approx2) + 1), err_x_T_approx2, label=str(epsilon_2)+'-Approx-Eq', color=colors[2], linewidth=2)
    # plt.plot(range(1, len(err_x_T_approx3) + 1), err_x_T_approx3, label=str(epsilon_3)+'-Approx-Eq', color=colors[3], linewidth=2)
    # plt.plot(range(1, len(err_x_T_approx4) + 1), err_x_T_approx4, label=str(epsilon_4)+'-Approx-Eq', color=colors[4], linewidth=2)

    plt.ylabel(
        r'$\| x_{\mathrm{esti}} - x_{\mathrm{true}} \|_2$', fontsize=18
    )
    plt.xlabel(r'Iterations', fontsize=14)
    plt.xlim(0, len(err_x_T))
    # plt.ylim(0, 7)
    plt.grid(visible=True)
    plt.legend(fontsize='16', loc='lower right')
    plt.tight_layout()
    # saving the figure.
    plt.savefig(res_path + '/Prior1_PredictionError_run_' + str(r) + '_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max) +'.png')
    plt.show()
    plt.close()



