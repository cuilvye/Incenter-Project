#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""
import numpy as np
import networkx as nx
from scipy.optimize import brentq  # for root finding
from collections import defaultdict

class Arc:
    def __init__(self, start_node, end_node, capacity, theta_0, theta_1, trueflow=0, obsflow=0,  thetas_estimated=(0, 0)):
        self.start_node = start_node
        self.end_node = end_node
        self.capacity = capacity
        # self.theta_0 = freeflowtime
        self.theta_0 = theta_0
        self.theta_1 = theta_1
        self.trueflow = trueflow
        self.obsflow = obsflow
        # self.thetas_true = thetas_true
        self.thetas_estimated = thetas_estimated

    def __repr__(self):
        return f"Arc({self.start_node}, {self.end_node}, {self.capacity}, {self.theta_0}, {self.theta_1}, {self.trueflow}, {self.obsflow})"

def read_demands_from_file(file_path):
    # Initialize an empty dictionary to store the demands
    demands = {}
    # Open the file and read it line by line #
    with open(file_path, 'r') as file:
        s = 0
        for line in file:
            if "Origin" in line:
                s = int(line.split()[1])
            else:
                pairs = line.split(";")
                for pair in pairs:
                    if pair.strip() and ":" in pair:  # Check if the pair is not empty or just a newline
                        pair_vals = pair.split(":")
                        t = int(pair_vals[0])
                        demand = float(pair_vals[1])
                        demands[(s, t)] = demand
    return demands

def generate_arcs_from_network(file_path):
    # Initialize an empty dictionary to store the arcs
    arcs = {}
    # Open the file and read it line by line
    with open(file_path, 'r') as file:
        in_header = True
        for line in file:
            if in_header:
                if "Init node" in line:
                    in_header = False
                continue
            # Check for lines that are not valid data rows
            if line.startswith("~") or line.strip() == "":
                continue
            vals = line.split()
            # Ensure the line contains valid data
            if len(vals) < 5:
                continue
            start_node = int(vals[0])
            end_node = int(vals[1])
            capacity = float(vals[2])
            free_flow_time = float(vals[4])
            theta_0 = free_flow_time
            assert 0.15 == float(vals[5])
            theta_1 = free_flow_time * float(vals[5])

            arcs[(start_node, end_node)] = Arc(start_node, end_node, capacity, theta_0, theta_1)

    return arcs

def add_costs_flows_to_dict_arcs(dict_arcs, file_path):
    ix, test_cost = 0, 0
    with open(file_path, 'r') as file:
        for line in file:
            ix += 1
            if ix == 1:
                continue

            vals = line.split()
            start_node = int(vals[0])
            end_node = int(vals[1])
            trueflow = float(vals[2])
            cost = float(vals[3])

            if (start_node, end_node) in dict_arcs:
                dict_arcs[(start_node, end_node)].trueflow = trueflow
            test_cost += cost

    # Calculate the total cost using the bpacost function
    tot_cost = sum(bpacost_flow_arc(arc.trueflow, arc) for arc in dict_arcs.values())
    # print(tot_cost)
    # Verify the total cost
    assert abs(tot_cost - test_cost) <= 1e-8, "The total cost does not match the test cost!"

    return dict_arcs, tot_cost, test_cost

# def poly_eval(coeffs, pt):
#     return sum(coeff * pt**i for i, coeff in enumerate(coeffs))
#
# def poly_eval_float(coeffs, pt):
#     return sum(coeff * pt**i for i, coeff in enumerate(coeffs))

def bpacost(flow, capacity, theta_0, theta_1):
    # print('freeflowtime is {}'.format(freeflowtime))
    # return freeflowtime * (1 + 0.15 * (flow / capacity)**4)
    return theta_0 + theta_1 * (flow /capacity)**4

def bpacost_flow_arc(flow, arc):
    return bpacost(flow, arc.capacity, arc.theta_0, arc.theta_1)

def bpacost_flow_arc_outOf_Sample(flow, arc):
        return bpacost(flow, arc.capacity, arc.thetas_estimated[0], arc.thetas_estimated[1])
    # return arc.theta_0 + arc.theta_1 * (flow / arc.capacity)**4

def bpacost_arc(arc):
    return bpacost(arc.obsflow, arc.capacity, arc.theta_0, arc.theta_1)

def bpacost_arc_outOf_Sample(arc):
    return bpacost(arc.obsflow, arc.capacity, arc.thetas_estimated[0], arc.thetas_estimated[1])

# def bpacost_arc_theta(arc):
#     # print('freeflowtime is {}'.format(freeflowtime))
#     return arc.theta_0 + arc.theta_1 * (arc.flow / arc.capacity)**4

# def derivcost(flow, capacity, freeflowtime):
#     return freeflowtime / capacity * 0.15 * 4 * (flow / capacity)**3
#
# def derivcost_flow_arc(flow, arc):
#     return derivcost(flow, arc.capacity, arc.freeflowtime)
#
# def derivcost_arc(arc):
#     return derivcost(arc.obsflow, arc.capacity, arc.freeflowtime)

def frank_wolfe(G, v_arcs, demand_data, idx, TOL=1e-4, MAX_ITERS=100):
    flows = np.array([arc.obsflow for arc in v_arcs], dtype=float)
    #### costs here should be different depends on different cost function
    costs = np.array([bpacost_arc(arc) for arc in v_arcs], dtype=float)
    trace = []

    for iter in range(MAX_ITERS):
        flow_dict = {(od[0], od[1]): 0.0 for od in demand_data.keys()}
        for odpair, demands in demand_data.items():
            path = nx.shortest_path(G, source=odpair[0], target=odpair[1], weight=lambda u, v, d: costs[d['index']])
            for u, v in zip(path[:-1], path[1:]):
                if (u, v) not in flow_dict:
                    flow_dict[(u, v)] = demands[idx]
                else:
                    flow_dict[(u, v)] += demands[idx]

        d = np.array([flow_dict.get((arc.start_node, arc.end_node), 0.0) for arc in v_arcs], dtype=float)
        if iter == 0:
            flows = d
            costs = np.array([bpacost_flow_arc(flows[ix], arc) for ix, arc in enumerate(v_arcs)], dtype=float)
            continue

        assert np.dot(costs, d) <= np.dot(flows, costs)
        d -= flows

        def deriv_fun(alpha):
            return sum(bpacost_flow_arc(flows[ix] + alpha * d[ix], arc) * d[ix] for ix, arc in enumerate(v_arcs))

        if deriv_fun(0) >= 0:
            alpha = 0
        elif deriv_fun(1) <= 0:
            alpha = 1
        else:
            alpha = brentq(deriv_fun, 0, 1)

        converge_dist = alpha * np.linalg.norm(d) / np.linalg.norm(flows)
        flows += alpha * d
        trace.append(converge_dist)

        if iter > 1 and converge_dist <= TOL:
            break
        else:
            costs = np.array([bpacost_flow_arc(flows[ix], arc) for ix, arc in enumerate(v_arcs)], dtype=float)

    return trace[-1], flows


def frank_wolfe_outOf_sample(G, v_arcs, demand_data, idx, TOL=1e-4, MAX_ITERS=100):
    flows = np.array([arc.obsflow for arc in v_arcs], dtype=float)
    #### costs here should be different depends on different cost function
    costs = np.array([bpacost_arc_outOf_Sample(arc) for arc in v_arcs], dtype=float)
    trace = []

    for iter in range(MAX_ITERS):
        flow_dict = {(od[0], od[1]): 0.0 for od in demand_data.keys()}
        for odpair, demands in demand_data.items():
            path = nx.shortest_path(G, source=odpair[0], target=odpair[1], weight=lambda u, v, d: costs[d['index']])
            for u, v in zip(path[:-1], path[1:]):
                if (u, v) not in flow_dict:
                    flow_dict[(u, v)] = demands[idx]
                else:
                    flow_dict[(u, v)] += demands[idx]

        d = np.array([flow_dict.get((arc.start_node, arc.end_node), 0.0) for arc in v_arcs], dtype=float)
        if iter == 0:
            flows = d
            costs = np.array([bpacost_flow_arc_outOf_Sample(flows[ix], arc) for ix, arc in enumerate(v_arcs)], dtype=float)
            continue

        assert np.dot(costs, d) <= np.dot(flows, costs)
        d -= flows

        def deriv_fun(alpha):
            return sum(bpacost_flow_arc_outOf_Sample(flows[ix] + alpha * d[ix], arc) * d[ix] for ix, arc in enumerate(v_arcs))

        if deriv_fun(0) >= 0:
            alpha = 0
        elif deriv_fun(1) <= 0:
            alpha = 1
        else:
            alpha = brentq(deriv_fun, 0, 1)

        converge_dist = alpha * np.linalg.norm(d) / np.linalg.norm(flows)
        flows += alpha * d
        trace.append(converge_dist)

        if iter > 1 and converge_dist <= TOL:
            break
        else:
            costs = np.array([bpacost_flow_arc_outOf_Sample(flows[ix], arc) for ix, arc in enumerate(v_arcs)], dtype=float)

    return trace[-1], flows


def generate_user_equilibrium_data(numData, dict_arcs, dict_demands, sigma, G, v_arcs):

    np.random.seed(0)

    flow_data = np.zeros((numData, len(dict_arcs)))
    demand_data = defaultdict(list)

    for iRun in range(numData):
        # Perturb the demand_data
        for odpair in dict_demands.keys():
            perturbed_demand = dict_demands[odpair] * (1 + sigma * np.random.rand())
            demand_data[odpair].append(perturbed_demand)

        # Solve using FW and record (assuming frank_wolfe function is defined elsewhere)
        conv_tol, flow_solution = frank_wolfe(G, v_arcs, demand_data, iRun)
        flow_data[iRun, :] = flow_solution  # each row is a sample

    return flow_data, demand_data

