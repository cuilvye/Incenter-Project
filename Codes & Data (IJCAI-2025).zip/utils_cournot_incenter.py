#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

import numpy as np
import gurobipy as gp

def check_Theta(Theta):
    """Check if Theta is valid."""
    if Theta not in [None, 'nonnegative']:
        raise Exception(
            'Invalid Theta. Accepted values are: None (default)'
            'and \'nonnegative\'.'
        )

def check_regularizer(regularizer):
    """Check if regularizer is valid."""
    if regularizer not in ['L2_squared', 'L1']:
        raise Exception(
            'Invalid regularizer. Accepted values are:'
            ' \'L2_squared\' (default) and \'L1\'.'
        )

def check_reg_parameter(reg_param):
    """Check if reg_param is valid."""
    if reg_param < 0:
        raise Exception('reg_param must be nonnegative.')


def warning_theta_hat_reg_param(theta_hat, reg_param):
    """Warn user theta_hat is not used when reg_param=0."""
    if (theta_hat is not None) and (reg_param == 0):
        warnings.warn('theta_hat is not used when reg_param=0.')

def phi_func_Cournot(qstar_j, xi_j):
    q1, q2, q3 = qstar_j

    phi_1 = [-(q2 + q3 + 2 * q1), 1, xi_j, - q1, 0, 0]
    phi_2 = [-(q1 + q3 + 2 * q2), 1, xi_j, 0, - q2, 0]
    phi_3 = [-(q1 + q2 + 2 * q3), 1, xi_j, 0, 0, - q3]

    # phi_j_set = [phi_1, phi_2,  phi_3]#
    phi_j = phi_1 + phi_2
    phi_j = phi_j + phi_3
    assert len(phi_j) == len(phi_1) * 3

    return np.array(phi_j), np.array(phi_1), np.array(phi_2), np.array(phi_3)

def phi_func_Cournot_five_firms(qstar_j, xi_j):
    q1, q2, q3, q4, q5 = qstar_j

    phi_1 = [-(q2 + q3 + q4 + q5 + 2 * q1), 1, xi_j, - q1, 0, 0, 0, 0]
    phi_2 = [-(q1 + q3 + q4 + q5 + 2 * q2), 1, xi_j, 0, - q2, 0, 0, 0]
    phi_3 = [-(q1 + q2 + q4 + q5 + 2 * q3), 1, xi_j, 0, 0, - q3, 0, 0]
    phi_4 = [-(q1 + q2 + q3 + q5 + 2 * q4), 1, xi_j, 0, 0, 0, -q4,  0]
    phi_5 = [-(q1 + q2 + q3 + q4 + 2 * q5), 1, xi_j, 0, 0, 0, 0, - q5]

    # phi_j_set = [phi_1, phi_2,  phi_3]
    phi_j = phi_1 + phi_2
    phi_j = phi_j + phi_3
    phi_j = phi_j + phi_4
    phi_j = phi_j + phi_5
    assert len(phi_j) == len(phi_1) * 5

    return np.array(phi_j), np.array(phi_1), np.array(phi_2), np.array(phi_3),  np.array(phi_4), np.array(phi_5)

def FOP_game_Cournot(n_player, pmax, theta, data_j, squaring_param, gurobi_params=None):
    if n_player == 3:
        q1_hat, q2_hat, q3_hat, xi_hat = data_j
        qstar_j = (q1_hat, q2_hat, q3_hat)
        x_hat_j = np.array([q1_hat, q2_hat, q3_hat])
        phi_j, phi_j_1, phi_j_2, phi_j_3 = phi_func_Cournot(qstar_j, xi_hat)
    elif n_player == 5:
        q1_hat, q2_hat, q3_hat, q4_hat, q5_hat, xi_hat = data_j
        qstar_j = (q1_hat, q2_hat, q3_hat, q4_hat, q5_hat,)
        x_hat_j = np.array([q1_hat, q2_hat, q3_hat, q4_hat, q5_hat])
        phi_j, phi_j_1, phi_j_2, phi_j_3, phi_j_4, phi_j_5  = phi_func_Cournot_five_firms(qstar_j, xi_hat)


    assert phi_j.shape[0] == len(theta) * n_player
    mdl = gp.Model('FOP-Game-Cournot')
    mdl.setParam('OutputFlag', 0) ### should see the method

    x = mdl.addVars(n_player, vtype=gp.GRB.CONTINUOUS, name='x')
    phi_j_reshape = phi_j.reshape(len(theta), -1)

    res_1_phi = []
    for i in range(n_player):
        res_1_phi.append(np.inner(theta, phi_j_reshape[:, i]))

    ### Need to be careful for res_2_phi in the Cournot Games, be careful in this place ###
    res_2_phi = []
    for i in range(n_player):
        res_2_phi.append(np.inner(phi_j_reshape[:, i], phi_j_reshape[:, i]))# np.linalg.norm(phi_j_reshape[:, i]
        # print(res_2_phi)

    objective_1 = gp.quicksum(res_1_phi[i] * (x[i] - x_hat_j[i]) for i in range(n_player))

    objective_2 = gp.quicksum(res_2_phi[i] * (x[i] - x_hat_j[i]) * (x[i] - x_hat_j[i]) for i in range(n_player))
    # objective_2 = gp.norm(gp.quicksum(phi_j_reshape[:, i] * (x[i] - x_hat_j[i]) for i in range(n_player)), 2)
    # objective_2_approxi = gp.quicksum((2 * res_2_phi[i] * x_hat_j[i] - 1) * x[i] for i in range(n_player))

    mdl.setObjective(objective_1 + squaring_param * objective_2, gp.GRB.MAXIMIZE) #0.001 *

    mdl.addConstrs(x[i] >= 0 for i in range(n_player)) ### the constraints to equilibrium prices
    mdl.addConstrs(x[i] <= pmax for i in range(n_player))

    if gurobi_params is not None:
        for param, value in gurobi_params:
            mdl.setParam(param, value)

    # mdl.setParam(gp.GRB.Param.InfUnbdInfo, 1)
    mdl.optimize()
    # print(mdl.get('GRB_IntAttr_Status'))
    # print("status", mdl.Status)
    if mdl.status == 4:
        print("The model is infeasible or Unbounded; computing IIS")
        # mdl.computeIIS() #Cannot compute IIS on a feasible model
        # mdl.write("model.ilp")
        # print("IIS written to 'model.ilp'")
        # print("The model is unbounded.")
        print(mdl.getParamInfo(gp.GRB.Param.InfUnbdInfo))
        unbd_ray = mdl.getAttr("UnbdRay", x)
        print("Unbounded ray direction for x^j:", unbd_ray)

    # print(mdl.status)
    # print(afffff)
    if mdl.status == 2:
        x_opt = np.array([x[k].X for k in range(n_player)])
        # print(x_opt)
    elif mdl.status == 9:
        # Time limit reched. Return vector a all ones
        x_opt = np.ones(n_player)
        assert 1 == 0
    else:
        raise Exception(
            f'Optimal solution not found. Gurobi status code = {mdl.status}.'
        )
    # print(x_opt)
    # help(mdl)
    # print(x_opt)
    # print(mdl.getParamInfo('Method'))
    # #('Method', <class 'int'>, -1, -1, 5, -1) FOR QP, the default method is Method = 2 (barrier)
    # print(afffffff)
    return x_opt

def ASL_Cournot(
    theta,
    dataset,
    n_player,
    pmax,
    regularizer='L2_squared',
    reg_param=0,
    squaring_param = 1,
    theta_hat=None,
    ):
    """
    Evaluate Augmented Suboptimality loss.

    Parameters
    ----------
    theta : 1D ndarray
        Cost vector.
    dataset : array-like, shape (n_samples, n_features), each row is that  p1_j, p2_j, xi_j
    regularizer : {'L2_squared', 'L1'}, optional
        Type of regularization on cost vector theta. The default is
        'L2_squared'.
    reg_param : float, optional
        Nonnegative regularization parameter. The default is 0.
    theta_hat : {1D ndarray, None}, optional
        A priory belief or estimate of the true cost vector theta. The default
        is None.

    Raises
    ------
    Exception
        If invalid regularization parameter. If negative regularization
        parameter.

    Returns
    -------
    float
        Augmented suboptimality loss value.

    """
    # Check if the inputs are valid
    check_regularizer(regularizer)
    check_reg_parameter(reg_param)

    if theta_hat is None:
        theta_hat = 0

    if regularizer == 'L2_squared':
        reg_term = (reg_param/2)*np.linalg.norm(theta - theta_hat)**2
    elif regularizer == 'L1':
        reg_term = reg_param*np.linalg.norm(theta - theta_hat, 1)

    N = len(dataset)
    loss = 0
    # for i in range(N):
    #     s_hat, x_hat = dataset[i]
    #     x = FOP_aug(theta, s_hat, x_hat)
    #     phi_diff = phi(s_hat, x_hat) - phi(s_hat, x)
    #     try:
    #         dist = dist_func(x_hat, x)
    #     except TypeError:
    #         dist = dist_func(x_hat, x, s_hat)
    #
    #     loss += theta @ phi_diff + dist
    for i in range(N):
        # Check if the FOP is augmented
        q1_hat, q2_hat, q3_hat, xi_hat = dataset[i]
        # print(p1_hat, p2_hat, xi_hat)
        x_hat = np.array([q1_hat, q2_hat, q3_hat])

        # solve a approximate solution to the original Incenter-loss-term
        data_j = (q1_hat, q2_hat, q3_hat, xi_hat)
        x_opt = FOP_game_Cournot(n_player, pmax, theta, data_j, squaring_param)

        phi_j, _, _, _ = phi_func_Cournot((q1_hat, q2_hat, q3_hat), xi_hat)
        # n_player = 2
        each_theta_len = len(theta)
        I_n = np.ones(each_theta_len)
        temp_m = np.kron(I_n, (x_opt - x_hat))
        loss_Euclidean = np.linalg.norm(phi_j * temp_m.reshape(-1, order='F'))# * means element-size multiplication
        # loss_Euclidean_squaring = loss_Euclidean ** 2


        phi_j_reshape = phi_j.reshape(each_theta_len, -1)  # each_theta_len * n_Player
        assert phi_j_reshape.shape[0] == each_theta_len
        res_1_phi = []
        for i in range(n_player):
            res_1_phi.append(np.inner(theta, phi_j_reshape[:, i]))
        loss_linear = np.inner(res_1_phi, (x_opt - x_hat))

        loss = loss + loss_Euclidean + loss_linear
        # loss = loss + loss_Euclidean_squaring * squaring_param + loss_linear

    return reg_term + (1/N)*loss


def FOP_game_Cournot_Plus(Theta_True, n_player, pmax, theta, data_j, squaring_param, gurobi_params=None):

    q1_hat, q2_hat, q3_hat, xi_hat = data_j

    mdl = gp.Model('FOP-Game-Cournot')
    mdl.setParam('OutputFlag', 0) ### should see the method

    x = mdl.addVars(n_player, vtype=gp.GRB.CONTINUOUS, name='x')

    phi_j, phi_j_1, phi_j_2, phi_j_3 = phi_func_Cournot((q1_hat, q2_hat, q3_hat), xi_hat)
    assert phi_j.shape[0] == len(theta) * n_player
    phi_j_reshape = phi_j.reshape(len(theta), -1)

    res_1_phi = []
    for i in range(n_player):
        res_1_phi.append(np.inner(theta, phi_j_reshape[:, i]))

    x_hat_j = np.array([q1_hat, q2_hat, q3_hat])

    ### Need to be careful for res_2_phi in the Cournot Games, be careful in this place ###
    res_2_phi = []
    for i in range(n_player):
        res_2_phi.append(np.inner(phi_j_reshape[:, i], phi_j_reshape[:, i]))# np.linalg.norm(phi_j_reshape[:, i]
        # print(res_2_phi)

    objective_1 = gp.quicksum(res_1_phi[i] * (x[i] - x_hat_j[i]) for i in range(n_player))
    objective_2 = gp.quicksum(res_2_phi[i] * (x[i] - x_hat_j[i]) * (x[i] - x_hat_j[i]) for i in range(n_player))
    # objective_2 = gp.norm(gp.quicksum(phi_j_reshape[:, i] * (x[i] - x_hat_j[i]) for i in range(n_player)), 2)
    # objective_2_approxi = gp.quicksum((2 * res_2_phi[i] * x_hat_j[i] - 1) * x[i] for i in range(n_player))

    ### New Loss ###
    phi_x_var_1 = [-(x[1] + x[2] + 2 * x[0]), 1, xi_hat, - x[0], 0, 0]
    phi_x_var_2 = [-(x[0] + x[2] + 2 * x[1]), 1, xi_hat, 0, - x[1], 0]
    phi_x_var_3 = [-(x[0] + x[1] + 2 * x[2]), 1, xi_hat, 0, 0, - x[2]]
    objective_3_1 = gp.quicksum(Theta_True[i] * phi_x_var_1[i] for i in range(n_player))
    objective_3_2 = gp.quicksum(Theta_True[i] * phi_x_var_2[i] for i in range(n_player))
    objective_3_3 = gp.quicksum(Theta_True[i] * phi_x_var_3[i] for i in range(n_player))
    objective_3 = objective_3_1 * objective_3_1 + objective_3_2 * objective_3_2 + objective_3_3 * objective_3_3

    objective_4_1 = gp.quicksum(theta[i] * phi_x_var_1[i] for i in range(n_player))
    objective_4_2 = gp.quicksum(theta[i] * phi_x_var_2[i] for i in range(n_player))
    objective_4_3 = gp.quicksum(theta[i] * phi_x_var_3[i] for i in range(n_player))
    objective_4 = objective_4_1 * objective_4_1 + objective_4_2 * objective_4_2 + objective_4_3 * objective_4_3

    # the following has nothing to do with x
    # objective_5_1 = gp.quicksum(theta[i] * phi_j_1[i] for i in range(n_player))
    # objective_5_2 = gp.quicksum(theta[i] * phi_j_2[i] for i in range(n_player))
    # objective_5_3 = gp.quicksum(theta[i] * phi_j_3[i] for i in range(n_player))
    # objective_5 = objective_5_1 * objective_5_1 + objective_5_2 * objective_5_2 + objective_5_3 * objective_5_3

    obj = objective_1 + squaring_param * objective_2 + objective_3 - 2 * objective_4
    mdl.setObjective(obj, gp.GRB.MAXIMIZE) #0.001 *

    mdl.addConstrs(x[i] >= 0 for i in range(n_player)) ### the constraints to equilibrium prices
    mdl.addConstrs(x[i] <= pmax for i in range(n_player))

    if gurobi_params is not None:
        for param, value in gurobi_params:
            mdl.setParam(param, value)

    # mdl.setParam(gp.GRB.Param.InfUnbdInfo, 1)
    mdl.setParam('NonConvex', 2)
    mdl.optimize()
    # print(mdl.get('GRB_IntAttr_Status'))
    # print("status", mdl.Status)
    if mdl.status == 4:
        print("The model is infeasible or Unbounded; computing IIS")
        # mdl.computeIIS() #Cannot compute IIS on a feasible model
        # mdl.write("model.ilp")
        # print("IIS written to 'model.ilp'")
        # print("The model is unbounded.")
        print(mdl.getParamInfo(gp.GRB.Param.InfUnbdInfo))
        unbd_ray = mdl.getAttr("UnbdRay", x)
        print("Unbounded ray direction for x^j:", unbd_ray)

    # print(mdl.status)
    # print(afffff)
    if mdl.status == 2:
        x_opt = np.array([x[k].X for k in range(n_player)])
        # print(x_opt)
    elif mdl.status == 9:
        # Time limit reched. Return vector a all ones
        x_opt = np.ones(n_player)
        assert 1 == 0
    else:
        raise Exception(
            f'Optimal solution not found. Gurobi status code = {mdl.status}.'
        )
    # print(x_opt)
    # help(mdl)
    # print(x_opt)
    # print(mdl.getParamInfo('Method'))
    # #('Method', <class 'int'>, -1, -1, 5, -1) FOR QP, the default method is Method = 2 (barrier)
    # print(afffffff)
    return x_opt

def ASL_Cournot_Plus(
    Theta_True,
    theta,
    dataset,
    n_player,
    pmax,
    regularizer='L2_squared',
    reg_param=0,
    squaring_param = 1,
    theta_hat=None,
    ):
    # Check if the inputs are valid
    check_regularizer(regularizer)
    check_reg_parameter(reg_param)

    if theta_hat is None:
        theta_hat = 0

    if regularizer == 'L2_squared':
        reg_term = (reg_param/2)*np.linalg.norm(theta - theta_hat)**2
    elif regularizer == 'L1':
        reg_term = reg_param*np.linalg.norm(theta - theta_hat, 1)

    N = len(dataset)
    loss = 0
    # for i in range(N):
    #     s_hat, x_hat = dataset[i]
    #     x = FOP_aug(theta, s_hat, x_hat)
    #     phi_diff = phi(s_hat, x_hat) - phi(s_hat, x)
    #     try:
    #         dist = dist_func(x_hat, x)
    #     except TypeError:
    #         dist = dist_func(x_hat, x, s_hat)
    #
    #     loss += theta @ phi_diff + dist
    for i in range(N):
        # Check if the FOP is augmented
        q1_hat, q2_hat, q3_hat, xi_hat = dataset[i]
        # print(p1_hat, p2_hat, xi_hat)
        x_hat = np.array([q1_hat, q2_hat, q3_hat])

        # solve a approximate solution to the original Incenter-loss-term
        data_j = (q1_hat, q2_hat, q3_hat, xi_hat)
        x_opt = FOP_game_Cournot_Plus(Theta_True, n_player, pmax, theta, data_j, squaring_param)

        phi_j, phi_j_1, phi_j_2, phi_j_3 = phi_func_Cournot((q1_hat, q2_hat, q3_hat), xi_hat)
        # n_player = 2
        each_theta_len = len(theta)
        I_n = np.ones(each_theta_len)
        temp_m = np.kron(I_n, (x_opt - x_hat))
        loss_Euclidean = np.linalg.norm(phi_j * temp_m.reshape(-1, order='F'))# * means element-size multiplication
        # loss_Euclidean_squaring = loss_Euclidean ** 2

        phi_j_reshape = phi_j.reshape(each_theta_len, -1)  # each_theta_len * n_Player
        assert phi_j_reshape.shape[0] == each_theta_len
        res_1_phi = []
        for i in range(n_player):
            res_1_phi.append(np.inner(theta, phi_j_reshape[:, i]))
        loss_linear = np.inner(res_1_phi, (x_opt - x_hat))

        loss = loss + loss_Euclidean + loss_linear
        # loss = loss + loss_Euclidean_squaring * squaring_param + loss_linear

        ############ new loss
        phi_x_var_1 = [-(x_opt[1] + x_opt[2] + 2 * x_opt[0]), 1, xi_hat, - x_opt[0], 0, 0]
        phi_x_var_2 = [-(x_opt[0] + x_opt[2] + 2 * x_opt[1]), 1, xi_hat, 0, - x_opt[1], 0]
        phi_x_var_3 = [-(x_opt[0] + x_opt[1] + 2 * x_opt[2]), 1, xi_hat, 0, 0, - x_opt[2]]

        new_1 = (np.inner(phi_x_var_1, Theta_True)) ** 2 + (np.inner(phi_x_var_2, Theta_True)) ** 2 + (np.inner(phi_x_var_3, Theta_True)) **2

        new_2 = (np.inner(phi_x_var_1, theta)) ** 2 + (np.inner(phi_x_var_2, theta)) ** 2 + (np.inner(phi_x_var_3, theta)) ** 2

        new_3 = (np.inner(phi_j_1, theta)) ** 2 + (np.inner(phi_j_2, theta)) ** 2 + (np.inner(phi_j_3, theta)) ** 2
        # gamma = 2
        loss = loss + new_1 - 2 * new_2 + 2 * new_3


    return reg_term + (1/N)*loss
