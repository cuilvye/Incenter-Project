#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

# INCORPORATE KNOWLEDGE OF THETA #
import os
import argparse
import random

import numpy as np
import pandas as pd
import time, math
import warnings
import gurobipy as gp
import matplotlib.pyplot as plt
import scipy.linalg
import cvxpy as cp

from scipy.optimize import fsolve
from utils_cournot_incenter import check_reg_parameter
from utils_cournot_incenter import check_regularizer

from utils_cournot_semidefinite import convert_beth_to_theta_Cournot
from utils_cournot_semidefinite import is_semiPos_def
from utils_cournot_semidefinite import compute_ASL_loss_Cournot
from utils_cournot_semidefinite import normalize_each_variable_Cournot
from utils_cournot_semidefinite import callback
from utils_cournot_semidefinite import zero_to_nan


def F(z, params, Psi_set):
    beth, Lambda1, Lambda2, Xi, Gamma1, Gamma2 = z
    mu, alpha, n_player  = params
    Psi_0, Psi_1, Psi_2 = Psi_set

    # Define each equation
    eq1 = Xi @ beth - (1 / mu) * np.eye(beth.shape[0])

    # in numpy, row vector and column vector are the same thing, using np.outer(e1, e1)
    # eq2 = lambdas[0] * np.matrix.trace(np.outer(e0, e0) @ beth) - 1/mu
    eq2 = Gamma1 @ Lambda1 - (1 / mu) * np.eye(Lambda1.shape[0])

    eq3 = Gamma2 @ Lambda2 - (1 / mu) * np.eye(Lambda2.shape[0])

    eq4 = alpha * beth + 1/(2 * n_player) * Psi_0 - Xi

    eq5 = alpha * Lambda1 + Psi_1 - Gamma1

    eq6 = alpha * Lambda2 + Psi_2 - Gamma2


    return (eq1, eq2, eq3, eq4, eq5, eq6)
    # return np.hstack([np.array([eq1]), np.array([eq2]), np.array([eq3]), eq4.flatten(), eq5.flatten(), eq6.flatten(), eq7.flatten()])


def solve_linear_systems_by_optimization(z_k, params_k, loss_k_set):
    _, mat_Psi_0_k, mat_Psi_1_k, mat_Psi_2_k, vec_v_j_norm_avg_k = loss_k_set
    beth_k, Lambda1_k, Lambda2_k, Xi_k, Gamma1_k, Gamma2_k = z_k
    mu_k, alpha, n_player = params_k

    res_k = F(z_k, params_k, (mat_Psi_0_k, mat_Psi_1_k, mat_Psi_2_k))
    eq1_k, eq2_k, eq3_k, eq4_k, eq5_k, eq6_k = res_k

    # Reshape flattened variables back to their original shapes
    beth = cp.Variable(beth_k.shape, symmetric=True)

    c = cp.Variable(n_player)
    Lambda_1 = cp.diag(c)

    b_d = cp.Variable(2)
    Lambda_2 = cp.diag(b_d)

    ##### how to define the dual variables, need to check it again
    Xi = cp.Variable(Xi_k.shape, symmetric=True)

    c2 = cp.Variable(n_player)
    Gamma_1 = cp.diag(c2)

    b_d_2 = cp.Variable(2)
    Gamma_2 = cp.diag(b_d_2)

    f1 = Xi_k @ beth + Xi @ beth_k # Need to be careful!!
    f1 = f1 + eq1_k
    # f2 = lambdas_k[0] * np.matrix.trace(np.outer(e0, e0) @ beth) + np.matrix.trace(np.outer(e0, e0) @ beth_k) * lambdas[0]
    f2 = Gamma1_k @ Lambda_1 + Gamma_1 @ Lambda1_k - (Xi_k @ beth + Xi @ beth_k)
    f2 = f2 + eq2_k - eq1_k

    # f3 = lambdas_k[1] * np.matrix.trace(np.outer(e1, e1) @ beth) + np.matrix.trace(np.outer(e1, e1) @ beth_k) * lambdas[1]
    f3 = Gamma2_k @ Lambda_2 + Gamma_2 @ Lambda2_k
    f3 = f3 + eq3_k

    f4 = alpha * beth - Xi
    f4 = f4 + eq4_k

    f5 = alpha * Lambda_1 - Gamma_1 - f4
    f5 = f5 + eq5_k - eq4_k

    f6 = alpha * Lambda_2 - Gamma_2
    f6 = f6 + eq6_k

    # obj = cp.norm(f1)  + cp.norm(f2) + cp.norm(f3) + cp.norm(f4)  + cp.norm(f5)  + cp.norm(f6)
    obj = cp.norm(f1) ** 2 + cp.norm(f2) ** 2 + cp.norm(f3) ** 2 + cp.norm(f4) ** 2 + cp.norm(f5) ** 2 + cp.norm(f6) ** 2

    constraints = [beth >> 0]
    for i in range(n_player-1):
        constraints += [beth[i, i] == beth[i + 1, i + 1]]
        # constraints += [Xi[i, i] == Xi[i + 1, i + 1]]

    for i in range(n_player):
        for j in range(n_player):
            if j != i:
                constraints += [beth[i, i] == 2 * beth[i, j]]
                # constraints += [Xi[i, i] == 0.5 * Xi[i, j]]

    constraints += [Lambda_1 >> 0]
    constraints += [Lambda_2 >> 0]
    constraints += [Xi >> 0]
    constraints += [Gamma_1 >> 0]
    constraints += [Gamma_2 >> 0]

    prob = cp.Problem(cp.Minimize(obj), constraints)
    prob.solve(solver=cp.MOSEK)

    delta_beth = beth.value
    delta_Lambda1 = Lambda_1.value
    delta_Lambda2 = Lambda_2.value
    delta_Xi = Xi.value
    delta_Gamma1 = Gamma_1.value
    delta_Gamma2 = Gamma_2.value

    # print("Solution for delta_beth:\n", delta_beth)
    # print("Solution for delta_Lambda_1:\n", delta_Lambda1)
    # print("Solution for delta_Lambda_2:\n", delta_Lambda2)
    # print("Solution for delta_Xi:\n", delta_Xi)
    # print("Solution for delta_Gamma_1:\n", delta_Gamma1)
    # print("Solution for delta_Gamma_2:\n", delta_Gamma2)

    ### to ensure the symmetry ###
    delta_beth, delta_Lambda1, delta_Lambda2, delta_Xi, delta_Gamma1, delta_Gamma2 = normalize_each_variable_Cournot(
        delta_beth, delta_Lambda1, delta_Lambda2, delta_Xi, delta_Gamma1, delta_Gamma2)

    print("Solution for delta_beth:\n", delta_beth)
    print("Solution for delta_Lambda_1:\n", delta_Lambda1)
    print("Solution for delta_Lambda_2:\n", delta_Lambda2)
    print("Solution for delta_Xi:\n", delta_Xi)
    print("Solution for delta_Gamma_1:\n", delta_Gamma1)
    print("Solution for delta_Gamma_2:\n", delta_Gamma2)

    # print(affffff)

    return delta_beth, delta_Lambda1, delta_Lambda2, delta_Xi, delta_Gamma1, delta_Gamma2

def compute_dual_objective_Cournot(mat_Psi_0, mat_Psi_1, mat_Psi_2, vec_v_j_norm_avg, xi, Gamma_1, Gamma_2, alpha):

    # dual objective

    g_term_1 = xi - 1 / (2 * n_player) * mat_Psi_0
    g_term_1_fSqure = np.linalg.norm(g_term_1, 'fro') ** 2

    g_term_2 = Gamma_1 - mat_Psi_1
    g_term_2_fSqure = np.linalg.norm(g_term_2, 'fro') ** 2

    g_term_3 = Gamma_2 - mat_Psi_2
    g_term_3_fSqure = np.linalg.norm(g_term_3, 'fro') ** 2

    obj_dual = -1/(2*alpha) * g_term_1_fSqure - 1/(2*alpha) * g_term_2_fSqure - 1/(2*alpha) * g_term_3_fSqure + vec_v_j_norm_avg

    return obj_dual, g_term_1, g_term_2, g_term_3

######### implement the backtrack line search  ########
def backtrack_Cournot(z, delta_z, loss_k_set, samples, n_player, qmax, squaring_param, alpha, beta=0.5, gamma = 0.5):

    beth, Lambda_1, Lambda_2, xi, Gamma_1, Gamma_2 = z
    delta_beth, delta_Lambda_1, delta_Lambda_2, delta_xi, delta_Gamma_1, delta_Gamma_2 = delta_z
    loss_k, mat_Psi_0_k, mat_Psi_1_k, mat_Psi_2_k, vec_v_j_norm_avg_k = loss_k_set

    bar_eta_p, bar_eta_d = 1, 1 # Typically, beta\in[0.5, 0.8], gamma takes from [0.001, 0.1]
    print('we are backtracking......')
    k = 0
    while True:
        print('primal step length is {}'.format(bar_eta_p))
        new_beth = beth + bar_eta_p * delta_beth
        new_Lambda_1 = Lambda_1 + bar_eta_p * delta_Lambda_1
        new_Lambda_2 = Lambda_2 + bar_eta_p * delta_Lambda_2
        # if is_semiPos_def(new_beth) and is_semiPos_def(new_tilde_beth):
        #     break
        # beth_k, tilde_beth_k =
        loss_new, mat_Psi_0_new, mat_Psi_1_new, mat_Psi_2_new, vec_v_j_norm_avg_new = compute_ASL_loss_Cournot(new_beth, new_Lambda_1, new_Lambda_2, samples, n_player, qmax, squaring_param, alpha)
        difference = np.matrix.trace((alpha * beth + (1 / (2 * n_player)) * mat_Psi_0_k) @ delta_beth) + np.matrix.trace((alpha * Lambda_1 + mat_Psi_1_k) @ delta_Lambda_1) + np.matrix.trace((alpha * Lambda_2 + mat_Psi_2_k) @ delta_Lambda_2)
        if loss_new >= loss_k + gamma * bar_eta_p * difference and  k <= 30:# and k <= 50: #gamma *
            bar_eta_p *= beta
            k = k + 1
        else:
            break

    obj_k, g_term_1_k, g_term_2_k, g_term_3_k = compute_dual_objective_Cournot(mat_Psi_0_k, mat_Psi_1_k, mat_Psi_2_k, vec_v_j_norm_avg_k, xi, Gamma_1, Gamma_2, alpha)
    k = 0
    while True:
        print('dual step length is {}'.format(bar_eta_d))
        new_xi = xi + bar_eta_d * delta_xi
        new_Gamma1 = Gamma_1 + bar_eta_d * delta_Gamma_1
        new_Gamma2 = Gamma_2 + bar_eta_d * delta_Gamma_2

        obj_new, _, _, _ = compute_dual_objective_Cournot(mat_Psi_0_new, mat_Psi_1_new, mat_Psi_2_new, vec_v_j_norm_avg_new, new_xi, new_Gamma1, new_Gamma2, alpha)

        grad_xi = - 1 / alpha * (xi - (1 / (2 * n_player)) * mat_Psi_0_k)
        grad_Gamma_1 = - 1 / alpha * (Gamma_1 - mat_Psi_1_k)
        grad_Gamma_2 = - 1 / alpha * (Gamma_2 - mat_Psi_2_k)

        difference_dual = np.matrix.trace(grad_xi @ delta_xi) + np.matrix.trace(grad_Gamma_1 @ delta_Gamma_1) + np.matrix.trace(grad_Gamma_2 @ delta_Gamma_2)
        if obj_new < obj_k + gamma * bar_eta_d * difference_dual and k <= 30:
            bar_eta_d *= beta
            k = k + 1
        else:
            break

    eta_p, eta_d = bar_eta_p, bar_eta_d

    return eta_p, eta_d

def compute_mu_k_Cournot(beth_k, Lambda1_k, Lambda2_k, xi_k, Gamma1_k, Gamma2_k):

    mu_k_reci = (np.matrix.trace(beth_k @ xi_k) + np.matrix.trace(Lambda1_k @ Gamma1_k)) / (
                beth_k.shape[0] * 3) + np.matrix.trace(Lambda2_k @ Gamma2_k) / 6
    # mu_k_reci = (np.matrix.trace(beth_k @ xi_k) + np.matrix.trace(Lambda1_k @ Gamma1_k)) / (
    #             beth_k.shape[0] * 2)
    mu_k = 1 / mu_k_reci

    return mu_k


def FOM_Game_SDP_Cournot(
    dataset,
    n_player,
    qmax,
    variables_0,
    step,
    Theta_true, # only for comparison
    regularizer='L2_squared',
    reg_param=0,
    squaring_param = 0.1,
    theta_hat=None,
    batch_type=1,
    callback=None,
    callback_resolution=1,
    verbose=True
):
    beth_0, Lambda1_0, Lambda2_0 = variables_0[0], variables_0[1], variables_0[2]
    xi_0, Gamma1_0, Gamma2_0 = variables_0[3], variables_0[4], variables_0[5]

    check_regularizer(regularizer)
    check_reg_parameter(reg_param)

    # Warnings
    assert step == 'newton'

    # Get the dimension of the problem: len(theta_0) and the number of samples
    beth_k, Lambda1_k, Lambda2_k = beth_0, Lambda1_0, Lambda2_0
    xi_k, Gamma1_k, Gamma2_k = xi_0, Gamma1_0, Gamma2_0

    # normalize each varible, why we should normalize the matrix?
    beth_k, Lambda1_k, Lambda2_k, xi_k, Gamma1_k, Gamma2_k = normalize_each_variable_Cournot(beth_k, Lambda1_k, Lambda2_k, xi_k, Gamma1_k, Gamma2_k)

    callback_list = []
    if callback is not None:
        # Evaluate theta_0
        callback_list.append(callback([beth_k, Lambda1_k, Lambda2_k, xi_k, Gamma1_k, Gamma2_k]))

    alpha = reg_param
    Theta_norm = Theta_true / np.linalg.norm(Theta_true)

    N = dataset.shape[0]

    mu_k = compute_mu_k_Cournot(beth_k, Lambda1_k, Lambda2_k, xi_k, Gamma1_k, Gamma2_k)
    # print('1/mu_0 is {}'.format(1/mu_k))
    epsilon = 0.001 # Q1-how to set this value? need to read references
    k = 0
    ASL_loss_set, error_set = [], []
    mu_k_set = [mu_k]
    # mu_k = 2 * mu_k
    while 1 / mu_k > epsilon and k < 50: #1/mu_k > epsilon: mu_k < 1/epsilon
        if verbose:
            print(f'********* Iteration {k+1} ***********')
            print('')
        print('1/mu_k_{} is {}'.format(k + 1, 1/mu_k))
        print('n/trace of beth @ xi is {}'.format(beth_k.shape[0] / np.matrix.trace(beth_k @ xi_k)))
        print('n/trace of Lambda_1 @ Gamma_1 is {}'.format(Lambda1_k.shape[0] / np.matrix.trace(Lambda1_k @ Gamma1_k)))
        print('n/trace of Lambda_2 @ Gamma_2 is {}'.format(Lambda2_k.shape[0] / np.matrix.trace(Lambda2_k @ Gamma2_k)))

        batch_size = int(np.ceil(batch_type * N)) #batch_type = 1
        sample_idxs = np.random.choice(N, batch_size, replace=False)
        samples = [dataset[i] for i in sample_idxs]

        ########### solve for the Newton's linear system   ###########
        ## compute \psi^{j}_{s} ##
        ## be careful!!!! the convert between \beth, \beth2 to theta!! need to check again!!!!!
        theta_k = convert_beth_to_theta_Cournot(beth_k, Lambda1_k, Lambda2_k)
        print('theta_k is {}'.format(theta_k))

        theta_k_normed = theta_k / np.linalg.norm(theta_k)
        print('normalized theta_k_{} is {}'.format(k, theta_k_normed))
        error_norm = np.linalg.norm(np.array(Theta_norm) - np.array(theta_k_normed))
        print('estimated normed error is {}'.format(error_norm))
        error_set.append(error_norm)

        loss_ASL_k, mat_Psi_0_k, mat_Psi_1_k, mat_Psi_2_k, vec_v_j_norm_avg_k = compute_ASL_loss_Cournot(beth_k, Lambda1_k, Lambda2_k, samples, n_player, qmax, squaring_param, alpha)

        ASL_loss_set.append(loss_ASL_k)
        print('ASL loss value is {}'.format(loss_ASL_k))

        z_k = (beth_k, Lambda1_k, Lambda2_k, xi_k, Gamma1_k, Gamma2_k)
        params_k = (mu_k, alpha, n_player)
        loss_k_set = (loss_ASL_k, mat_Psi_0_k, mat_Psi_1_k, mat_Psi_2_k, vec_v_j_norm_avg_k)

        # delta_beth, delta_tilde_beth, delta_Xi, delta_tilde_Xi, delta_lambdas = solve_linear_systems(z_k, params_k, loss_k_set)
        delta_beth, delta_Lambda1, delta_Lambda2, delta_Xi, delta_Gamma1, delta_Gamma2 = solve_linear_systems_by_optimization(z_k, params_k, loss_k_set)
        # newton step: how to determine?
        delta_z = (delta_beth, delta_Lambda1, delta_Lambda2, delta_Xi, delta_Gamma1, delta_Gamma2)

        eta_k, dual_eta_k = backtrack_Cournot(z_k, delta_z, loss_k_set, samples, n_player, qmax, squaring_param, alpha, beta=0.8, gamma = 0.5)

        beth_k = beth_k + eta_k * delta_beth
        Lambda1_k = Lambda1_k + eta_k * delta_Lambda1
        Lambda2_k = Lambda2_k + eta_k * delta_Lambda2
        xi_k = xi_k + dual_eta_k * delta_Xi
        Gamma1_k = Gamma1_k + dual_eta_k * delta_Gamma1
        Gamma2_k = Gamma2_k + dual_eta_k * delta_Gamma2

        beth_k, Lambda1_k, Lambda2_k, xi_k, Gamma1_k, Gamma2_k = normalize_each_variable_Cournot(beth_k, Lambda1_k, Lambda2_k, xi_k, Gamma1_k, Gamma2_k)

        mu_k = compute_mu_k_Cournot(beth_k, Lambda1_k, Lambda2_k, xi_k, Gamma1_k, Gamma2_k)
        k = k + 1
        mu_k_before = mu_k_set[-1]
        scaling = 1.2
        while  mu_k < mu_k_before:
            mu_k = scaling * mu_k
        mu_k_set.append(mu_k)

        callback_list.append(callback([beth_k, Lambda1_k, Lambda2_k, xi_k, Gamma1_k, Gamma2_k]))

    print(ASL_loss_set)
    print(error_set)
    mu_k_reci_set =[1 / i  for i in mu_k_set]
    print(mu_k_reci_set)
    return callback_list, ASL_loss_set, error_set

def intialize_variables_Cournot(n_player):

    a = np.random.uniform(low =0, high = 10, size = 1)[0] # random one element from (0, 1)
    beth = np.zeros((n_player, n_player))
    for i in range(n_player):
        for j in range(n_player):
            if i == j:
                beth[i, j] = 2 * a
            else:
                beth[i, j] = a
    assert is_semiPos_def(beth) == True

    Lambda_1_ele = np.random.uniform(0, 10, size=n_player)#np.random.rand(n_player, n_player)
    Lambda_1 = np.diag(Lambda_1_ele)
    # print(tilde_beth_0)
    assert is_semiPos_def(Lambda_1) == True

    Lambda_2_ele = np.random.uniform(0, 10, size=2)#np.random.rand(n_player, n_player)
    Lambda_2 = np.diag(Lambda_2_ele)
    assert is_semiPos_def(Lambda_2) == True

    a_xi = np.random.uniform(low =0, high = 10, size = 1)[0] # random one element from (0, 1)
    xi = np.zeros((n_player, n_player))
    for i in range(n_player):
        for j in range(n_player):
            if i == j:
                xi[i, j] = 2 * a_xi
            else:
                xi[i, j] = a_xi
    assert is_semiPos_def(xi) == True

    Gamma_1_ele = np.random.uniform(0, 10, size=n_player)#np.random.rand(n_player, n_player)
    Gamma_1 = np.diag(Gamma_1_ele)
    assert is_semiPos_def(Gamma_1) == True

    Gamma_2_ele = np.random.uniform(0, 10, size=2)#np.random.rand(n_player, n_player)
    Gamma_2 = np.diag(Gamma_2_ele)
    assert is_semiPos_def(Gamma_2) == True

    return [beth, Lambda_1, Lambda_2, xi, Gamma_1, Gamma_2]


args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/cournot/', help = 'the root of data', type = str)
# args_parser.add_argument('--u_type', default = 'linear', help = 'the type of demand function', type = str)
args_parser.add_argument('--seed', default = 0, help = 'random index', type = int)
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args_parser.add_argument('--qmax', default = 6, help = 'upper bound of price', type = float)
args_parser.add_argument('--nPlayer', default = 3, help = 'the number of players', type = int)
args_parser.add_argument('--squaring', default = 1, help = 'random index', type = float)
# args_parser.add_argument('--Epoch', default = 500, help = 'maximum of iterations in our algorithm', type = int)
args_parser.add_argument('--step', default = 'newton', help = 'the descent update method', type = str)
args_parser.add_argument('--regularizer', default = 'L2_squared', help = 'the regularizer term in our loss', type = str)
# args_parser.add_argument('--normalize_grad', default = True, help = 'if gradient is normalized', type = bool)
args_parser.add_argument('--batch_ratio', default = 1.0, help = 'the batch size', type = float)
args_parser.add_argument('--time_limit', default = 0.05, help = 'the time limit in optimization', type = float)
# args_parser.add_argument('--step_size_constant', default = 0.5, help = 'the step size constant in update', type = float)
args_parser.add_argument('--reg_param', default = 0.01, help = 'the coefficient of the regularizer loss', type = float)
args_parser.add_argument('--theta_prior', default = None, help = 'the prior of theta', type = float)
args = args_parser.parse_args()

seed = args.seed
file_path = args.file_root
N_train = args.N
qmax = args.qmax
n_player = args.nPlayer

Theta_true = np.load(file_path + 'parameter_' + str(seed) + '_n_' + str(n_player) + '.npy', allow_pickle=True)
dataset_train_df = pd.read_csv(file_path + 'dataset_seed_'+ str(seed) + '_train_n_' + str(n_player) + '_N_' + str(N_train) + '_firstOrder.csv')
dataset_test_df = pd.read_csv(file_path + 'dataset_seed_' + str(seed) + '_test_n_' + str(n_player) +'_N_' + str(N_train) + '_firstOrder.csv')

dataset_train = np.array(dataset_train_df)
dataset_test = np.array(dataset_test_df)

# n_player = 2 # player number is 2
n_theta = len(Theta_true)
# pmax = math.ceil(max(np.max(dataset_train[:, 0]), np.max(dataset_train[:, 1])))
qmax_train = math.ceil(np.max(dataset_train[:, :(dataset_train.shape[1]-1)]))
qmax_test = math.ceil(np.max(dataset_test[:, :(dataset_test.shape[1]-1)]))
qmax = min(max(qmax_train, qmax_test), qmax)
print("qmax is {}".format(qmax))


time_limit = args.time_limit
step = args.step #'exponentiated'
regularizer = args.regularizer

# #### 'L2-squared' and 'standard' fails due to Eucliduan-geometry......
# regularizer = 'L2_squared'
# step = 'standard'
squaring_param = args.squaring
Theta_Prior = args.theta_prior
reg_param = args.reg_param
batch = args.batch_ratio

save_path = './results/cournot/Seed_' + str(seed) + '/'+ step + '_' + regularizer
if not os.path.exists(save_path):
    os.makedirs(save_path)

time_s = time.time()
# n_runs = 5
run_set = [0]#, 1, 2, 3, 4
callbacks_runs = []
ASL_runs, err_runs = [], []
# print('training sample number is {}'.format(dataset_train.shape[0]))
for r_idx in range(len(run_set)):#range(n_runs):
    #### runs -- r #####
    r = run_set[r_idx]
    variables_set = intialize_variables_Cournot(n_player)
    print('Initial variables are ', variables_set)

    callback_results, ASL_Set, Err_Set = FOM_Game_SDP_Cournot(dataset_train,
                                             n_player,
                                             qmax,
                                             variables_set,
                                             step,
                                             Theta_true,
                                             regularizer=regularizer,
                                             reg_param= reg_param,
                                             squaring_param =squaring_param,
                                             batch_type=batch,
                                             callback=callback)#,normalize_grad=normalize_grad)


    print(callback_results)
    callbacks_runs.append(callback_results)
    ASL_runs.append(ASL_Set)
    err_runs.append(Err_Set)
    ## save all-thetas ##
    thetas_iter_name = save_path + '/SDP_thetas_run_' + str(r) + '_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '.npy'
    np.save(thetas_iter_name, np.array(callback_results, dtype=object), allow_pickle=True)

loss_ASL_name = save_path + '/SDP_loss_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '.csv'
# runs_LOSS_np = np.array(ASL_runs)# cannot directly use this, since each run has different length
runs_LOSS_np = np.zeros([len(ASL_runs),len(max(ASL_runs,key = lambda x: len(x)))])
for i,j in enumerate(ASL_runs):
    runs_LOSS_np[i][0:len(j)] = j
pd.DataFrame(runs_LOSS_np).to_csv(loss_ASL_name, index = False)

ERR_ASL_name = save_path + '/SDP_Err_thetas_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '.csv'
# runs_Err_np = np.array(err_runs)
runs_ERR_np = np.zeros([len(err_runs),len(max(err_runs,key = lambda x: len(x)))])
for i,j in enumerate(err_runs):
    runs_ERR_np[i][0:len(j)] = j
pd.DataFrame(runs_ERR_np).to_csv(ERR_ASL_name, index = False)

print('squaring is {}'.format(squaring_param))
print('After running 5 exps, time spent {} minutes'.format((time.time()-time_s)/60))

################ plot the average result for ASL LOSS #####################
assert runs_LOSS_np.shape[0] == len(callbacks_runs)
runs_average = np.nanmean(zero_to_nan(runs_LOSS_np), axis = 0) #runs_LOSS_np.mean(axis=0)     # to take the mean of each col
runs_std = np.nanstd(zero_to_nan(runs_LOSS_np), axis = 0)#runs_LOSS_np.std(axis=0)

plt.rcParams["mathtext.fontset"] = 'cm'
plt.rcParams['font.family'] = 'serif'
plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]

plt.figure(0)
plt.plot(range(1, len(runs_average) + 1), runs_average, label='ASL', color='red', linewidth=2)
plt.fill_between(range(1, len(runs_average) + 1), runs_average-runs_std, runs_average+runs_std, alpha=0.25, edgecolor='#FF4500', facecolor='#FE420F')
# plt.plot(range(1, len(err_T) + 1), np.repeat(1.0710639067698995, len(err_T)), label='Bertsimas')
plt.ylabel(
    'Loss Value', fontsize=18
)
plt.xlabel(r'Iterations of $ \mu $', fontsize=14)
plt.xlim(0, len(runs_average))
# plt.ylim(40, 60)
plt.grid(visible=True)
plt.legend(fontsize='16', loc='upper right')
plt.tight_layout()
# saving the figure.
plt.savefig(save_path + '/SDP_avgLOSS_squaring_'+str(squaring_param) + '_N_' + str(N_train)
     + '_' + regularizer + '_' + step + '.png')
plt.show()

######################## plot the average of ERRORS result ################################

runs_average = np.nanmean(zero_to_nan(runs_ERR_np), axis = 0) #runs_ERR_np.mean(axis=0)     # to take the mean of each col
runs_std = np.nanstd(zero_to_nan(runs_ERR_np), axis = 0) #runs_ERR_np.std(axis=0)

plt.rcParams["mathtext.fontset"] = 'cm'
plt.rcParams['font.family'] = 'serif'
plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]

plt.figure(1)
plt.plot(range(1, len(runs_average) + 1), runs_average, label='ASL', color='red', linewidth=2)
plt.fill_between(range(1, len(runs_average) + 1), runs_average-runs_std, runs_average+runs_std, alpha=0.25, edgecolor='#FF4500', facecolor='#FE420F')
# plt.plot(range(1, len(err_T) + 1), np.repeat(1.0710639067698995, len(err_T)), label='Bertsimas')
plt.ylabel(
    r'$\| {\vartheta}_{\mathrm{esti}} - {\vartheta}_{\mathrm{true}} \|_2$', fontsize=18
)
plt.xlabel(r'Iterations of $ \mu $', fontsize=14)
plt.xlim(0, len(runs_average))
# plt.ylim(0.5, 1.2)
plt.grid(visible=True)
plt.legend(fontsize='16', loc='upper right')
plt.tight_layout()
# saving the figure.
plt.savefig(save_path + '/SDP_avgTheta_squaring_' + str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '.png')
plt.show()






