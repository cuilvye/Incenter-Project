#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

import os

import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd
import pickle

from utils_traffic import read_demands_from_file
from utils_traffic import generate_arcs_from_network
from utils_traffic import add_costs_flows_to_dict_arcs
from utils_traffic import generate_user_equilibrium_data

################################################## Read in the demand file #######################################
file_path = "./SiouxFalls/"
file_demands = file_path + "SiouxFalls_trips.tntp"

# Print the demands dictionary to verify
dict_demands = read_demands_from_file(file_demands)
print(dict_demands)
print(len(dict_demands))

save_path  = './data/traffic/'
if not os.path.exists(save_path):
    os.makedirs(save_path)

################################### Read in the arc file #################################
file_net = file_path + "SiouxFalls_net.tntp"
dict_arcs = generate_arcs_from_network(file_net)
# Print the arcs dictionary to verify
# arcs[(start_node, end_node)] = Arc(start_node, end_node, capacity, theta_0, theta_1)
for key, arc in dict_arcs.items():
    print(key, arc)

################################### Read in the true costs ##################################
file_flow = file_path + "SiouxFalls_flow.tntp"
dict_arcs, tot_cost, test_cost = add_costs_flows_to_dict_arcs(dict_arcs, file_flow)
for key, arc in dict_arcs.items():
    print(arc.trueflow)
    print(key, arc)
print('computed cost using cost function is :', tot_cost)
print('the actual cost is:', test_cost)
# Number of nodes
# num_nodes = 24
# Create a directed graph
# G = nx.DiGraph()
# Initialize the list of arcs
# v_arcs = []
# Update obsflow to trueflow, add edges to the graph, and collect arcs
# for arc in dict_arcs.values():
#     arc.obsflow = arc.trueflow
#     G.add_edge(arc.start_node, arc.end_node)
#     # v_arcs.append(arc)
#
# # Print the graph to verify
# print("Graph edges:", G.edges())
# print(len(G.edges()))
# # print("v_arcs:", v_arcs)
# print(len(v_arcs))

############################################################# Generate the simulated data #############################################################
numData = 500
sigma = 0.1

# Create a directed graph
G = nx.DiGraph()
# Initialize the list of arcs
# Update obsflow to trueflow, add edges to the graph, and collect arcs
v_arcs, thetas = [], []
for idx, arc in enumerate(dict_arcs.values()):
    arc.obsflow = arc.trueflow
    G.add_edge(arc.start_node, arc.end_node, index=idx)
    # G.add_edge(arc.start_node, arc.end_node)
    arc.thetas_true = (arc.theta_0, arc.theta_1)
    v_arcs.append(arc)
    thetas.append([arc.theta_0, arc.theta_1, arc.capacity])

thetas = np.array(thetas)
thetas_pd = pd.DataFrame(thetas, columns=['theta_0', 'theta_1', 'capacity'])
thetas_pd.to_csv(save_path + "thetas-true-N-" + str(numData) + ".csv", index=False)


## Randomize the flow data a little bit too
# flow_data *= (1 + sigma * np.random.rand(*flow_data.shape))
# Print the flow data to verify
flow_data_train, _ = generate_user_equilibrium_data(numData, dict_arcs, dict_demands, sigma, G, v_arcs)
print("Flow Data:")
print(flow_data_train)
pd.DataFrame(flow_data_train).to_csv(save_path + "dataset_train_Flow_N_"+str(numData)+".csv", index=False)

flow_data_test, demand_test = generate_user_equilibrium_data(numData, dict_arcs, dict_demands, sigma, G, v_arcs)
pd.DataFrame(flow_data_test).to_csv(save_path +"dataset_test_Flow_N_"+str(numData)+".csv", index=False)
with open(save_path + 'dataset_test_demands_N_' + str(numData) +'.pkl', 'wb') as f:
    pickle.dump(demand_test, f)


# Define the true coefficients and coefficients from the dictionary
# true_coeffs = [1, 0, 0, 0, 0.15]
# coeffs_dict = {
#     (3, 3.41, 1.0): (3, 3.41, 1.0),
#     (4, 3.41, 1.0): (4, 3.41, 1.0),
#     (5, 2.6, 0.1):  (5, 2.6, 0.1),
#     (6, 2.6, 0.001): (6, 2.6, 0.001),
# }
#
# fcoeffs3 = coeffs_dict[(3, 3.41, 1.0)]
# fcoeffs4 = coeffs_dict[(4, 3.41, 1.0)]
# fcoeffs5 = coeffs_dict[(5, 2.6, 0.1)]
# fcoeffs6 = coeffs_dict[(6, 2.6, 0.001)]
#
# # Define the range of x values
# xs = np.linspace(0, 2, 20)
#
# # Evaluate the polynomials at the x values
# ys_true = [poly_eval(true_coeffs, x) for x in xs]
# ys3 = [poly_eval(fcoeffs3, x) for x in xs]
# ys4 = [poly_eval(fcoeffs4, x) for x in xs]
# ys5 = [poly_eval(fcoeffs5, x) for x in xs]
# ys6 = [poly_eval(fcoeffs6, x) for x in xs]
#
# # Plotting
# plt.plot(xs, ys_true, "--k", label="True Coefficients")
# plt.plot(xs, ys3, ".-r", label="Coeffs (3, 3.41, 1.0)")
# plt.plot(xs, ys4, "s-b", label="Coeffs (4, 3.41, 1.0)")
# plt.plot(xs, ys5, "o-b", label="Coeffs (5, 2.6, 0.1)")
# plt.plot(xs, ys6, "*-b", label="Coeffs (6, 2.6, 0.001)")
#
# # Set the y-axis limit
# # plt.ylim(0, 3.5)
# # Add legend
# plt.legend()
#
# # Show the plot
# plt.show()

# ##Create a DataFrame
# df = pd.DataFrame({
#     "Flow": xs,
#     "True": ys_true,
#     "Deg3": ys3,
#     "Deg4": ys4,
#     "Deg5": ys5,
#     "Deg6": ys6
# })
#
# # Save the DataFrame to a CSV file
# df.to_csv("fittedFuncs.csv", index=False)
