#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

from scipy.optimize import fsolve
import numpy as np

def projection(q1, q2, q3, qmax):

    q1_clip = np.clip(q1, 0, qmax)
    q2_clip = np.clip(q2, 0, qmax)
    q3_clip = np.clip(q3, 0, qmax)

    return q1_clip, q2_clip, q3_clip

def firstOrderEq_givenXi_linearDemand(xi_hat, thetas, qmax):
    # Initial guess for p1 and p2
    initial_guess = [1, 1, 1]
    a, b, d, c1, c2, c3 = thetas[0], thetas[1], thetas[2], thetas[3], thetas[4], thetas[5]
    def equations(prices):
        q1, q2, q3 = prices

        f1 = b + d * xi_hat - a * (q2 + q3 + 2 * q1) - c1 * q1
        f2 = b + d * xi_hat - a * (q1 + q3 + 2 * q2) - c2 * q2
        f3 = b + d * xi_hat - a * (q1 + q2 + 2 * q3) - c3 * q3

        return [f1, f2, f3]

    # Solve the system of equations#
    solution = fsolve(equations, initial_guess)
    q1, q2, q3 = solution

    q1_new, q2_new, q3_new = projection(q1, q2, q3, qmax)

    return np.array([q1_new, q2_new, q3_new])

def firstOrderEq_givenXi_linearDemand_five_firms(xi_hat, thetas, qmax):
    # Initial guess for p1 and p2
    initial_guess = [1, 1, 1, 1, 1]
    a, b, d, c1, c2, c3, c4, c5 = thetas[0], thetas[1], thetas[2], thetas[3], thetas[4], thetas[5], thetas[6], thetas[7]
    def equations(prices):
        q1, q2, q3, q4, q5 = prices

        f1 = b + d * xi_hat - a * (q2 + q3 + q4 + q5 + 2 * q1) - c1 * q1
        f2 = b + d * xi_hat - a * (q1 + q3 + q4 + q5 + 2 * q2) - c2 * q2
        f3 = b + d * xi_hat - a * (q1 + q2 + q4 + q5 + 2 * q3) - c3 * q3
        f4 = b + d * xi_hat - a * (q1 + q2 + q3 + q5 + 2 * q4) - c4 * q4
        f5 = b + d * xi_hat - a * (q1 + q2 + q3 + q4 + 2 * q5) - c5 * q5

        return [f1, f2, f3, f4, f5]

    # Solve the system of equations
    solution = fsolve(equations, initial_guess)
    q1, q2, q3, q4, q5 = solution

    q1_clip = np.clip(q1, 0, qmax)
    q2_clip = np.clip(q2, 0, qmax)
    q3_clip = np.clip(q3, 0, qmax)
    q4_clip = np.clip(q4, 0, qmax)
    q5_clip = np.clip(q5, 0, qmax)

    return np.array([q1_clip, q2_clip, q3_clip, q4_clip, q5_clip])

def FirstOrder_Equilibrium_LinearDemand_Cournot(N, xi_mean, xi_std, thetas, qmax, n_firms):
    ## Demand function: D_{i}\left(p_1, p_2, \xi ; \bm\theta_{i}\right) = \theta_{i1}p_{1} + \theta_{i2}p_{2} + \theta_{i3}\xi +\theta_{i4};
    dataset = []
    for i in range(N):
        xi = np.random.normal(xi_mean, xi_std)  # context feature xi
        # Initial guess for p1 and p2
        if n_firms == 3:
            equilibrium = firstOrderEq_givenXi_linearDemand(xi, thetas, qmax)
        elif n_firms == 5:
            equilibrium = firstOrderEq_givenXi_linearDemand_five_firms(xi, thetas, qmax)
        # Output the results
        # print("xi: {} ".format(xi))
        # print("Equilibrium prices:", equilibrium)
        dataset.append(list(equilibrium) + [xi])

    dataset_np = np.array(dataset)
    assert dataset_np.shape[1] == n_firms + 1
    print(dataset_np)
    return dataset_np


def ProjectAlgEq_givenXi_linearDemand_Cournot(xi_hat, thetas, qmax, max_Iter, tau, epsilon):
    # global p1, p2, xi
    quantities = np.full(3, qmax / 2.0)
    q1, q2, q3 = quantities[0], quantities[1], quantities[2]
    a, b, d, c1, c2, c3 = thetas[0], thetas[1], thetas[2], thetas[3], thetas[4], thetas[5]
    for iter in range(max_Iter):
        # Calculate profit gradients
        grad_q1 = b + d * xi_hat - a * (q2 + q3 + 2 * q1) - c1 * q1
        grad_q2 = b + d * xi_hat - a * (q1 + q3 + 2 * q2) - c2 * q2
        grad_q3 = b + d * xi_hat - a * (q1 + q2 + 2 * q3) - c3 * q3

        # Update prices using gradient descent
        q1_iter = q1 + tau * grad_q1
        q2_iter = q2 + tau * grad_q2
        q3_iter = q3 + tau * grad_q3

        q1_new, q2_new, q3_new  = projection(q1_iter, q2_iter,q3_iter, qmax)
        # Check convergence

        if np.linalg.norm(np.array([q1_new, q2_new, q3_new]) - np.array([q1, q2, q3])) <= epsilon:
            print('find the {}-equilibrium after iteration-{} '.format(epsilon, iter))
            q1, q2, q3 = q1_new, q2_new, q3_new
            return q1, q2, q3

        # Update prices
        q1, q2, q3 = q1_new, q2_new, q3_new

    return np.array([q1, q2, q3])