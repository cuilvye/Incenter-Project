#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""
import pandas as pd
import numpy as np
import gurobipy as gp
import os, sys
import time
from gurobipy import GRB, quicksum
from scipy.optimize import fsolve
import argparse
import pickle
import networkx as nx

from utils_traffic import frank_wolfe_outOf_sample
from utils_traffic import generate_arcs_from_network
from utils_traffic import add_costs_flows_to_dict_arcs
from utils_traffic import frank_wolfe_outOf_sample

# Example usage #
args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/traffic/', help = 'the root of data', type = str)
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args = args_parser.parse_args()

file_path  = args.file_root
N_train = args.N

save_path = './results/traffic/aaai_Baseline2/'
if not os.path.exists(save_path):
    os.makedirs(save_path)


seeds_theta_estimated_normed = []
seeds_err_normed = []
seeds_equilibrium = []
# seeds_equilibrium_approx = []

Theta_true_file = pd.read_csv(os.path.join(file_path, "thetas-true-N-" + str(N_train) + ".csv"))
theta_true = np.array(Theta_true_file[['theta_0', 'theta_1']])
Theta_true = theta_true.flatten()  # a=matrix([[1, 2],[3, 4]]), a.flatten() = matrix([[1, 2, 3, 4]])
np_capacities = np.array(Theta_true_file['capacity'])

Theta_true_normed = Theta_true / np.linalg.norm(Theta_true)

dataset_test_df = pd.read_csv(file_path + "dataset_test_Flow_N_" + str(N_train) + ".csv", header=0)
dataset_test = np.array(dataset_test_df)


with open(file_path + 'dataset_test_demands_N_'+ str(N_train) +'.pkl', 'rb') as f:
    demand_data = pickle.load(f)
file_path = "./SiouxFalls/"
file_net = file_path + "SiouxFalls_net.tntp"
dict_arcs = generate_arcs_from_network(file_net)
################################### Read in the true costs ##################################
file_flow = file_path + "SiouxFalls_flow.tntp"
dict_arcs, tot_cost, test_cost = add_costs_flows_to_dict_arcs(dict_arcs, file_flow)
for key, arc in dict_arcs.items():
    print(key, arc)
print('computed cost using cost function is :', tot_cost)
print('the actual cost is:', test_cost)
############################################################# Generate the simulated data #############################################################
# Create a directed graph
G = nx.DiGraph()

for idx, arc in enumerate(dict_arcs.values()):
    arc.obsflow = arc.trueflow
    G.add_edge(arc.start_node, arc.end_node, index=idx)

for seed in range(10):
    ######## start to estimate thetas ########
    Theta_estimated = np.random.uniform(low = -10, high = 10, size= len(Theta_true))

    Theta_estimated_normed = Theta_estimated / np.linalg.norm(Theta_estimated)
    error_normed = np.linalg.norm(np.array(Theta_true_normed) - np.array(Theta_estimated_normed))
    print('Estimated error (all normalize to l2-norm) is {}'.format(error_normed)) #Estimated error (all normalize to l2-norm) is 1.0710639067698995

    seeds_theta_estimated_normed.append(Theta_estimated_normed)
    seeds_err_normed.append(error_normed)

    # ######## to evaluate the \| x_esti - x_true \|_{2} on out-of samples, i.e., testing dataset #######
    difference_set_test = []
    difference_set_test_approx = []
    dataset_test = np.array(dataset_test_df)

    v_arcs_i = []
    for idx, arc in enumerate(dict_arcs.values()):
        arc.thetas_estimated = (abs(Theta_estimated_normed [2 * idx]), abs(Theta_estimated_normed [2 * idx + 1]))
        v_arcs_i.append(arc)

    for j in range(dataset_test.shape[0]):

        x_hat = dataset_test[j]
        #### the reason that why there is a line is because when we compute the equilibrium, we did not use the theta_t ####
        conv_tol, flow_solution = frank_wolfe_outOf_sample(G, v_arcs_i, demand_data, j)

        p_solution = flow_solution

        difference_j = np.linalg.norm(p_solution - x_hat)
        difference_set_test.append(difference_j)

    # print(difference_set_test)
    # print(np.mean(difference_set_test))
    # print(difference_set_test_approx)
    # print(np.mean(difference_set_test_approx))
    seeds_equilibrium.append(np.mean(difference_set_test))
    # seeds_equilibrium_approx.append(np.mean(difference_set_test_approx))

#### save the results
result_dict = {
               'l2-norm-error-set': seeds_err_normed,
               'l2-norm-error-mean': np.mean(seeds_err_normed),
               'l2-norm-error-std': np.std(seeds_err_normed),
               'error-equilibrium': seeds_equilibrium,
               'error-equilibrium-mean': np.mean(seeds_equilibrium),
               'error-equilibrium-std': np.std(seeds_equilibrium),
               # str(epsilon) +'-equilibrium-approx-mean': np.mean(seeds_equilibrium_approx),
               # str(epsilon) +'-equilibrium-approx-std': np.std(seeds_equilibrium_approx),
               }

with open(save_path + 'Randomness_N_'+str(N_train)+'.txt', 'w') as f:
    print(result_dict, file = f)

print(result_dict)

#