#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

# INCORPORATE KNOWLEDGE OF THETA #
import os
import argparse
import random

import numpy as np
import pandas as pd
import time, math
import warnings
import gurobipy as gp
import matplotlib.pyplot as plt
import scipy.linalg
import cvxpy as cp
from sklearn import preprocessing

from utils_traffic_incenter import check_regularizer
from utils_traffic_incenter import check_reg_parameter

from utils_traffic_semidefinite import convert_lambdas_to_theta_traffic
from utils_traffic_semidefinite import is_semiPos_def
from utils_traffic_semidefinite import compute_ASL_loss_traffic
from utils_traffic_semidefinite import normalize_each_variable_traffic
from utils_traffic_semidefinite import callback
from utils_traffic_semidefinite import compute_mu_k_traffic
from utils_traffic_semidefinite import zero_to_nan


def F_traffic(z, params, Psi_set):
    Lambda0, Lambda1, Gamma0, Gamma1 = z
    mu, alpha, n_arcs  = params
    Psi_0, Psi_1 = Psi_set
    # Define each equation
    eq1 = Gamma0 @ Lambda0 + Lambda0 @ Gamma0 - (2 / mu) * np.eye(Lambda0.shape[0])

    eq2 = Gamma1 @ Lambda1 + Lambda1 @ Gamma1 - (2 / mu) * np.eye(Lambda1.shape[0])

    eq3 = alpha * Lambda0 - Psi_0 - Gamma0

    eq4 = alpha * Lambda1 - Psi_1 - Gamma1

    return (eq1, eq2, eq3, eq4)
    # return np.hstack([np.array([eq1]), np.array([eq2]), np.array([eq3]), eq4.flatten(), eq5.flatten(), eq6.flatten(), eq7.flatten()])


def solve_linear_systems_by_optimization(z_k, params_k, loss_k_set):
    _, mat_Psi_0_k, mat_Psi_1_k, vec_v_j_norm_avg_k = loss_k_set
    Lambda0_k, Lambda1_k, Gamma0_k, Gamma1_k = z_k
    mu_k, alpha, n_arcs = params_k

    res_k = F_traffic(z_k, params_k, (mat_Psi_0_k, mat_Psi_1_k))
    eq1_k, eq2_k, eq3_k, eq4_k  = res_k

    # Reshape flattened variables back to their original shapes
    c = cp.Variable(n_arcs)
    Lambda_0 = cp.diag(c)

    c2 = cp.Variable(n_arcs)
    Lambda_1 = cp.diag(c2)

    ##### how to define the dual variables, need to check it again
    c3 = cp.Variable(n_arcs)
    Gamma_0 = cp.diag(c3)

    c4 = cp.Variable(n_arcs)
    Gamma_1 = cp.diag(c4)

    # f2 = lambdas_k[0] * np.matrix.trace(np.outer(e0, e0) @ beth) + np.matrix.trace(np.outer(e0, e0) @ beth_k) * lambdas[0]
    f1 = Gamma0_k @ Lambda_0 + Gamma_0 @ Lambda0_k + Lambda0_k @ Lambda_0 + Lambda_0 @ Gamma0_k
    f1 = f1 + eq1_k

    # f3 = lambdas_k[1] * np.matrix.trace(np.outer(e1, e1) @ beth) + np.matrix.trace(np.outer(e1, e1) @ beth_k) * lambdas[1]
    f2 = Gamma1_k @ Lambda_1 + Gamma_1 @ Lambda1_k + Lambda1_k @ Lambda_1 + Lambda_1 @ Gamma1_k
    f2 = f2 + eq2_k

    f3 = alpha * Lambda_0 - Gamma_0
    f3 = f3 + eq3_k

    f4 = alpha * Lambda_1 - Gamma_1 - (alpha * Lambda_0 - Gamma_0)
    f4 = f4 + eq4_k - eq3_k

    obj = cp.norm(f1) ** 2 + cp.norm(f2) ** 2 + cp.norm(f3) ** 2 + cp.norm(f4) ** 2

    constraints = [Lambda_0 >> 0]
    constraints += [Lambda_1 >> 0]
    constraints += [Gamma_0 >> 0]
    constraints += [Gamma_1 >> 0]

    prob = cp.Problem(cp.Minimize(obj), constraints)
    prob.solve(solver=cp.MOSEK, verbose=False)

    delta_Lambda0 = Lambda_0.value
    delta_Lambda1 = Lambda_1.value
    delta_Gamma0 = Gamma_0.value
    delta_Gamma1 = Gamma_1.value

    # print(delta_Lambda0)
    # print("Solution for delta_beth:\n", delta_beth)
    # print("Solution for delta_Lambda_1:\n", delta_Lambda1)
    # print("Solution for delta_Lambda_2:\n", delta_Lambda2)
    # print("Solution for delta_Xi:\n", delta_Xi)
    # print("Solution for delta_Gamma_1:\n", delta_Gamma1)
    # print("Solution for delta_Gamma_2:\n", delta_Gamma2)

    ### to ensure the symmetry ###
    delta_Lambda0, delta_Lambda1, delta_Gamma0, delta_Gamma1 = normalize_each_variable_traffic(
        delta_Lambda0, delta_Lambda1, delta_Gamma0, delta_Gamma1)

    # print("Solution for delta_Lambda_1:\n", delta_Lambda0)
    # print("Solution for delta_Lambda_2:\n", delta_Lambda1)
    # print("Solution for delta_Gamma_1:\n", delta_Gamma0)
    # print("Solution for delta_Gamma_2:\n", delta_Gamma1)

    return delta_Lambda0, delta_Lambda1, delta_Gamma0, delta_Gamma1

def compute_dual_objective_traffic(mat_Psi_0, mat_Psi_1, vec_v_j_norm_avg, Gamma_0, Gamma_1, alpha):

    # dual objective

    g_term_0 = Gamma_0 + mat_Psi_0
    g_term_0_fSqure = np.linalg.norm(g_term_0, 'fro') ** 2

    g_term_1 = Gamma_1 + mat_Psi_1
    g_term_1_fSqure = np.linalg.norm(g_term_1, 'fro') ** 2

    obj_dual = -1/(2*alpha) * g_term_0_fSqure - 1/(2*alpha) * g_term_1_fSqure + vec_v_j_norm_avg

    return obj_dual, g_term_0, g_term_1

######### implement the backtrack line search  ########
def backtrack_traffic(z, delta_z, loss_k_set, samples, n_arcs, p_set, squaring_param, alpha, beta=0.5, gamma = 0.5):
    pmin, pmax = p_set[0], p_set[1]
    Lambda_0, Lambda_1,  Gamma_0, Gamma_1 = z
    delta_Lambda_0, delta_Lambda_1, delta_Gamma_0, delta_Gamma_1 = delta_z
    loss_k, mat_Psi_0_k, mat_Psi_1_k, vec_v_j_norm_avg_k = loss_k_set

    bar_eta_p, bar_eta_d = 1, 1 # Typically, beta\in[0.5, 0.8], gamma takes from [0.001, 0.1]
    print('we are backtracking......')
    k = 0
    while True:
        print('primal step length is {}'.format(bar_eta_p))
        new_Lambda_0 = Lambda_0 + bar_eta_p * delta_Lambda_0
        new_Lambda_1 = Lambda_1 + bar_eta_p * delta_Lambda_1
        # if is_semiPos_def(new_beth) and is_semiPos_def(new_tilde_beth):
        #     break
        loss_new, mat_Psi_0_new, mat_Psi_1_new, vec_v_j_norm_avg_new = compute_ASL_loss_traffic(new_Lambda_0, new_Lambda_1, samples, np_capacities, n_arcs, p_set, squaring_param, alpha)
        difference = np.matrix.trace((alpha * Lambda_0 - mat_Psi_0_k) @ delta_Lambda_0) + np.matrix.trace((alpha * Lambda_1 - mat_Psi_1_k) @ delta_Lambda_1)
        if loss_new >= loss_k + gamma * bar_eta_p * difference and  k <= 30:# and k <= 50: #gamma *
            bar_eta_p *= beta
            k = k + 1
        else:
            break

    obj_k, g_term_1_k, g_term_2_k = compute_dual_objective_traffic(mat_Psi_0_k, mat_Psi_1_k, vec_v_j_norm_avg_k, Gamma_0, Gamma_1, alpha)
    k = 0
    while True:
        print('dual step length is {}'.format(bar_eta_d))
        new_Gamma0 = Gamma_0 + bar_eta_d * delta_Gamma_0
        new_Gamma1 = Gamma_1 + bar_eta_d * delta_Gamma_1

        obj_new, _, _ = compute_dual_objective_traffic(mat_Psi_0_new, mat_Psi_1_new, vec_v_j_norm_avg_new, new_Gamma0, new_Gamma1, alpha)

        grad_Gamma_0 = - 1 / alpha * (Gamma_0 + mat_Psi_0_k)
        grad_Gamma_1 = - 1 / alpha * (Gamma_1 + mat_Psi_1_k)

        difference_dual =  np.matrix.trace(grad_Gamma_0 @ delta_Gamma_0) + np.matrix.trace(grad_Gamma_1 @ delta_Gamma_1)
        if obj_new < obj_k + gamma * bar_eta_d * difference_dual and k <= 30:
            bar_eta_d *= beta
            k = k + 1
        else:
            break

    eta_p, eta_d = bar_eta_p, bar_eta_d

    return eta_p, eta_d

def compute_mu_k_Cournot(beth_k, Lambda1_k, Lambda2_k, xi_k, Gamma1_k, Gamma2_k):

    mu_k_reci = (np.matrix.trace(beth_k @ xi_k) + np.matrix.trace(Lambda1_k @ Gamma1_k)) / (
                beth_k.shape[0] * 3) + np.matrix.trace(Lambda2_k @ Gamma2_k) / 6
    # mu_k_reci = (np.matrix.trace(beth_k @ xi_k) + np.matrix.trace(Lambda1_k @ Gamma1_k)) / (
    #             beth_k.shape[0] * 2)
    mu_k = 1 / mu_k_reci

    return mu_k


def FOM_Game_Traffic_SDP(
        variables_0,
        Theta_true,
        dataset,
        np_capacities,
        n_arcs,
        p_set,
        squaring_param,
        regularizer,
        reg_param,
        callback = callback):
    pmin, pmax = p_set[0], p_set[1]
    Lambda0_0, Lambda1_0 = variables_0[0], variables_0[1]
    Gamma0_0, Gamma1_0 = variables_0[2], variables_0[3]

    check_regularizer(regularizer)
    check_reg_parameter(reg_param)

    # Warnings
    assert step == 'newton'

    # Get the dimension of the problem: len(theta_0) and the number of samples
    Lambda0_k, Lambda1_k, Gamma0_k, Gamma1_k = Lambda0_0, Lambda1_0, Gamma0_0, Gamma1_0

    # normalize each varible, why we should normalize the matrix?
    Lambda0_k, Lambda1_k, Gamma0_k, Gamma1_k = normalize_each_variable_traffic(Lambda0_k, Lambda1_k, Gamma0_k, Gamma1_k)

    callback_list = []
    if callback is not None:
        # Evaluate theta_0
        callback_list.append(callback([Lambda0_k, Lambda1_k, Gamma0_k, Gamma1_k]))

    alpha = reg_param
    Theta_norm = Theta_true / np.linalg.norm(Theta_true)

    N = dataset.shape[0]
    mu_k = compute_mu_k_traffic(Lambda0_k, Lambda1_k, Gamma0_k, Gamma1_k)
    # print('1/mu_0 is {}'.format(1/mu_k))
    epsilon = 0.00001 # Q1-how to set this value? need to read references
    k = 0
    ASL_loss_set, error_set = [], []
    mu_k_set = [mu_k]
    # mu_k = 2 * mu_k
    while 1 / mu_k > epsilon and k < 50: #1/mu_k > epsilon: mu_k < 1/epsilon
        print(f'********* Iteration {k+1} ***********')
        print('')
        print('1/mu_k_{} is {}'.format(k + 1, 1/mu_k))
        print('n/trace of Lambda_0 @ Gamma_0 is {}'.format(Lambda0_k.shape[0] / np.matrix.trace(Lambda0_k @ Gamma1_k)))
        print('n/trace of Lambda_1 @ Gamma_1 is {}'.format(Lambda1_k.shape[0] / np.matrix.trace(Lambda1_k @ Gamma1_k)))

        sample_idxs = np.random.choice(N, N, replace=False)
        samples = [dataset[i] for i in sample_idxs]

        ########### solve for the Newton's linear system   ###########
        ## compute \psi^{j}_{s} ##
        ## be careful!!!! the convert between \beth, \beth2 to theta!! need to check again!!!!!
        theta_k = convert_lambdas_to_theta_traffic(Lambda0_k, Lambda1_k)
        # print('theta_k is {}'.format(theta_k))

        theta_k_normed = theta_k / np.linalg.norm(theta_k)
        # print('normalized theta_k_{} is {}'.format(k, theta_k_normed))
        error_norm = np.linalg.norm(np.array(Theta_norm) - np.array(theta_k_normed))
        print('estimated normed error is {}'.format(error_norm))
        error_set.append(error_norm)

        loss_ASL_k, mat_Psi_0_k, mat_Psi_1_k, vec_v_j_norm_avg_k = compute_ASL_loss_traffic(Lambda0_k, Lambda1_k, samples, np_capacities, n_arcs, (pmin, pmax), squaring_param, alpha)

        ASL_loss_set.append(loss_ASL_k)
        print('ASL loss value is {}'.format(loss_ASL_k))

        z_k = (Lambda0_k, Lambda1_k, Gamma0_k, Gamma1_k)
        params_k = (mu_k, alpha, n_arcs)
        loss_k_set = (loss_ASL_k, mat_Psi_0_k, mat_Psi_1_k, vec_v_j_norm_avg_k)

        delta_Lambda0, delta_Lambda1, delta_Gamma0, delta_Gamma1 = solve_linear_systems_by_optimization(z_k, params_k, loss_k_set)
        # newton step: how to determine?
        delta_z = (delta_Lambda0, delta_Lambda1, delta_Gamma0, delta_Gamma1)

        eta_k, dual_eta_k = backtrack_traffic(z_k, delta_z, loss_k_set, samples, n_arcs, (pmin, pmax), squaring_param, alpha, beta=0.8, gamma = 0.5)

        Lambda0_k = Lambda0_k + eta_k * delta_Lambda0
        Lambda1_k = Lambda1_k + eta_k * delta_Lambda1
        Gamma0_k = Gamma0_k + dual_eta_k * delta_Gamma0
        Gamma1_k = Gamma1_k + dual_eta_k * delta_Gamma1

        Lambda0_k, Lambda1_k, Gamma0_k, Gamma1_k = normalize_each_variable_traffic(Lambda0_k, Lambda1_k, Gamma0_k, Gamma1_k)

        mu_k = compute_mu_k_traffic(Lambda0_k, Lambda1_k, Gamma0_k, Gamma1_k)
        k = k + 1
        mu_k_before = mu_k_set[-1]
        scaling = 1.2
        while  mu_k < mu_k_before:
            mu_k = scaling * mu_k
        mu_k_set.append(mu_k)

        callback_list.append(callback([Lambda0_k, Lambda1_k, Gamma0_k, Gamma1_k]))

    print(ASL_loss_set)
    print(error_set)
    mu_k_reci_set =[1 / i  for i in mu_k_set]
    print(mu_k_reci_set)
    return callback_list, ASL_loss_set, error_set

def intialize_variables_Traffic(n_arcs):

    Lambda_0_ele = np.random.uniform(0, 10, size=n_arcs)#np.random.rand(n_player, n_player)
    Lambda_0 = np.diag(Lambda_0_ele)
    assert is_semiPos_def(Lambda_0) == True


    Lambda_1_ele = np.random.uniform(0, 10, size=n_arcs)#np.random.rand(n_player, n_player)
    Lambda_1 = np.diag(Lambda_1_ele)
    assert is_semiPos_def(Lambda_1) == True


    Gamma_0_ele = np.random.uniform(0, 10, size=n_arcs)#np.random.rand(n_player, n_player)
    Gamma_0 = np.diag(Gamma_0_ele)
    assert is_semiPos_def(Gamma_0) == True

    Gamma_1_ele = np.random.uniform(0, 10, size=n_arcs)#np.random.rand(n_player, n_player)
    Gamma_1 = np.diag(Gamma_1_ele)
    assert is_semiPos_def(Gamma_1) == True

    return [Lambda_0, Lambda_1, Gamma_0, Gamma_1]


args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/traffic/', help = 'the root of data', type = str)
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args_parser.add_argument('--squaring', default = 10, help = 'random index', type = float)
args_parser.add_argument('--step', default = 'newton', help = 'the descent update method', type = str)
args_parser.add_argument('--regularizer', default = 'L2_squared', help = 'the regularizer term in our loss', type = str)
args_parser.add_argument('--normalize_grad', default = True, help = 'if gradient is normalized', type = bool)
args_parser.add_argument('--batch_ratio', default = 1.0, help = 'the batch size', type = float)
args_parser.add_argument('--time_limit', default = 0.05, help = 'the time limit in optimization', type = float)
args_parser.add_argument('--reg_param', default = 0.01, help = 'the coefficient of the regularizer loss', type = float)
args = args_parser.parse_args()

file_path = args.file_root
N_train = args.N

Theta_true_file = pd.read_csv(os.path.join(file_path, "thetas-true-N-" + str(N_train) + ".csv"))
# print(list(Theta_true_file))
theta_true = np.array(Theta_true_file[['theta_0', 'theta_1']])
Theta_true = theta_true.flatten() #a=matrix([[1, 2],[3, 4]]), a.flatten() = matrix([[1, 2, 3, 4]])
np_capacities = np.array(Theta_true_file['capacity'])

dataset_train_df = pd.read_csv(file_path + "dataset_train_Flow_N_"+str(N_train)+".csv", header = 0)
# dataset_test_df = pd.read_csv(file_path + 'dataset_test_u_'+ utility_type +'_N_' + str(N_train) + '_firstOrder.csv')
dataset_train = np.array(dataset_train_df)
# dataset_test = np.array(dataset_test_df)

## test if it works
dataset_train  = preprocessing.normalize(dataset_train)

# n_player = 2 # player number is 2
n_arcs = dataset_train.shape[1]
n_theta = 2

# pmax = math.ceil(max(np.max(dataset_train[:, 0]), np.max(dataset_train[:, 1])))
pmax = np.max(dataset_train)
pmin = np.min(dataset_train)

print(pmin, pmax)
normalize_grad = args.normalize_grad
batch_ratio = args.batch_ratio
time_limit = args.time_limit

step = args.step #'exponentiated'
regularizer = args.regularizer
squaring_param = args.squaring
reg_param = args.reg_param


if step == 'exponentiated':
    reg_param_alg = 1 / np.linalg.norm(np.array(Theta_true), 1) #theta_opt is computed based on the consistent algorithm
else:
    reg_param_alg = reg_param
# reg_param_alg = reg_param
save_path = './results/traffic/' + step + '_' + regularizer
if not os.path.exists(save_path):
    os.makedirs(save_path)

time_s = time.time()
run_set = [4]#
callbacks_runs = []
ASL_runs = []
for r_idx in range(len(run_set)):#range(n_runs):
    #### runs -- r #####
    r = run_set[r_idx]
    variables_set_r = intialize_variables_Traffic(n_arcs)
    print('Initial variables are ', variables_set_r)

    callback_results, ASL_Set, error_set = FOM_Game_Traffic_SDP(variables_set_r, Theta_true, dataset_train, np_capacities, n_arcs, (pmin, pmax),squaring_param,
                                                     regularizer, reg_param)

    print(callback_results)
    callbacks_runs.append(callback_results)
    ASL_runs.append(ASL_Set)
    ## save all-thetas ##
    thetas_iter_name = save_path + '/SDP_thetas_run_' + str(r) + '_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '.npy'
    np.save(thetas_iter_name, np.array(callback_results, dtype=object), allow_pickle=True)

thetas_ASL_name = save_path + '/SDP_losses_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step +'.csv'
runs_LOSS_np = np.array(ASL_runs)
pd.DataFrame(runs_LOSS_np).to_csv(thetas_ASL_name, index = False)
print('After running 5 exps, time spent {} minutes'.format((time.time()-time_s)/60))

##### plot the average result for ASL LOSS #####
assert runs_LOSS_np.shape[0] == len(callbacks_runs)
runs_average = runs_LOSS_np.mean(axis=0)     # to take the mean of each col
runs_std = runs_LOSS_np.std(axis=0)

plt.rcParams["mathtext.fontset"] = 'cm'
plt.rcParams['font.family'] = 'serif'
plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]

plt.figure(0)
plt.plot(range(1, len(runs_average) + 1), runs_average, label='ASL', color='red', linewidth=2)
plt.fill_between(range(1, len(runs_average) + 1), runs_average-runs_std, runs_average+runs_std, alpha=0.25, edgecolor='#FF4500', facecolor='#FE420F')
# plt.plot(range(1, len(err_T) + 1), np.repeat(1.0710639067698995, len(err_T)), label='Bertsimas')
plt.ylabel(
    'Loss Value', fontsize=18
)
plt.xlabel(r'Iterations of $ \vartheta $', fontsize=14)
plt.xlim(0, len(runs_average))
# plt.ylim(40, 80)
plt.grid(visible=True)
plt.legend(fontsize='16', loc='upper right')
plt.tight_layout()
# saving the figure.
plt.savefig(save_path + '/SDP_avgLoss_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train)
     + '_' + regularizer + '_' + step + '.png')
plt.show()

runs_error = [4]
for r_idx in range(len(run_set)): #range(n_runs):
    r = run_set[r_idx]
    callback_results = callbacks_runs[r_idx]
    Theta_estimated = callback_results[len(callback_results)-1][0]
    # error = np.linalg.norm(np.array(Theta_true) - np.array(Theta_estimated))
    # print('True theas is ', Theta_true)
    # print('Estimated error is {}'.format(error)) #Estimated error is 2.9614639158104348

    Theta_norm = Theta_true / np.linalg.norm(Theta_true)
    # Theta_estimated_norm = Theta_estimated/np.linalg.norm(Theta_estimated)
    # error_norm = np.linalg.norm(np.array(Theta_norm) - np.array(Theta_estimated_norm))
    # print('Estimated error (all normalize to l2-norm) is {}'.format(error_norm)) #Estimated error (all normalize to l2-norm) is 0.9603612684936694

    ##### plot all theta_t ######
    err_T = []
    for i in range(1, len(callback_results)):
        theta_t = callback_results[i][0]
        lambda_0_t = theta_t[0]
        lambda_1_t = theta_t[1]
        theta_t = convert_lambdas_to_theta_traffic(lambda_0_t, lambda_1_t)

        theta_t_norm = theta_t/np.linalg.norm(theta_t)
        error_t = np.linalg.norm(np.array(Theta_norm) - np.array(theta_t_norm))
        err_T.append(error_t)

        print('t is {}'.format(i))
        print('error_theta_t is {}'.format(error_t))

    runs_error.append(err_T)
    plt.rcParams["mathtext.fontset"] = 'cm'
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]

    plt.figure()
    plt.plot(range(1, len(err_T) + 1), err_T, label='ASL', color='red', linewidth=2)
    # plt.plot(range(1, len(err_T) + 1), np.repeat(1.0710639067698995, len(err_T)), label='Bertsimas')
    plt.ylabel(
        r'$\| \vartheta_{\mathrm{esti}} - \vartheta_{\mathrm{true}} \|_2$', fontsize=18
    )
    plt.xlabel(r'Iterations of $ \vartheta $', fontsize=14)
    plt.xlim(0, len(err_T))
    # plt.ylim(0.5, 1.2)
    plt.grid(visible=True)
    plt.legend(fontsize='16', loc='upper right')
    plt.tight_layout()
    # saving the figure.
    plt.savefig(save_path + '/SDP_thetas_run_' + str(r) + '_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step  +'.png')
    plt.show()
    plt.close()

# ##### plot the average result #####
# runs_error_np = np.array(runs_error)
# assert runs_error_np.shape[0] == len(runs_error)
# runs_average = runs_error_np.mean(axis=0)     # to take the mean of each col
# runs_std = runs_error_np.std(axis=0)
#
# plt.rcParams["mathtext.fontset"] = 'cm'
# plt.rcParams['font.family'] = 'serif'
# plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]
#
# plt.figure(1)
# plt.plot(range(1, len(runs_average) + 1), runs_average, label='ASL', color='red', linewidth=2)
# plt.fill_between(range(1, len(runs_average) + 1), runs_average-runs_std, runs_average+runs_std, alpha=0.25, edgecolor='#FF4500', facecolor='#FE420F')
# # plt.plot(range(1, len(err_T) + 1), np.repeat(1.0710639067698995, len(err_T)), label='Bertsimas')
# plt.ylabel(
#     r'$\| \vartheta_{\mathrm{esti}} - \vartheta_{\mathrm{true}} \|_2$', fontsize=18
# )
# plt.xlabel(r'Iterations', fontsize=14)
# plt.xlim(0, len(runs_average))
# # plt.ylim(0.5, 1.2)
# plt.grid(visible=True)
# plt.legend(fontsize='16', loc='upper right')
# plt.tight_layout()
# # saving the figure.
# plt.savefig(save_path + '/SDP_avgThetas_squaring_' + str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '.png')
# plt.show()






