#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

import numpy as np
import gurobipy as gp


def check_Theta(Theta):
    """Check if Theta is valid."""
    if Theta not in [None, 'nonnegative']:
        raise Exception(
            'Invalid Theta. Accepted values are: None (default)'
            'and \'nonnegative\'.'
        )

def check_regularizer(regularizer):
    """Check if regularizer is valid."""
    if regularizer not in ['L2_squared', 'L1']:
        raise Exception(
            'Invalid regularizer. Accepted values are:'
            ' \'L2_squared\' (default) and \'L1\'.'
        )

def check_reg_parameter(reg_param):
    """Check if reg_param is valid."""
    if reg_param < 0:
        raise Exception('reg_param must be nonnegative.')


def warning_theta_hat_reg_param(theta_hat, reg_param):
    """Warn user theta_hat is not used when reg_param=0."""
    if (theta_hat is not None) and (reg_param == 0):
        warnings.warn('theta_hat is not used when reg_param=0.')

def phi_func(pstar_j, xi_j):
    p1, p2 = pstar_j
    phi_1 = [2*p1, p2, xi_j, 1]
    phi_2 = [p1, 2*p2, xi_j, 1]

    phi_j = phi_1 + phi_2

    return np.array(phi_j), np.array(phi_1), np.array(phi_2)
def FOP_game(n_player, pmax, theta, p1_hat, p2_hat, xi_hat, squaring_param, gurobi_params=None):

    # n_player = 2
    each_theta_len = int(len(theta)/n_player)
    # n = n_player

    mdl = gp.Model('FOP-Game')
    mdl.setParam('OutputFlag', 0) ### should see the method

    x = mdl.addVars(n_player, vtype=gp.GRB.CONTINUOUS, name='x')

    phi_j, phi_j_1, phi_j_2 = phi_func((p1_hat, p2_hat), xi_hat)
    assert phi_j.shape[0] == (each_theta_len * n_player)

    theta_reshape = theta.reshape(each_theta_len, -1) #each_theta_len * n_Player
    assert theta_reshape.shape[0] == each_theta_len
    phi_j_reshape = phi_j.reshape(each_theta_len, -1)#each_theta_len * n_Player
    assert phi_j_reshape.shape[0] == each_theta_len

    res_1_phi = []
    for i in range(n_player):
        res_1_phi.append(np.inner(theta_reshape[:, i], phi_j_reshape[:, i]))

    x_hat_j = np.array([p1_hat, p2_hat])
    # Compute the difference (x^j - \hat{x}^j)
    # diff = [x[i] - x_hat_j[i] for i in range(n_player)]
    # # Compute the Kronecker product of I_n and (x^j - \hat{x}^j)
    # kronecker_product = []
    # for d in diff:
    #     for i in range(each_theta_len):
    #         kronecker_product.append(d)
    # assert len(kronecker_product) == each_theta_len * n_player
    # # Compute the Hadamard product with phi^j
    # hadamard_product = [phi_j[i] * kronecker_product[i] for i in range(each_theta_len * n_player)]
    # # Compute the Euclidean norm (2-norm)
    # euclidean_norm = gp.quicksum(hadamard_product[i] * hadamard_product[i] for i in range(each_theta_len * n_player))
    # mdl.setObjective(
    #     gp.quicksum(res_1_phi[i] * (x[i] - x_hat_j[i]) for i in range(n_player))
    #     + euclidean_norm, gp.GRB.MAXIMIZE)
    res_2_phi = []
    for i in range(n_player):
        # print(i)
        res_2_phi.append(np.inner(phi_j_reshape[:, i], phi_j_reshape[:, i]))# np.linalg.norm(phi_j_reshape[:, i]
        # print(res_2_phi)
    # print(affff)
    objective_1 = gp.quicksum(res_1_phi[i] * (x[i] - x_hat_j[i]) for i in range(n_player))
    objective_2 = gp.quicksum(res_2_phi[i] * (x[i] - x_hat_j[i]) * (x[i] - x_hat_j[i]) for i in range(n_player))
    # objective_2_approxi = gp.quicksum((2 * res_2_phi[i] * x_hat_j[i] - 1) * x[i] for i in range(n_player))

    mdl.setObjective(objective_1 + squaring_param * objective_2, gp.GRB.MAXIMIZE) #0.001 *

    mdl.addConstrs(x[i] >= 0 for i in range(n_player)) ### the constraints to equilibrium prices
    mdl.addConstrs(x[i] <= pmax for i in range(n_player))

    if gurobi_params is not None:
        for param, value in gurobi_params:
            mdl.setParam(param, value)

    # mdl.setParam(gp.GRB.Param.InfUnbdInfo, 1)
    mdl.optimize()
    # print(mdl.get('GRB_IntAttr_Status'))
    # print("status", mdl.Status)
    if mdl.status == 4:
        print("The model is infeasible or Unbounded; computing IIS")
        # mdl.computeIIS() #Cannot compute IIS on a feasible model
        # mdl.write("model.ilp")
        # print("IIS written to 'model.ilp'")
        # print("The model is unbounded.")
        print(mdl.getParamInfo(gp.GRB.Param.InfUnbdInfo))
        unbd_ray = mdl.getAttr("UnbdRay", x)
        print("Unbounded ray direction for x^j:", unbd_ray)

    # print(mdl.status)
    # print(afffff)
    if mdl.status == 2:
        x_opt = np.array([x[k].X for k in range(n_player)])
        # print(x_opt)
    elif mdl.status == 9:
        # Time limit reched. Return vector a all ones
        x_opt = np.ones(n_player)
        assert 1 == 0
    else:
        raise Exception(
            f'Optimal solution not found. Gurobi status code = {mdl.status}.'
        )
    # print(x_opt)
    # help(mdl)
    # print(x_opt)
    # print(mdl.getParamInfo('Method'))
    # #('Method', <class 'int'>, -1, -1, 5, -1) FOR QP, the default method is Method = 2 (barrier)
    # print(afffffff)
    return x_opt


def ASL(
    theta,
    dataset,
    n_player,
    pmax,
    regularizer='L2_squared',
    reg_param=0,
    squaring_param = 1,
    theta_hat=None,
    ):
    """
    Evaluate Augmented Suboptimality loss.

    Parameters
    ----------
    theta : 1D ndarray
        Cost vector.
    dataset : array-like, shape (n_samples, n_features),
              each row is that  p1_j, p2_j, xi_j
    regularizer : {'L2_squared', 'L1'}, optional
        Type of regularization on cost vector theta. The default is
        'L2_squared'.
    reg_param : float, optional
        Nonnegative regularization parameter. The default is 0.
    theta_hat : {1D ndarray, None}, optional
        A priory belief or estimate of the true cost vector theta. The default
        is None.

    Raises
    ------
    Exception
        If invalid regularization parameter. If negative regularization
        parameter.

    Returns
    -------
    float
        Augmented suboptimality loss value.

    """
    # Check if the inputs are valid
    check_regularizer(regularizer)
    check_reg_parameter(reg_param)

    if theta_hat is None:
        theta_hat = 0

    if regularizer == 'L2_squared':
        reg_term = (reg_param/2)*np.linalg.norm(theta - theta_hat)**2
    elif regularizer == 'L1':
        reg_term = reg_param*np.linalg.norm(theta - theta_hat, 1)

    N = len(dataset)
    loss = 0
    # for i in range(N):
    #     s_hat, x_hat = dataset[i]
    #     x = FOP_aug(theta, s_hat, x_hat)
    #     phi_diff = phi(s_hat, x_hat) - phi(s_hat, x)
    #     try:
    #         dist = dist_func(x_hat, x)
    #     except TypeError:
    #         dist = dist_func(x_hat, x, s_hat)
    #
    #     loss += theta @ phi_diff + dist
    for i in range(N):
        # Check if the FOP is augmented
        p1_hat, p2_hat, xi_hat = dataset[i]
        # print(p1_hat, p2_hat, xi_hat)
        x_hat = np.array([p1_hat, p2_hat])

        # solve a approximate solution to the original Incenter-loss-term
        x_opt = FOP_game(n_player, pmax, theta, p1_hat, p2_hat, xi_hat, squaring_param)

        phi_j, _, _ = phi_func((p1_hat, p2_hat), xi_hat)
        # n_player = 2
        each_theta_len = int(len(theta) / n_player)
        I_n = np.ones(each_theta_len)
        temp_m = np.kron(I_n, (x_opt - x_hat))
        loss_Euclidean = np.linalg.norm(phi_j * temp_m.reshape(-1, order='F'))# * means element-size multiplication
        loss_Euclidean_squaring = loss_Euclidean ** 2

        theta_reshape = theta.reshape(each_theta_len, -1)  # each_theta_len * n_Player
        assert theta_reshape.shape[0] == each_theta_len
        phi_j_reshape = phi_j.reshape(each_theta_len, -1)  # each_theta_len * n_Player
        assert phi_j_reshape.shape[0] == each_theta_len
        res_1_phi = []
        for i in range(n_player):
            res_1_phi.append(np.inner(theta_reshape[:, i], phi_j_reshape[:, i]))
        loss_linear = np.inner(res_1_phi, (x_opt - x_hat))

        loss = loss + loss_Euclidean + loss_linear
        # loss = loss + loss_Euclidean_squaring * squaring_param + loss_linear

    return reg_term + (1/N)*loss
