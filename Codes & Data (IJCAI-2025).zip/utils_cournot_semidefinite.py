#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

import numpy  as np
import pandas as pd
from scipy.linalg import issymmetric
import time

from utils_cournot_incenter import FOP_game_Cournot, phi_func_Cournot_five_firms
from utils_cournot_incenter import phi_func_Cournot

def convert_beth_to_theta_Cournot(beth, Lambda_1, Lambda_2):

    thetas = [beth[0, 1], Lambda_2[0, 0], Lambda_2[1, 1]]
    cost_set = list(np.diag(Lambda_1)) # is a list
    assert len(cost_set) == Lambda_1.shape[0]
    # print(thetas)
    # print(cost_set)

    thetas = thetas + cost_set
    # print(thetas)
    # print(affff)
    return thetas

def is_semiPos_def(X):# ONLY FOR SYMMETRIC MATRIX#
    # print(X)
    if issymmetric(X):
        return np.all(np.linalg.eigvals(X) >= 0)
    else:
        X_new = X + X.transpose()
        return np.all(np.linalg.eigvals(X_new) >= 0)

def compute_ASL_loss_Cournot(beth, Lambda_1, Lambda_2, samples, n_player, qmax, squaring_param, alpha):

    theta = convert_beth_to_theta_Cournot(beth, Lambda_1, Lambda_2)
    theta = theta / np.linalg.norm(theta)

    if n_player == 3:
        psi_0_j_set, psi_1_j_set, psi_2_j_set, vec_v_j_norm_avg = compute_psi_j_set_using_data_Cournot(samples, n_player,
                                                                                                  qmax,
                                                                                                  np.array(theta),
                                                                                                  squaring_param)
    if n_player == 5:
        psi_0_j_set, psi_1_j_set, psi_2_j_set, vec_v_j_norm_avg = compute_psi_j_set_using_data_Cournot_five_firms(
            samples, n_player,
            qmax,
            np.array(theta),
            squaring_param)

    mat_Psi_0 = np.mean(psi_0_j_set, axis=0)  # 1/N(\sum_{i=1}^{N}psi_j)
    mat_Psi_1 = np.mean(psi_1_j_set, axis=0)
    mat_Psi_2 = np.mean(psi_2_j_set, axis=0)

    assert mat_Psi_0.shape[0] == n_player
    assert mat_Psi_1.shape[0] == n_player
    assert mat_Psi_2.shape[0] == 2

    assert issymmetric(mat_Psi_0) == True
    assert issymmetric(mat_Psi_1) == True
    assert issymmetric(mat_Psi_2) == True

    # ASL loss
    loss_ASL = (0.5 * alpha * (np.linalg.norm(beth, 'fro') ** 2) + 1/(2 * n_player) * np.matrix.trace(mat_Psi_0 @ beth)
                + 0.5 * alpha * (np.linalg.norm(Lambda_1, 'fro') ** 2) + np.matrix.trace(mat_Psi_1 @ Lambda_1)
                + 0.5 * alpha * (np.linalg.norm(Lambda_2, 'fro') ** 2) + np.matrix.trace(mat_Psi_2 @ Lambda_2)
                + vec_v_j_norm_avg)

    return loss_ASL, mat_Psi_0, mat_Psi_1, mat_Psi_2, vec_v_j_norm_avg


def normalize_each_variable_Cournot(beth, Lambda1, Lambda2, xi, Gamma1, Gamma2):

    beth_nor = beth / np.linalg.norm(beth, 'fro')
    Lambda1_nor = Lambda1 / np.linalg.norm(Lambda1, 'fro')
    Lambda2_nor = Lambda2 / np.linalg.norm(Lambda2, 'fro')
    xi_nor = xi / np.linalg.norm(xi, 'fro')
    Gamma1_nor = Gamma1 / np.linalg.norm(Gamma1, 'fro')
    Gamma2_nor = Gamma2 / np.linalg.norm(Gamma2, 'fro')

    return beth_nor, Lambda1_nor, Lambda2_nor, xi_nor, Gamma1_nor, Gamma2_nor


def callback(theta):
    """Store input and current time."""
    return theta, time.time()

def compute_psi_j_set_using_data_Cournot(samples, n_player, qmax, theta_t, squaring_param):
    psi_0_j_set, psi_1_j_set, psi_2_j_set = [], [], []
    vec_v_j_norm_set = []
    for q1_hat, q2_hat, q3_hat, xi_hat in samples:
        # Check if the FOP is augmented
        # print(p1_hat, p2_hat, xi_hat)
        x_hat = np.array([q1_hat, q2_hat, q3_hat])
        data_j = (q1_hat, q2_hat, q3_hat, xi_hat)
        try:
            x_opt = FOP_game_Cournot(n_player, qmax, theta_t, data_j, squaring_param)
            # print(x_opt)
            # print('distance between x and \hat{x} is', np.linalg.norm(x_opt - x_hat))
        except TypeError:
            print('there is sth wrong with the gradient computation..., please check them')


        phi_j, _, _, _ = phi_func_Cournot((q1_hat, q2_hat, q3_hat), xi_hat)

        # n_player = 2
        each_theta_len = len(theta_t)
        I_n = np.ones(each_theta_len)
        temp_m = np.kron(I_n, (x_opt - x_hat))

        # Need to modify the following codes
        vec_v_j_temp = phi_j * temp_m.reshape(-1, order='F')# * means element-size multiplication
        vec_v_j_temp_reshape = vec_v_j_temp.reshape(-1, len(theta_t))
        vec_v_j = np.sum(vec_v_j_temp_reshape, axis=0)
        # print(vec_v_j)
        # print(vec_v_j[0])
        psi_0_ele = np.repeat(vec_v_j[0], n_player)
        psi_0_j = np.diag(psi_0_ele) ## be careful! need to check again!!!
        psi_1_j = np.diag(vec_v_j[3:])
        psi_2_j = np.diag(np.array([vec_v_j[1], vec_v_j[2]]))

        psi_0_j_set.append(psi_0_j)
        psi_1_j_set.append(psi_1_j)
        psi_2_j_set.append(psi_2_j)

        vec_v_j_norm_set.append(np.linalg.norm(vec_v_j, 2))

    vec_v_j_norm_avg = np.mean(vec_v_j_norm_set)

    return  psi_0_j_set, psi_1_j_set, psi_2_j_set, vec_v_j_norm_avg

def compute_psi_j_set_using_data_Cournot_five_firms(samples, n_player, qmax, theta_t, squaring_param):
    psi_0_j_set, psi_1_j_set, psi_2_j_set, psi_3_j_set, psi_4_j_set = [], [], [], [], []
    vec_v_j_norm_set = []
    for q1_hat, q2_hat, q3_hat, q4_hat, q5_hat, xi_hat in samples:
        # Check if the FOP is augmented
        # print(p1_hat, p2_hat, xi_hat)
        x_hat = np.array([q1_hat, q2_hat, q3_hat, q4_hat, q5_hat])
        data_j = (q1_hat, q2_hat, q3_hat, q4_hat, q5_hat, xi_hat)
        try:
            x_opt = FOP_game_Cournot(n_player, qmax, theta_t, data_j, squaring_param)
            # print(x_opt)
            # print('distance between x and \hat{x} is', np.linalg.norm(x_opt - x_hat))
        except TypeError:
            print('there is sth wrong with the gradient computation..., please check them')


        phi_j, _, _, _, _, _ = phi_func_Cournot_five_firms((q1_hat, q2_hat, q3_hat, q4_hat, q5_hat), xi_hat)

        # n_player = 2
        each_theta_len = len(theta_t)
        I_n = np.ones(each_theta_len)
        temp_m = np.kron(I_n, (x_opt - x_hat))

        # Need to modify the following codes
        vec_v_j_temp = phi_j * temp_m.reshape(-1, order='F')# * means element-size multiplication
        vec_v_j_temp_reshape = vec_v_j_temp.reshape(-1, len(theta_t))
        vec_v_j = np.sum(vec_v_j_temp_reshape, axis=0)
        # print(vec_v_j)
        # print(vec_v_j[0])
        psi_0_ele = np.repeat(vec_v_j[0], n_player)
        psi_0_j = np.diag(psi_0_ele) ## be careful! need to check again!!!
        psi_1_j = np.diag(vec_v_j[3:])
        psi_2_j = np.diag(np.array([vec_v_j[1], vec_v_j[2]]))

        psi_0_j_set.append(psi_0_j)
        psi_1_j_set.append(psi_1_j)
        psi_2_j_set.append(psi_2_j)

        vec_v_j_norm_set.append(np.linalg.norm(vec_v_j, 2))

    vec_v_j_norm_avg = np.mean(vec_v_j_norm_set)

    return  psi_0_j_set, psi_1_j_set, psi_2_j_set, vec_v_j_norm_avg

def zero_to_nan(array):
    array[array == 0] = np.NaN
    return array