#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

######### INCORPORATE PRIOR KNOWLEDGE OF THETA ###########
import os
import argparse
import random

import numpy as np
import pandas as pd
import time, math
import warnings
import gurobipy as gp
import matplotlib.pyplot as plt
import scipy.linalg
import cvxpy as cp

from utils_bertrand_incenter import check_reg_parameter
from utils_bertrand_incenter import check_regularizer
from scipy.optimize import fsolve

from utils_bertrand_semidefinite import convert_beth_to_theta
from utils_bertrand_semidefinite import is_semiPos_def
from utils_bertrand_semidefinite import compute_asl_loss
from utils_bertrand_semidefinite import normalize_each_variable
from utils_bertrand_semidefinite import callback
from utils_bertrand_semidefinite import zero_to_nan


def F(z, params, Psi_set):
    beth, tilde_beth, Xi, tilde_Xi, lambdas = z
    mu, alpha, A, e_set = params
    Psi_s, tilde_Psi_s = Psi_set

    e0, e1 = e_set
    # e0 = np.eye(1,2,0)[0] #array([1., 0.])
    # e1 = np.eye(1,2,1)[0]# array([0., 1.])

    # Define each equation
    eq1 = np.matrix.trace(A @ beth) + 1

    # in numpy, row vector and column vector are the same thing, using np.outer(e1, e1)
    # eq2 = lambdas[0] * np.matrix.trace(np.outer(e0, e0) @ beth) - 1/mu
    eq2 = lambdas[0] * np.matrix.trace(np.outer(e0, e0) @ beth) - np.matrix.trace(Xi @ beth) / beth.shape[0]

    # eq3 = lambdas[1] * np.matrix.trace(np.outer(e1, e1) @ beth) - 1 / mu
    eq3 = lambdas[1] * np.matrix.trace(np.outer(e1, e1) @ beth) - np.matrix.trace(Xi @ beth) / beth.shape[0]

    eq4 = Xi @ beth - (1 / mu) * np.eye(beth.shape[0])

    eq5 = tilde_Xi @ tilde_beth - (1 / mu) * np.eye(tilde_beth.shape[0])
    # eq4 = Xi @ beth + beth @ Xi - (2 / mu) * np.eye(beth.shape[0]) #to ensure that the variable matrices are symmetric!!!!
    # eq5 = tilde_Xi @ tilde_beth + tilde_beth @ tilde_Xi - (2 / mu) * np.eye(tilde_beth.shape[0])

    eq6_term_0 = alpha * beth - (lambdas[0] * np.outer(e0, e0) + lambdas[1] * np.outer(e1, e1)) - Xi - Psi_s
    v = (np.matrix.trace((Psi_s + (lambdas[0] * np.outer(e0, e0) + lambdas[1] * np.outer(e1, e1)) + Xi) @ A) + alpha)/(np.linalg.norm(A, 'fro') ** 2)
    eq6 = eq6_term_0 + v * A

    eq7 = alpha * tilde_beth - tilde_Xi + tilde_Psi_s

    return (eq1, eq2, eq3, eq4, eq5, eq6, eq7)
    # return np.hstack([np.array([eq1]), np.array([eq2]), np.array([eq3]), eq4.flatten(), eq5.flatten(), eq6.flatten(), eq7.flatten()])



def solve_linear_systems(z_k, params_k, loss_k_set):
    _, mat_Psi_s_k, mat_tilde_Psi_s_k, vec_v_j_norm_avg_k = loss_k_set
    beth_k, tilde_beth_k, Xi_k, tilde_Xi_k, lambdas_k = z_k
    mu_k, alpha, A, e_set = params_k
    e0, e1 = e_set

    initial_beth = np.ones([beth_k.shape[0], beth_k.shape[1]])
    initial_tilde_beth = np.ones([tilde_beth_k.shape[0], tilde_beth_k.shape[1]])
    initial_xi = np.ones([Xi_k.shape[0], Xi_k.shape[1]])
    initial_tilde_Xi = np.ones([tilde_Xi_k.shape[0], tilde_Xi_k.shape[1]])
    initial_lambdas = np.array([1, 1])
    initial_guess = np.hstack([initial_beth.flatten(), initial_tilde_beth.flatten(), initial_xi.flatten(), initial_tilde_Xi.flatten(),
               initial_lambdas])

    res_k = F(z_k, params_k, (mat_Psi_s_k, mat_tilde_Psi_s_k))
    eq1_k, eq2_k, eq3_k, eq4_k, eq5_k, eq6_k, eq7_k = res_k
    def equations(z_flatten):
        # Compute sizes
        beth_size = np.prod(beth_k.shape)
        tilde_beth_size = np.prod(tilde_beth_k.shape)
        Xi_size = np.prod(Xi_k.shape)
        tilde_Xi_size = np.prod(tilde_Xi_k.shape)
        # lambdas_size = np.prod(lambdas_shape)
        # Unpack the flattened array into variables
        beth_flatten = z_flatten[:beth_size]
        tilde_beth_flatten = z_flatten[beth_size: (beth_size + tilde_beth_size)]
        Xi_flatten = z_flatten[(beth_size + tilde_beth_size) : (beth_size + tilde_beth_size + Xi_size)]
        tilde_Xi_flatten = z_flatten[(beth_size + tilde_beth_size + Xi_size): (beth_size + tilde_beth_size + Xi_size + tilde_Xi_size)]
        lambdas = z_flatten[(beth_size + tilde_beth_size + Xi_size + tilde_Xi_size):]

        # Reshape flattened variables back to their original shapes
        beth = beth_flatten.reshape(beth_k.shape)
        tilde_beth = tilde_beth_flatten.reshape(tilde_beth_k.shape)
        Xi = Xi_flatten.reshape(Xi_k.shape)
        tilde_Xi = tilde_Xi_flatten.reshape(tilde_Xi_k.shape)

        f1 = np.matrix.trace(A @ beth) + eq1_k
        # f2 = lambdas_k[0] * np.matrix.trace(np.outer(e0, e0) @ beth) + np.matrix.trace(np.outer(e0, e0) @ beth_k) * lambdas[0]
        f2 = lambdas_k[0] * np.matrix.trace((np.outer(e0, e0) - (1/beth.shape[0]) * Xi_k.transpose()) @ beth) + np.matrix.trace(np.outer(e0, e0) @ beth_k) * \
             lambdas[0] - np.matrix.trace((1/beth_k.shape[0]) * beth_k.transpose() @ Xi)
        f2 = f2 + eq2_k

        # f3 = lambdas_k[1] * np.matrix.trace(np.outer(e1, e1) @ beth) + np.matrix.trace(np.outer(e1, e1) @ beth_k) * lambdas[1]
        f3 = lambdas_k[1] * np.matrix.trace((np.outer(e1, e1) - (1/beth_k.shape[0]) * Xi_k.transpose()) @ beth) + np.matrix.trace(np.outer(e1, e1) @ beth_k) * \
             lambdas[1] - np.matrix.trace((1/beth_k.shape[0]) * beth_k.transpose() @ Xi)
        f3 = f3 + eq3_k
        f3 = f3 + f2 # be careful with this

        f4 = Xi_k @ beth + Xi @ beth_k
        f4 = f4 + eq4_k
        #
        # f5 = tilde_Xi_k @ tilde_beth + tilde_Xi @ tilde_beth_k
        # f5 = f5 + eq5_k

        f5 = tilde_Xi_k @ tilde_beth + tilde_Xi @ tilde_beth_k - (Xi_k @ beth + Xi @ beth_k)
        f5 = f5 + eq5_k - eq4_k

        # f4 = Xi_k @ beth + Xi @ beth_k + Xi @ beth_k + beth_k @ Xi
        # f4 = f4 + eq4_k

        # f5= tilde_Xi_k @ tilde_beth + tilde_Xi @ tilde_beth_k + tilde_Xi @ tilde_beth_k + tilde_beth_k @ Xi
        # f5 = f5 + eq5_k

        f6_co_1 = -np.eye(A.shape[0]) + ((np.transpose(A) @ A )/(np.linalg.norm(A, 'fro')**2))
        f6_co_2 = -np.outer(e0, e0) + (np.matrix.trace(np.outer(e0, e0) @ A)/(np.linalg.norm(A, 'fro')**2)) * A
        f6_co_3 = -np.outer(e1, e1) + (np.matrix.trace(np.outer(e1, e1) @ A)/(np.linalg.norm(A, 'fro')**2)) * A
        f6 = alpha * beth + f6_co_1 @ Xi + f6_co_2 * lambdas[0] + f6_co_3 * lambdas[1]
        f6 = f6 + eq6_k

        f7 = alpha * tilde_beth - tilde_Xi
        f7 = f7 + eq7_k

        # return [f1, f2 , f3, f4, f5, f6, f7]np.array(f2),
        return np.hstack([np.array(f1), np.array(f3), f4.flatten(), f5.flatten(), f6.flatten(), f7.flatten()])
        # np.hstack([eq1.flatten(), eq2.flatten()])

    # Solve the system of equations
    solution = fsolve(equations, initial_guess)
    # solution_result = root(equations, initial_guess, method='df-sane')
    # solution = solution_result.x
    # Extract the solutions and reshape them
    beth_size = np.prod(beth_k.shape)
    tilde_beth_size = np.prod(tilde_beth_k.shape)
    Xi_size = np.prod(Xi_k.shape)
    tilde_Xi_size = np.prod(tilde_Xi_k.shape)
    # lambdas_size = np.prod(lambdas_k.shape)

    beth_solution = solution[:beth_size].reshape(beth_k.shape)
    tilde_beth_solution = solution[beth_size : (beth_size + tilde_beth_size)].reshape(tilde_beth_k.shape)
    Xi_solution = solution[(beth_size + tilde_beth_size) : (beth_size + tilde_beth_size + Xi_size)].reshape(Xi_k.shape)
    tilde_Xi_solution = solution[
                        (beth_size + tilde_beth_size + Xi_size) : (beth_size + tilde_beth_size + Xi_size + tilde_Xi_size)].reshape(
        tilde_Xi_k.shape)
    lambdas_solution = solution[(beth_size + tilde_beth_size + Xi_size + tilde_Xi_size):]

    ### to ensure the symmetry ###
    delta_beth_solution, delta_tilde_beth_solution, delta_Xi_solution, delta_tilde_Xi_solution, delta_lambdas_solution = normalize_each_variable(
        beth_solution, tilde_beth_solution, Xi_solution, tilde_Xi_solution, lambdas_solution)

    print("Solution for delta_beth:\n", delta_beth_solution)
    print("Solution for delta_tilde_beth:\n", delta_tilde_beth_solution)
    print("Solution for delta_Xi:\n", delta_Xi_solution)
    print("Solution for delta_tilde_Xi:\n", delta_tilde_Xi_solution)
    print("Solution for delta_lambdas:\n", delta_lambdas_solution)

    # delta_beth_solution = (1/2) * (delta_beth_solution + delta_beth_solution.transpose())
    # delta_tilde_beth_solution = (1/2) * (delta_tilde_beth_solution + delta_tilde_beth_solution.transpose())
    # delta_Xi_solution = (1 / 2) * (delta_Xi_solution + delta_Xi_solution.transpose())
    # delta_tilde_Xi_solution = (1/2) * (delta_tilde_Xi_solution + delta_tilde_Xi_solution.transpose())
    # delta_lambdas_solution = delta_lambdas_solution

    # print("Solution for delta_beth:\n", delta_beth_solution)
    # print("Solution for delta_tilde_beth:\n", delta_tilde_beth_solution)
    # print("Solution for delta_Xi:\n", delta_Xi_solution)
    # print("Solution for delta_tilde_Xi:\n", delta_tilde_Xi_solution)
    # print("Solution for delta_lambdas:\n", delta_lambdas_solution)


    return delta_beth_solution, delta_tilde_beth_solution, delta_Xi_solution, delta_tilde_Xi_solution, delta_lambdas_solution


def solve_linear_systems_by_optimization(z_k, params_k, loss_k_set):
    _, mat_Psi_s_k, mat_tilde_Psi_s_k, vec_v_j_norm_avg_k = loss_k_set
    beth_k, tilde_beth_k, Xi_k, tilde_Xi_k, lambdas_k = z_k
    mu_k, alpha, A, e_set = params_k
    e0, e1 = e_set

    res_k = F(z_k, params_k, (mat_Psi_s_k, mat_tilde_Psi_s_k))
    eq1_k, eq2_k, eq3_k, eq4_k, eq5_k, eq6_k, eq7_k = res_k

    # Reshape flattened variables back to their original shapes
    beth = cp.Variable(beth_k.shape, symmetric= True)
    tilde_beth = cp.Variable(tilde_beth_k.shape, symmetric= True)
    Xi = cp.Variable(Xi_k.shape, symmetric= True)
    tilde_Xi = cp.Variable(tilde_Xi_k.shape, symmetric= True)
    lambdas = cp.Variable(lambdas_k.shape, pos=True)

    f1 = cp.trace(A @ beth) + eq1_k
    # f2 = lambdas_k[0] * np.matrix.trace(np.outer(e0, e0) @ beth) + np.matrix.trace(np.outer(e0, e0) @ beth_k) * lambdas[0]
    f2 = lambdas_k[0] * cp.trace((np.outer(e0, e0) - (1/beth.shape[0]) * Xi_k.transpose()) @ beth) + cp.trace(np.outer(e0, e0) @ beth_k) * \
         lambdas[0] - cp.trace((1/beth_k.shape[0]) * beth_k.transpose() @ Xi)
    f2 = f2 + eq2_k

    # f3 = lambdas_k[1] * np.matrix.trace(np.outer(e1, e1) @ beth) + np.matrix.trace(np.outer(e1, e1) @ beth_k) * lambdas[1]
    f3 = lambdas_k[1] * cp.trace((np.outer(e1, e1) - (1/beth_k.shape[0]) * Xi_k.transpose()) @ beth) + cp.trace(np.outer(e1, e1) @ beth_k) * \
         lambdas[1] - cp.trace((1/beth_k.shape[0]) * beth_k.transpose() @ Xi)
    f3 = f3 + eq3_k
    # f3 = f3 + f2 # be careful with this

    f4 = Xi_k @ beth + Xi @ beth_k
    f4 = f4 + eq4_k
    #
    # f5 = tilde_Xi_k @ tilde_beth + tilde_Xi @ tilde_beth_k
    # f5 = f5 + eq5_k

    f5 = tilde_Xi_k @ tilde_beth + tilde_Xi @ tilde_beth_k - (Xi_k @ beth + Xi @ beth_k)
    f5 = f5 + eq5_k - eq4_k

    # f4 = Xi_k @ beth + Xi @ beth_k + Xi @ beth_k + beth_k @ Xi
    # f4 = f4 + eq4_k

    # f5= tilde_Xi_k @ tilde_beth + tilde_Xi @ tilde_beth_k + tilde_Xi @ tilde_beth_k + tilde_beth_k @ Xi
    # f5 = f5 + eq5_k

    f6_co_1 = -np.eye(A.shape[0]) + ((np.transpose(A) @ A )/(np.linalg.norm(A, 'fro')**2))
    f6_co_2 = -np.outer(e0, e0) + (np.matrix.trace(np.outer(e0, e0) @ A)/(np.linalg.norm(A, 'fro')**2)) * A
    f6_co_3 = -np.outer(e1, e1) + (np.matrix.trace(np.outer(e1, e1) @ A)/(np.linalg.norm(A, 'fro')**2)) * A
    f6 = alpha * beth + f6_co_1 @ Xi + f6_co_2 * lambdas[0] + f6_co_3 * lambdas[1]
    f6 = f6 + eq6_k

    f7 = alpha * tilde_beth - tilde_Xi
    f7 = f7 + eq7_k

    obj = cp.square(f1) + cp.square(f2) + cp.square(f3) + cp.norm(f4) + cp.norm(f5) ** 2 + cp.norm(f6) ** 2 + cp.norm(f7) ** 2
    ##### ？？？？？？？？
    # obj = cp.square(f1) + cp.square(f2) + cp.square(f3) + cp.norm(f4) ** 2 + cp.norm(f5) ** 2 + cp.norm(f6) ** 2 + cp.norm(f7) ** 2

    constraints = [beth >> 0]
    constraints += [tilde_beth >> 0]
    constraints += [Xi >> 0]
    constraints += [tilde_Xi >> 0]

    prob = cp.Problem(cp.Minimize(obj), constraints)
    prob.solve(solver=cp.MOSEK)

    # print("Solution for delta_beth:\n", beth.value)
    # print("Solution for delta_tilde_beth:\n", tilde_beth.value)
    # print("Solution for delta_Xi:\n", Xi.value)
    # print("Solution for delta_tilde_Xi:\n", tilde_Xi.value)
    # print("Solution for delta_lambdas:\n", lambdas.value)

    delta_beth = beth.value
    delta_tilde_beth= tilde_beth.value
    delta_Xi = Xi.value
    delta_tilde_Xi = tilde_Xi.value
    delta_lambdas = lambdas.value

    ### to ensure the symmetry ###
    delta_beth_solution, delta_tilde_beth_solution, delta_Xi_solution, delta_tilde_Xi_solution, delta_lambdas_solution = normalize_each_variable(
        delta_beth, delta_tilde_beth, delta_Xi, delta_tilde_Xi, delta_lambdas)

    # print('after normalization......')
    # print("Solution for delta_beth:\n", delta_beth_solution)
    # print("Solution for delta_tilde_beth:\n", delta_tilde_beth_solution)
    # print("Solution for delta_Xi:\n", delta_Xi_solution)
    # print("Solution for delta_tilde_Xi:\n", delta_tilde_Xi_solution)
    # print("Solution for delta_lambdas:\n", delta_lambdas_solution)

    return delta_beth_solution, delta_tilde_beth_solution, delta_Xi_solution, delta_tilde_Xi_solution, delta_lambdas_solution

def compute_dual_objective(mat_Psi_s, mat_tilde_Psi_s, vec_v_j_norm_avg, xi, tilde_xi, lambdas, alpha, A, e_set):

    e0, e1 = e_set
    # dual objective
    v_term = mat_Psi_s + lambdas[0] * np.outer(e0, e0) + lambdas[1] * np.outer(e1, e1) + xi
    v = (np.matrix.trace(v_term @ A) + alpha)/(np.linalg.norm(A, 'fro') ** 2)

    g_term_1 = mat_Psi_s + lambdas[0] * np.outer(e0, e0) + lambdas[1] * np.outer(e1, e1) + xi - v * A
    g_term_1_fSqure = np.linalg.norm(g_term_1, 'fro') ** 2

    g_term_2 = mat_tilde_Psi_s - tilde_xi
    g_term_2_fSqure = np.linalg.norm(g_term_2, 'fro') ** 2

    obj_dual = -1/(2*alpha) * g_term_1_fSqure - 1/(2*alpha) * g_term_2_fSqure + vec_v_j_norm_avg

    return obj_dual, g_term_1, v

######### implement the backtrack line search  ########
def backtrack(z, delta_z, loss_k_set, samples, n_player, pmax, squaring_param, alpha, A, e_set, beta=0.5, gamma = 0.5):
    e0, e1 = e_set
    beth, tilde_beth, xi, tilde_xi, lambdas = z
    delta_beth, delta_tilde_beth, delta_xi, delta_tilde_xi, delta_lambdas = delta_z
    loss_k, mat_Psi_s_k, mat_tilde_Psi_s_k, vec_v_j_norm_avg_k = loss_k_set

    bar_eta_p, bar_eta_d = 1, 1 # Typically, beta\in[0.5, 0.8], gamma takes from [0.001, 0.1]
    print('we are backtracking......')
    k = 0
    while True:
        print('primal step length is {}'.format(bar_eta_p))
        new_beth = beth + bar_eta_p * delta_beth
        new_tilde_beth = tilde_beth + bar_eta_p * delta_tilde_beth
        # if is_semiPos_def(new_beth) and is_semiPos_def(new_tilde_beth):
        #     break
        # beth_k, tilde_beth_k =
        loss_new, mat_Psi_s_new, mat_tilde_Psi_s_new, vec_v_j_norm_avg_new = compute_asl_loss(new_beth, new_tilde_beth, samples, n_player, pmax, squaring_param, alpha)
        difference = np.matrix.trace((alpha * beth - mat_Psi_s_k) @ delta_beth) + np.matrix.trace((alpha * tilde_beth + mat_tilde_Psi_s_k) @ delta_tilde_beth)
        if loss_new >= loss_k + gamma * bar_eta_p * difference and k <= 30: #gamma *
            bar_eta_p *= beta
            k = k + 1
        else:
            break

    obj_k, g_term_1_k, v_k = compute_dual_objective(mat_Psi_s_k, mat_tilde_Psi_s_k, vec_v_j_norm_avg_k, xi, tilde_xi, lambdas, alpha, A, (e0, e1))
    k = 0
    while True:
        print('dual step length is {}'.format(bar_eta_d))
        new_xi = xi + bar_eta_d * delta_xi
        new_tilde_xi = tilde_xi + bar_eta_d * delta_tilde_xi
        new_lambdas = lambdas + bar_eta_d * delta_lambdas
        obj_new, _, _ = compute_dual_objective(mat_Psi_s_new, mat_tilde_Psi_s_new, vec_v_j_norm_avg_new, new_xi, new_tilde_xi, new_lambdas, alpha, A, (e0, e1))

        grad_xi = - 1/alpha * (g_term_1_k + xi)
        grad_tilde_xi = - 1/alpha * (-mat_tilde_Psi_s_k + tilde_xi)
        lambda_1_term = lambdas[0] * (lambdas[1] * np.matrix.trace(np.outer(e0, e0) @ np.outer(e1, e1))) **2
        grad_lambda_1 = - 1/alpha * (np.matrix.trace(mat_Psi_s_k @ np.outer(e0, e0)) + np.matrix.trace(np.outer(e0, e0) @ xi) - np.matrix.trace(np.outer(e0, e0) @ (v_k * A)) + lambda_1_term)

        lambda_2_term = lambdas[1] * (lambdas[0] * np.matrix.trace(np.outer(e0, e0) @ np.outer(e1, e1))) **2
        grad_lambda_2 = - 1/alpha * (np.matrix.trace(mat_Psi_s_k @ np.outer(e1, e1)) + np.matrix.trace(np.outer(e1, e1) @ xi) - np.matrix.trace(np.outer(e1, e1) @ (v_k * A)) + lambda_2_term)
        difference_dual = np.matrix.trace(grad_xi @ delta_xi) + np.matrix.trace(grad_tilde_xi @ delta_tilde_xi) + grad_lambda_1 * lambdas[0] + grad_lambda_2 * lambdas[1]
        if obj_new < obj_k + gamma * bar_eta_d * difference_dual and  k <= 30:
            bar_eta_d *= beta
            k = k + 1
        else:
            break
        # if is_semiPos_def(new_xi) and is_semiPos_def(new_tilde_xi):
        #     break
    eta_p, eta_d = bar_eta_p, bar_eta_d
    # eta_p = min(1, tau * bar_eta_p)
    # eta_d = min(1, tau * bar_eta_d)

    return eta_p, eta_d

def compute_mu_k(beth_k, tilde_beth_k, xi_k, tilde_xi_k, lambdas_k, e_set):
    e0, e1 = e_set
    mu_k_reci_term1 = (np.matrix.trace(beth_k @ xi_k) + np.matrix.trace(tilde_beth_k @ tilde_xi_k)) / (
                beth_k.shape[0] * 4)
    mu_k_reci_term2 = (lambdas_k[0] * np.matrix.trace(np.outer(e0, e0) @ beth_k) + lambdas_k[1] * np.matrix.trace(
        np.outer(e1, e1) @ beth_k)) / 4
    mu_k_reci = mu_k_reci_term1 + mu_k_reci_term2
    mu_k = 1 / mu_k_reci

    return mu_k


def FOM_Game_SDP(
    dataset,
    n_player,
    pmax,
    variables_0,
    step,
    Theta_true, # only for comparison
    regularizer='L2_squared',
    reg_param=0,
    squaring_param = 0.1,
    theta_hat=None,
    batch_type=1,
    callback=None,
    callback_resolution=1,
    verbose=True
):
    """
    Optimize (Augmented) Suboptimality loss using first-order methods.

    Parameters
    ----------
    dataset : array-like, shape (n_samples, n_features),
              each row is that  p1_j, p2_j, xi_j
    n_player : int, number of players
    pmax : float, the upper bound of price
    variables_0 : the list of all variables, including primal variable and dual variables
        Initial variables.
    T : int
        The number of iterations for the algorithm.
    step : {'newton'}, optional
    regularizer : {'L2_squared', 'L1'}, optional
        Type of regularization on cost vector theta. The default is 'L2_squared'.
    reg_param : float, optional
        Nonnegative regularization parameter. The default is 0.
    batch_type : {float, 'reshuffled'}, optional
        If float, it is the fraction of the dataset used to compute stochastic
        subgradients of the loss function, where batch_type=b means use 100*b %
        of the data to compute (stochastic) subgradients. If
        batch_type='reshuffled', T is the number of epochs instead of the
        number of iterations. For each epoch, run the algorithm for N
        iterations, where N is the size of the dataset. That is, perform one
        update step for each example in the dataset. At the beginning of each
        epoch, shuffle the order or the examples in the dataset. For more
        details, see Mishchenko et al. "Random Reshuffling: Simple Analysis
        with Vast Improvements". The default is 1.
    callback : {callable, None}, optional
        If not None, callback(theta_t) is evaluated for
        t=0,callback_resolution,2*callback_resolution... . The default is None.
    callback_resolution : int, optional
        Callback function resolution. The default is 1.
    verbose : bool, optional
        If True, prints iteration counter. The default is False.

    Raises
    ------
    Exception
        If unsupported Theta or regularizer. If step = 'exponentiated' and
        the regularizer is not 'L1' or theta_hat is not None.

    Returns
    -------
    theta_T : {1D ndarray, list}
        If callback=None, returns the final (averaged) vector found after T
        iterations of the algorithm. Otherwise, returns a list of size T+1
        with elements callback(theta_t) for t=0,...,T, where theta_t is the
        (averaged) vector after t iterations of the algorithm.

    """
    beth_0, tilde_beth_0 = variables_0[0], variables_0[1]
    xi_0, tilde_xi_0 = variables_0[2], variables_0[3]
    lambdas_0 = variables_0[4]

    check_regularizer(regularizer)
    check_reg_parameter(reg_param)

    # Warnings
    assert step == 'newton'

    # Get the dimension of the problem: len(theta_0) and the number of samples
    beth_k, tilde_beth_k = beth_0, tilde_beth_0
    xi_k, tilde_xi_k = xi_0, tilde_xi_0
    lambdas_k = lambdas_0

    # normalize each varible, why we should normalize the matrix?
    beth_k, tilde_beth_k, xi_k, tilde_xi_k, lambdas_k = normalize_each_variable(beth_k, tilde_beth_k, xi_k, tilde_xi_k, lambdas_k)

    callback_list = []
    if callback is not None:
        # Evaluate theta_0
        callback_list.append(callback([beth_k, tilde_beth_k, xi_k, tilde_xi_k, lambdas_k]))

    alpha = reg_param
    Theta_norm = Theta_true / np.linalg.norm(Theta_true)

    N = dataset.shape[0]
    matrix_A = np.array([[0, 1], [1, 0]])
    e0 = np.eye(1,2,0)[0] #array([1., 0.])
    e1 = np.eye(1,2,1)[0]# array([0., 1.])

    mu_k = compute_mu_k(beth_k, tilde_beth_k, xi_k, tilde_xi_k, lambdas_k, (e0, e1))
    # print('1/mu_0 is {}'.format(1/mu_k))
    epsilon = 0.001 # Q1-how to set this value? need to read references
    k = 0

    ASL_loss_set, error_set = [], []
    mu_k_set = [mu_k]
    # mu_k = 2 * mu_k
    while 1 / mu_k > epsilon and k < 50: #1/mu_k > epsilon: mu_k < 1/epsilon
        if verbose:
            print(f'********* Iteration {k+1} ***********')
            print('')
        print('1/mu_k_{} is {}'.format(k + 1, 1/mu_k))
        print('n/trace of beth @ xi is {}'.format(beth_k.shape[0] / np.matrix.trace(beth_k @ xi_k)))
        print('n/trace of tilde_beth @ tilde_xi is {}'.format(beth_k.shape[0] / np.matrix.trace(tilde_beth_k @ tilde_xi_k)))
        print('lambda_1 * trace(...) is {}'.format(lambdas_k[0] * np.matrix.trace(np.outer(e0, e0) @ beth_k)))
        print('lambda_2 * trace(...) is {}'.format(lambdas_k[1] * np.matrix.trace(np.outer(e1, e1) @ beth_k)))
        # eta_k = step_size(k) #eta_t = 0.5/sqrt(t+1) ## # Q2- how to determine this value

        batch_size = int(np.ceil(batch_type * N)) #batch_type = 1
        sample_idxs = np.random.choice(N, batch_size, replace=False)
        samples = [dataset[i] for i in sample_idxs]

        ########### solve for the Newton's linear system   ###########
        ## compute \psi^{j}_{s} ##
        ## be careful!!!! the convert between \beth, \beth2 to theta!! need to check again!!!!!
        theta_k = convert_beth_to_theta(beth_k, tilde_beth_k)
        theta_k_normed = theta_k / np.linalg.norm(theta_k)
        print('normalized theta_k_{} is {}'.format(k, theta_k_normed))
        error_norm = np.linalg.norm(np.array(Theta_norm) - np.array(theta_k_normed))
        print('estimated normed error is {}'.format(error_norm))
        error_set.append(error_norm)

        loss_ASL_k, mat_Psi_s_k, mat_tilde_Psi_s_k, vec_v_j_norm_avg_k = compute_asl_loss(beth_k, tilde_beth_k, samples, n_player, pmax, squaring_param, alpha)

        ASL_loss_set.append(loss_ASL_k)
        print('ASL loss value is {}'.format(loss_ASL_k))

        z_k = (beth_k, tilde_beth_k, xi_k, tilde_xi_k, lambdas_k)
        params_k = (mu_k, alpha, matrix_A, (e0, e1))
        loss_k_set = (loss_ASL_k, mat_Psi_s_k, mat_tilde_Psi_s_k, vec_v_j_norm_avg_k)

        # delta_beth, delta_tilde_beth, delta_Xi, delta_tilde_Xi, delta_lambdas = solve_linear_systems(z_k, params_k, loss_k_set)
        delta_beth, delta_tilde_beth, delta_Xi, delta_tilde_Xi, delta_lambdas = solve_linear_systems_by_optimization(z_k, params_k, loss_k_set)
        # newton step: how to determine?
        delta_z = (delta_beth, delta_tilde_beth, delta_Xi, delta_tilde_Xi, delta_lambdas)

        eta_k, dual_eta_k = backtrack(z_k, delta_z, loss_k_set, samples, n_player, pmax, squaring_param, alpha, matrix_A, (e0,e1), beta=0.8, gamma = 0.5)

        beth_k = beth_k + eta_k * delta_beth
        tilde_beth_k = beth_k + eta_k * delta_tilde_beth
        xi_k = xi_k + dual_eta_k * delta_Xi
        tilde_xi_k = tilde_xi_k + dual_eta_k * delta_tilde_Xi
        lambdas_k = lambdas_k + dual_eta_k * delta_lambdas

        beth_k, tilde_beth_k, xi_k, tilde_xi_k, lambdas_k = normalize_each_variable(beth_k, tilde_beth_k, xi_k, tilde_xi_k, lambdas_k)

        mu_k = compute_mu_k(beth_k, tilde_beth_k, xi_k, tilde_xi_k, lambdas_k, (e0, e1))
        k = k + 1
        mu_k_before = mu_k_set[-1]
        scaling = 1.19
        while  mu_k < mu_k_before:
            mu_k = scaling * mu_k
        mu_k_set.append(mu_k)

        callback_list.append(callback([beth_k, tilde_beth_k, xi_k, tilde_xi_k, lambdas_k]))

    # print(ASL_loss_set)
    # print(error_set)
    mu_k_reci_set =[1 / i  for i in mu_k_set]
    print(mu_k_reci_set)
    print(len(callback_list))
    assert len(callback_list) == 51

    return callback_list, ASL_loss_set, error_set

def intialize_variables(n_player):

    beth_0 = np.random.rand(n_player, n_player)
    # beth_0 = np.random.uniform(0, 2, size=(n_player, n_player))
    beth_0[0, 1] = - beth_0[0, 1]
    beth_0[1, 0] = - beth_0[1, 0]
    beth_0 = np.dot(beth_0, beth_0.transpose())
    assert is_semiPos_def(beth_0) == True

    tilde_beth_0 = np.random.uniform(0, 1, size=(n_player, n_player))#np.random.rand(n_player, n_player)
    tilde_beth_0 = np.dot(tilde_beth_0, tilde_beth_0.transpose())
    # print(tilde_beth_0)
    assert is_semiPos_def(tilde_beth_0) == True

    xi_0 = np.random.uniform(0, 1, size=(n_player, n_player))#np.random.rand(n_player, n_player)
    xi_0 = np.dot(xi_0, xi_0.transpose())
    assert is_semiPos_def(xi_0) == True

    tilde_xi_0 = np.random.uniform(0, 1, size=(n_player, n_player))#np.random.rand(n_player, n_player)
    tilde_xi_0 = np.dot(tilde_xi_0, tilde_xi_0.transpose())

    lambdas_0 = np.random.rand(n_player)

    return [beth_0, tilde_beth_0, xi_0, tilde_xi_0, lambdas_0]


args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/bertrand/', help = 'the root of data', type = str)
args_parser.add_argument('--u_type', default = 'linear', help = 'the type of demand function', type = str)
args_parser.add_argument('--seed', default = 0, help = 'the random index of dataset', type = int)
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args_parser.add_argument('--pmax', default = 8, help = 'upper bound of price', type = float)
args_parser.add_argument('--nPlayer', default = 2, help = 'the number of players', type = int)
args_parser.add_argument('--squaring', default = 1, help = 'random index', type = float)
# args_parser.add_argument('--Epoch', default = 500, help = 'maximum of iterations in our algorithm', type = int)
args_parser.add_argument('--step', default = 'newton', help = 'the descent update method', type = str)
args_parser.add_argument('--regularizer', default = 'L2_squared', help = 'the regularizer term in our loss', type = str)
# args_parser.add_argument('--normalize_grad', default = True, help = 'if gradient is normalized', type = bool)
args_parser.add_argument('--batch_ratio', default = 1.0, help = 'the batch size', type = float)
args_parser.add_argument('--time_limit', default = 0.05, help = 'the time limit in optimization', type = float)
# args_parser.add_argument('--step_size_constant', default = 0.5, help = 'the step size constant in update', type = float)
args_parser.add_argument('--reg_param', default = 0.01, help = 'the coefficient of the regularizer loss', type = float)
args_parser.add_argument('--theta_prior', default = None, help = 'the prior of theta', type = float)
args = args_parser.parse_args()

file_path = args.file_root
utility_type = args.u_type
N_train = args.N
pmax = args.pmax
seed = args.seed
# print("pmax is {}".format(pmax))

Theta_true =  np.load(file_path + 'Seed_' + str(seed) + '_parameters_SDP.npy', allow_pickle=True)
dataset_train_df = pd.read_csv(file_path + 'Seed_' + str(seed) + '_SDP_train_u_'+ utility_type + '_N_' + str(N_train) + '_firstOrder.csv')
dataset_test_df = pd.read_csv(file_path + 'Seed_' + str(seed) + '_SDP_test_u_' + utility_type + '_N_' + str(N_train) + '_firstOrder.csv')
dataset_train = np.array(dataset_train_df)
dataset_test = np.array(dataset_test_df)

# n_player = 2 # player number is 2
n_player = args.nPlayer
n_theta = int(len(Theta_true) / 2)
# pmax = math.ceil(max(np.max(dataset_train[:, 0]), np.max(dataset_train[:, 1])))
pmax_train = math.ceil(max(np.max(dataset_train[:, 0]), np.max(dataset_train[:, 1])))
pmax_test = math.ceil(max(np.max(dataset_test[:, 0]), np.max(dataset_test[:, 1])))
pmax = min (max(pmax_train, pmax_test), pmax)
print("pmax is {}".format(pmax))
# print(affff)

time_limit = args.time_limit
# step_size_constant = args.step_size_constant

# epoch_max = args.Epoch
step = args.step #'exponentiated'
regularizer = args.regularizer

# #### 'L2-squared' and 'standard' fails due to Eucliduan-geometry......
# regularizer = 'L2_squared'
# step = 'standard'
squaring_param = args.squaring
Theta_Prior = args.theta_prior
reg_param = args.reg_param
batch = args.batch_ratio

save_path = './results/bertrand/Seed_' +str(seed) + '/' + step + '_' + regularizer
if not os.path.exists(save_path):
    os.makedirs(save_path)

time_s = time.time()
# n_runs = 5
run_set = [0]#, 1, 2, 3, 4
callbacks_runs = []
ASL_runs, err_runs = [], []
# print('training sample number is {}'.format(dataset_train.shape[0]))
for r_idx in range(len(run_set)):#range(n_runs):
    #### runs -- r #####
    r = run_set[r_idx]
    variables_set = intialize_variables(n_player)
    print('Initial variables are ', variables_set)

    callback_results, ASL_Set, Err_Set = FOM_Game_SDP(dataset_train,
                                             n_player,
                                             pmax,
                                             variables_set,
                                             step,
                                             Theta_true,
                                             regularizer=regularizer,
                                             reg_param= reg_param,
                                             squaring_param =squaring_param,
                                             batch_type=batch,
                                             callback=callback)#,normalize_grad=normalize_grad)


    print(callback_results)
    callbacks_runs.append(callback_results)
    ASL_runs.append(ASL_Set)
    err_runs.append(Err_Set)
    ## save all-thetas ##
    thetas_iter_name = save_path + '/SDP_thetas_run_' + str(r) + '_' + utility_type+'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '.npy'
    np.save(thetas_iter_name, np.array(callback_results, dtype=object), allow_pickle=True)

loss_ASL_name = save_path + '/SDP_Loss_' + utility_type+'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '.csv'
# runs_LOSS_np = np.array(ASL_runs)# cannot directly use this, since each run has different length
runs_LOSS_np = np.zeros([len(ASL_runs),len(max(ASL_runs,key = lambda x: len(x)))])
for i,j in enumerate(ASL_runs):
    runs_LOSS_np[i][0:len(j)] = j
pd.DataFrame(runs_LOSS_np).to_csv(loss_ASL_name, index = False)

ERR_ASL_name = save_path + '/SDP_Err_thetas_' + utility_type+'_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '.csv'
# runs_Err_np = np.array(err_runs)
runs_ERR_np = np.zeros([len(err_runs),len(max(err_runs,key = lambda x: len(x)))])
for i,j in enumerate(err_runs):
    runs_ERR_np[i][0:len(j)] = j
pd.DataFrame(runs_ERR_np).to_csv(ERR_ASL_name, index = False)

print('squaring is {}'.format(squaring_param))
print('After running '+str(len(run_set)) +' exps, time spent {} minutes'.format((time.time()-time_s)/60))

################ plot the average result for ASL LOSS #####################
assert runs_LOSS_np.shape[0] == len(callbacks_runs)
runs_average = np.nanmean(zero_to_nan(runs_LOSS_np), axis = 0) #runs_LOSS_np.mean(axis=0)     # to take the mean of each col
runs_std = np.nanstd(zero_to_nan(runs_LOSS_np), axis = 0)#runs_LOSS_np.std(axis=0)

plt.rcParams["mathtext.fontset"] = 'cm'
plt.rcParams['font.family'] = 'serif'
plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]

plt.figure(0)
plt.plot(range(1, len(runs_average) + 1), runs_average, label='ASL', color='red', linewidth=2)
plt.fill_between(range(1, len(runs_average) + 1), runs_average-runs_std, runs_average+runs_std, alpha=0.25, edgecolor='#FF4500', facecolor='#FE420F')
# plt.plot(range(1, len(err_T) + 1), np.repeat(1.0710639067698995, len(err_T)), label='Bertsimas')
plt.ylabel(
    'Loss Value', fontsize=18
)
plt.xlabel(r'Iterations of $ \mu $', fontsize=14)
plt.xlim(0, len(runs_average))
# plt.ylim(30, 80)
plt.grid(visible=True)
plt.legend(fontsize='16', loc='upper right')
plt.tight_layout()
# saving the figure.
plt.savefig(save_path + '/SDP_avgLOSS_' + utility_type + '_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train)
     + '_' + regularizer + '_' + step + '.png')
plt.show()

######################## plot the average of ERRORS result ################################

runs_average = np.nanmean(zero_to_nan(runs_ERR_np), axis = 0) #runs_ERR_np.mean(axis=0)     # to take the mean of each col
runs_std = np.nanstd(zero_to_nan(runs_ERR_np), axis = 0) #runs_ERR_np.std(axis=0)

plt.rcParams["mathtext.fontset"] = 'cm'
plt.rcParams['font.family'] = 'serif'
plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]

plt.figure(1)
plt.plot(range(1, len(runs_average) + 1), runs_average, label='ASL', color='red', linewidth=2)
plt.fill_between(range(1, len(runs_average) + 1), runs_average-runs_std, runs_average+runs_std, alpha=0.25, edgecolor='#FF4500', facecolor='#FE420F')
# plt.plot(range(1, len(err_T) + 1), np.repeat(1.0710639067698995, len(err_T)), label='Bertsimas')
plt.ylabel(
    r'$\| \tilde{\vartheta}_{\mathrm{esti}} - \tilde{\vartheta}_{\mathrm{true}} \|_2$', fontsize=18
)
plt.xlabel(r'Iterations of $ \mu $', fontsize=14)
plt.xlim(0, len(runs_average))
# plt.ylim(0.5, 1.2)
plt.grid(visible=True)
plt.legend(fontsize='16', loc='upper right')
plt.tight_layout()
# saving the figure.
plt.savefig(save_path + '/SDP_avgThetas_' + utility_type +'_ASL_squaring_' + str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '.png')
plt.show()


# def Jacobian(F, z, params, epsilon=1e-5):
#     n = len(z)
#     m = len(F(z, params))
#     J = np.zeros((m, n))
#
#     for i in range(n):
#         z_eps = list(z)
#         z_eps[i] += epsilon
#         f1 = F(z_eps, params)
#         z_eps[i] -= 2 * epsilon
#         f2 = F(z_eps, params)
#         J[:, i] = (f1 - f2) / (2 * epsilon)
#
#     return J
#
# def Jacobian_manually(F, z, params):
#     beth, tilde_beth, Xi, tilde_Xi, lambdas  = z
#     mu, alpha, A, Psi_s, tilde_Psi_s = params
#
#     # n = len(z)
#     m = len(F(z, params))
#     n = beth.size + tilde_beth.size + Xi.size + tilde_Xi.size + lambdas.size
#     J = np.zeros((m, n))
#
#     J[0, :] = np.hstack([A.flatten(), np.zeros(tilde_beth.size), np.zeros(Xi.size), np.zeros(tilde_Xi.size), np.zeros(lambdas.size)])
#
#     e1 = np.eye(1,2,0)[0] #array([1., 0.])
#     e2 = np.eye(1,2,1)[0]# array([0., 1.])
#     F2_beth_grad_term1 = mu * (lambdas[0] * np.outer(e1, e1) + lambdas[1] * np.outer(e2, e2) + Xi)
#     F2_beth_grad_term2 = 1/(np.matrix.trace(np.outer(e1, e1), beth)**2) * np.outer(e1, e1) @ beth + 1/(np.matrix.trace(np.outer(e2, e2), beth)**2) * np.outer(e2, e2) @ beth
#     F2_beth_grad_term3 = 1/np.matrix.trace(np.outer(e1, e1), beth) * np.outer(e1, e1) + 1/np.matrix.trace(np.outer(e2, e2), beth)* np.outer(e2, e2)
#
#     F2_beth_grad = F2_beth_grad_term1 + F2_beth_grad_term2 - F2_beth_grad_term3
#     J[1, :] = np.hstack([F2_beth_grad.flatten(), np.zeros(tilde_beth.size), mu*beth.flatten(), np.zeros(tilde_Xi.size), np.array([np.matrix.trace(np.outer(e1, e1), beth), np.matrix.trace(np.outer(e2, e2), beth)]), 0])
#
#     J[2, :] = np.hstack([np.zeros(beth.size), tilde_Xi.flatten(), np.zeros(Xi.size), tilde_beth.flatten(), np.zeros(lambdas.size), 0])
#
#     J[3, :] = np.hstack([alpha * np.ones(beth.size), np.zeros(tilde_beth.size), -np.ones(Xi.size), np.zeros(tilde_Xi.size), -np.array([np.matrix.trace(np.outer(e1, e1)), np.matrix.trace(np.outer(e2, e2))]), A.flatten()])
#
#     return J



