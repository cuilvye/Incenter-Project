#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

# INCORPORATE KNOWLEDGE OF THETA #
import os
import argparse
import numpy as np
import pandas as pd
import time, math
import warnings
import gurobipy as gp
import matplotlib.pyplot as plt

from utils_cournot_incenter import ASL_Cournot
from utils_cournot_incenter import check_Theta, check_reg_parameter
from utils_cournot_incenter import check_regularizer, warning_theta_hat_reg_param
from utils_cournot_incenter import FOP_game_Cournot, phi_func_Cournot


def step_size(t):
    """Step size function."""
    return step_size_constant/np.sqrt(t+1)

def callback(theta):
    """Store input and current time."""
    return theta, time.time()

def FOM_Game_Cournot(
    dataset,
    n_player,
    qmax,
    theta_0,
    step_size,
    T,
    Theta=None,
    step='standard',
    regularizer='L2_squared',
    reg_param=0,
    squaring_param = 1,
    theta_hat=None,
    batch_type=1,
    averaged=0,
    callback=None,
    callback_resolution=1,
    normalize_grad=False,
    verbose=True
):
    """
    Optimize (Augmented) Suboptimality loss using first-order methods.

    Parameters
    ----------
    dataset : array-like, shape (n_samples, n_features),
              each row is that  p1_j, p2_j, xi_j
    n_player : int, number of players
    pmax : float, the upper bound of price
    theta_0 : 1D ndarray
        Initial cost vector theta.
    step_size : callable
        Step-size function. Takes as input the iteration counter t = 0,...,T-1
        and returns the step-size. Syntax: step_size(t).
    T : int
        The number of iterations for the algorithm.
    Theta : {None, 'nonnegative'}, optional
        Constraints on cost vector theta. The default is None.
    step : {'standard', 'exponentiated'}, optional
        Type of update step used for the first-order algorithm. If 'standard',
        uses standard "subgradient method" update steps:
        theta_{t+1} = theta_t - step_size(t)*subgradient. If 'exponentiated',
        uses exponentiated steps:
        theta_{t+1} = theta_t * exp{-step_size(t)*subgradient}. The default is
        'standard'.
    regularizer : {'L2_squared', 'L1'}, optional
        Type of regularization on cost vector theta. The default is 'L2_squared'.
    reg_param : float, optional
        Nonnegative regularization parameter. The default is 0.
    theta_hat : {1D ndarray, None}, optional
        A priory belief or estimate of the true cost vector. The default is None.
    batch_type : {float, 'reshuffled'}, optional
        If float, it is the fraction of the dataset used to compute stochastic
        subgradients of the loss function, where batch_type=b means use 100*b %
        of the data to compute (stochastic) subgradients. If
        batch_type='reshuffled', T is the number of epochs instead of the
        number of iterations. For each epoch, run the algorithm for N
        iterations, where N is the size of the dataset. That is, perform one
        update step for each example in the dataset. At the beginning of each
        epoch, shuffle the order or the examples in the dataset. For more
        details, see Mishchenko et al. "Random Reshuffling: Simple Analysis
        with Vast Improvements". The default is 1.
    averaged : {0, 1, 2}, optional
        Add the option to return the average of the iterates of the algorithm
        instead of the final iterate. If averaged=0, it does not average the
        iterates of the algorithm. If averaged=1, uses a simple average of
        iterations: (1/T)*sum_{t=1}^{T} theta_t. If averaged=2, uses a weighted
        average of iterations: (2/(T*(T+1)))*sum_{t=1}^{T} t*theta_t. In
        theory, for strongly convex problems, the weighted average works better
        (see Lacoste-Julien et al. "A simpler approach to obtaining an O(1/t)
        convergence rate for the projected stochastic subgradient method"). The
        default is 0.
    callback : {callable, None}, optional
        If not None, callback(theta_t) is evaluated for
        t=0,callback_resolution,2*callback_resolution... . The default is None.
    callback_resolution : int, optional
        Callback function resolution. The default is 1.
    normalize_grad : bool, optional
        If True, subgradient vectors are normalized before each iteration of
        the algorithm. If step='standard', the L2 norm of the subgradient is
        used. If step='exponentiated', the L-infinity norm of the subgradient
        is used. The default is False.
    verbose : bool, optional
        If True, prints iteration counter. The default is False.

    Raises
    ------
    Exception
        If unsupported Theta or regularizer. If step = 'exponentiated' and
        the regularizer is not 'L1' or theta_hat is not None.

    Returns
    -------
    theta_T : {1D ndarray, list}
        If callback=None, returns the final (averaged) vector found after T
        iterations of the algorithm. Otherwise, returns a list of size T+1
        with elements callback(theta_t) for t=0,...,T, where theta_t is the
        (averaged) vector after t iterations of the algorithm.

    """
    # Check if the inputs are valid
    check_Theta(Theta)
    check_regularizer(regularizer)
    check_reg_parameter(reg_param)

    # Warnings
    warning_theta_hat_reg_param(theta_hat, reg_param)

    if (step == 'exponentiated') and (regularizer != 'L1') and (reg_param > 0):
        raise Exception(
            'To use step = \'exponentiated\' with reg_param > 0,'
            'regularizer = \'L1\' is required.'
        )

    if (step == 'exponentiated') and (theta_hat is not None):
        raise Exception(
            'When step=\'exponentiated\', theta_hat must be None.'
        )

    # Get the dimension of the problem: len(theta_0) and the number of samples
    N = dataset.shape[0]
    if theta_hat is None:
        theta_hat = np.zeros(len(theta_0))

    theta_t = theta_0
    theta_avg = theta_0
    callback_list = []
    if callback is not None:
        callback_list.append(callback(theta_0)) # Evaluate theta_0

    ASL_loss_set = []
    for t in range(T):
        if verbose:
            print(f'Iteration {t+1} out of {T}')
            print('')

        eta_t = step_size(t) #eta_t = 0.5/sqrt(t+1)
        if batch_type == 'reshuffled':
            arr = np.arange(N) #array([0, 1, ..., N])
            np.random.shuffle(arr)
            for i in arr:
                samples = [dataset[i]] ## dataset[i]: get i-row of the dataset
                reg_grad, loss_grad = compute_grad_games_Cournot(n_player, qmax,
                    theta_t, samples, regularizer, reg_param, theta_hat)
                theta_t = grad_step(
                    theta_t, eta_t, reg_grad, loss_grad, reg_param, Theta,
                    step, normalize_grad
                )
        else:
            batch_size = int(np.ceil(batch_type * N)) #batch_type = 1
            sample_idxs = np.random.choice(N, batch_size, replace=False)
            samples = [dataset[i] for i in sample_idxs]
            # squaring_param = 0.001
            reg_grad, loss_grad = compute_grad_games_Cournot(n_player, qmax,
                theta_t, samples, regularizer, reg_param, squaring_param, theta_hat
            )
            # print('reg_grad', reg_grad)
            # print('loss_grad', loss_grad)
            assert len(reg_grad) == len(loss_grad)
            # print(affffff)
            theta_t = grad_step(
                theta_t, eta_t, reg_grad, loss_grad, reg_param, Theta, step,
                normalize_grad
            )
            print('theta_t', theta_t)

            #### compute the ASL value for each theta
            theta_t_norm = theta_t / np.linalg.norm(theta_t)
            Loss_ASL = ASL_Cournot(theta_t_norm, dataset, n_player, qmax, regularizer, reg_param, squaring_param, theta_hat=None)
            print('Loss_ASL', Loss_ASL)
            ASL_loss_set.append(Loss_ASL)

        if averaged == 0:
            theta_avg = theta_t
        elif averaged == 1:
            theta_avg = (1/(t+1))*theta_t + (t/(t+1))*theta_avg
        elif averaged == 2:
            theta_avg = (2/(t+2))*theta_t + (t/(t+2))*theta_avg

        if (callback is not None) and (np.mod(t+1, callback_resolution) == 0):
            callback_list.append(callback(theta_avg))

    # Check if the list callback_list is empty
    if callback_list:
        theta_T = callback_list
    else:
        theta_T = theta_avg

    return theta_T, ASL_loss_set


def gradient_regularizer(theta_t, regularizer, reg_param, theta_hat):
    """
    Compute (sub)gradient of the regularizer.

    Parameters
    ----------
    theta_t : 1D ndarray
        Vector where the gradient will be evaluated at.
    regularizer : {'L2_squared', 'L1'}
        Type of regularization on cost vector theta.
    reg_param : float
        Nonnegative regularization parameter..
    theta_hat : 1D ndarray
        A priory belief or estimate of the true cost vector.

    Returns
    -------
    reg_grad : 1D ndarray
        (Sub)gradient of the regularizer evaluated at theta_t.

    """
    if regularizer == 'L2_squared':
        grad = reg_param*(theta_t - theta_hat)
    elif regularizer == 'L1':
        grad = reg_param*np.sign(theta_t - theta_hat)

    return grad


def compute_grad_games_Cournot(n_player, qmax, theta_t, samples,  regularizer, reg_param, squaring_param, theta_hat):
    """
    Compute a (sub)gradient of the regularizer and the sum of losses.

    Parameters
    ----------
    n_player : int
    pmax : the maximum of price
    theta_t : 1D ndarray
        Vector where the (sub)gradient will be evaluated at.
    samples : list of arrays
        List of arrays np.array([p1, p2, xi]), where xi is the signal and [p1, p2] is the equilibrium prices.
        Each array defines a loss function.
    regularizer : {'L2_squared', 'L1'}
        Type of regularization on cost vector theta.
    reg_param : float
        Nonnegative regularization parameter.
    theta_hat : 1D ndarray
        A priory belief or estimate of the true cost vector.

    Returns
    -------
    reg_grad : 1D ndarray
        (Sub)gradient of the regularizer evaluated at theta_t.
    loss_grad : 1D ndarray
        (Sub)gradient of the sum of losses evaluated at theta_t.

    """
    aux = 0
    x_opt = None
    for q1_hat, q2_hat, q3_hat, xi_hat in samples:
        # Check if the FOP is augmented
        # print(p1_hat, p2_hat, xi_hat)
        x_hat = np.array([q1_hat, q2_hat, q3_hat])
        # x_opt = FOP_game_Cournot(n_player, qmax, theta_t, (q1_hat, q2_hat, q3_hat, xi_hat), squaring_param)
        try:
            x_opt = FOP_game_Cournot(n_player, qmax, theta_t, (q1_hat, q2_hat, q3_hat, xi_hat), squaring_param)
            # print(x_opt)
            # print('distance between x and \hat{x} is', np.linalg.norm(x_opt - x_hat))
        except TypeError:
            print('there is sth wrong with the gradient computation..., please check them')

        phi_j, _, _,_ = phi_func_Cournot((q1_hat, q2_hat, q3_hat), xi_hat)

        # n_player = 2
        each_theta_len = len(theta_t)
        I_n = np.ones(each_theta_len)
        temp_m = np.kron(I_n, (x_opt - x_hat))

        grad_temp = phi_j * temp_m.reshape(-1, order='F')# * means element-size multiplication

        grad_temp_reshape = grad_temp.reshape(-1, len(theta_t))
        grad_temp = np.sum(grad_temp_reshape, axis=0)
        # print(grad_temp.shape)
        assert len(grad_temp) == len(theta_t)

        aux += grad_temp

    # Subgradient of the sum of losses
    loss_grad = (1/len(samples)) * aux

    # (Sub)gradient of the regularizer
    reg_grad = gradient_regularizer(theta_t, regularizer, reg_param, theta_hat)

    return reg_grad, loss_grad


def normalize(vec, norm):
    """
    Normalize nonzero array according to some norm.

    Parameters
    ----------
    vec : 1D ndarray
        Array to be normalized.
    norm : {non-zero int, inf, -inf},
        Order of the norm. See numpy.linalg.norm documentation for more
        details.

    Returns
    -------
    vec : 1D ndarray
        Normalized array.

    """
    norm_vec = np.linalg.norm(vec, norm)
    if norm_vec > 0:
        vec = vec/norm_vec
    return vec

def project_operator(theta):
    # Projection onto the feasible set Θ = {θ: θ[0]<0 and θ[5]<0}
    # print(theta)
    for i in range(len(theta)):
        theta[i] = max(theta[i], 1e-10) ## Ensure θ[1] > 0
    # print(theta)
    return theta

def grad_step(
    theta_t, eta_t, reg_grad, loss_grad, reg_param, Theta, step,
    normalize_grad
):
    """
    Perform a subgradient step.

    Parameters
    ----------
    theta_t : 1D ndarray
        Initial vector.
    eta_t : float
        Step-size constant.
    reg_grad : 1D ndarray
        (Sub)gradient of the regularizer.
    loss_grad : 1D ndarray
        (Sub)gradient of the sum of loss functions.
    reg_param : float, optional
        Nonnegative regularization parameter. The default is 0.
    Theta : {None, 'nonnegative'}
        Constraints on cost vector theta.
    step : {'standard', 'exponentiated'}
        Type of update step used for the first-order algorithm. If 'standard',
        uses standard "subgradient method" update steps:
        theta_{t+1} = theta_t - step_size(t)*subgradient. If 'exponentiated',
        uses exponentiated steps:
        theta_{t+1} = theta_t * exp{-step_size(t)*subgradient}.
    normalize_grad : bool
        If True, subgradient vectors are normalized before each iteration of
        the algorithm. If step='standard', the L2 norm of the subgradient is
        used. If step='standard', the L-infinity norm of the subgradient is
        used.

    Returns
    -------
    theta_t1 : 1D ndarray
        Vector subgradient step.

    """
    if step == 'standard':
        grad = reg_grad + loss_grad
        if normalize_grad:
            grad = normalize(grad, 2)
        theta_t1 = theta_t - eta_t*grad
        ## add projection operator ##
        # theta_t1 = project_operator(theta_t1)

    elif step == 'exponentiated':
        grad = loss_grad #why not adding term reg_grad because of equation (21) in Page-16
        if normalize_grad:
            grad = normalize(grad, np.inf)
        if Theta == 'nonnegative':
            theta_t1 = np.multiply(theta_t, np.exp(-eta_t*grad))
            norm_theta_t1 = np.sum(theta_t1)
        else:
            warnings.warn('The combination of  step = \'exponentiated\' and '
                          'Theta != \'nonnegative\' still need to be tested.')
            theta_pos_t = np.clip(theta_t, 0, None)
            theta_neg_t = np.clip(theta_t, None, 0)
            theta_pos_t1 = np.multiply(theta_pos_t, np.exp(-eta_t*grad))
            theta_neg_t1 = np.multiply(theta_neg_t, np.exp(eta_t*grad))
            theta_t1 = theta_pos_t1 - theta_neg_t1
            norm_theta_t1 = np.sum(theta_pos_t1) + np.sum(theta_neg_t1)

        # If outside the simplex, project onto it
        if reg_param*norm_theta_t1 > 1:
            theta_t1 = theta_t1/(reg_param*norm_theta_t1)

    # Projection onto Theta
    if Theta == 'nonnegative':
        theta_t1 = np.clip(theta_t1, 0, None)

    ## add projection operator ##
    theta_t1 = project_operator(theta_t1)

    return theta_t1


args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/cournot/', help = 'the root of data', type = str)
# args_parser.add_argument('--u_type', default = 'linear', help = 'the type of demand function', type = str)
args_parser.add_argument('--seed', default = 4, help = 'random index', type = int)
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args_parser.add_argument('--qmax', default = 6, help = 'upper bound of capacity', type = float)
args_parser.add_argument('--nPlayer', default = 3, help = 'the number of players', type = int)
args_parser.add_argument('--squaring', default = 1, help = 'random index', type = float)
args_parser.add_argument('--Epoch', default = 500, help = 'maximum of iterations in our algorithm', type = int)
args_parser.add_argument('--step', default = 'standard', help = 'the descent update method', type = str)
args_parser.add_argument('--regularizer', default = 'L2_squared', help = 'the regularizer term in our loss', type = str)
args_parser.add_argument('--normalize_grad', default = True, help = 'if gradient is normalized', type = bool)
args_parser.add_argument('--batch_ratio', default = 1.0, help = 'the batch size', type = float)
args_parser.add_argument('--time_limit', default = 0.05, help = 'the time limit in optimization', type = float)
args_parser.add_argument('--step_size_constant', default = 0.5, help = 'the step size constant in update', type = float)
args_parser.add_argument('--reg_param', default = 0.01, help = 'the coefficient of the regularizer loss', type = float)
args_parser.add_argument('--theta_prior', default = 'nonnegative', help = 'the prior of theta', type = str)
args = args_parser.parse_args()

seed = args.seed
file_path = args.file_root
N_train = args.N
qmax = args.qmax
n_player = args.nPlayer

Theta_true = np.load(file_path + 'parameter_' + str(seed) + '_n_' + str(n_player) + '.npy', allow_pickle=True)
dataset_train_df = pd.read_csv(file_path + 'dataset_seed_' + str(seed) + '_train_n_' + str(n_player) + '_N_' + str(N_train) + '_firstOrder.csv')
dataset_test_df = pd.read_csv(file_path + 'dataset_seed_' + str(seed) + '_test_n_' + str(n_player) + '_N_' + str(N_train) + '_firstOrder.csv')
dataset_train = np.array(dataset_train_df)
dataset_test = np.array(dataset_test_df)

normalize_grad = args.normalize_grad
batch_ratio = args.batch_ratio
time_limit = args.time_limit
step_size_constant = args.step_size_constant

epoch_max = args.Epoch
step = args.step #'exponentiated'
regularizer = args.regularizer

qmax_train = math.ceil(np.max(dataset_train[:, :(dataset_train.shape[1]-1)]))
qmax_test = math.ceil(np.max(dataset_test[:, :(dataset_test.shape[1]-1)]))
qmax = min(max(qmax_train, qmax_test), qmax)
print("qmax is {}".format(qmax))

# #### 'L2-squared' and 'standard' fails due to Eucliduan-geometry......
squaring_param = args.squaring

Theta_Prior = args.theta_prior
reg_param = args.reg_param
batch = args.batch_ratio
T_max_alg = int(epoch_max / batch)

if step == 'exponentiated':
    reg_param_alg = 1 / np.linalg.norm(np.array(Theta_true), 1) #theta_opt is computed based on the consistent algorithm
else:
    reg_param_alg = reg_param
# reg_param_alg = reg_param
save_path = './results/cournot/Seed_' + str(seed) + '/' + step + '_' + regularizer
if not os.path.exists(save_path):
    os.makedirs(save_path)

time_s = time.time()
run_set = [0]#
callbacks_runs = []
ASL_runs = []
for r_idx in range(len(run_set)):#range(n_runs):
    #### runs -- r #####
    r = run_set[r_idx]
    # theta_0 = np.random.rand(n_theta * n_player)
    theta_0 = np.random.uniform(low=0, high=5, size=(n_player + 3,))
    print('theta_0 is {}'.format(theta_0))
    print('sample number is {}'.format(dataset_train.shape[0]))

    # print('corrected theta_0 is {}'.format(theta_0))
    callback_results, ASL_Set = FOM_Game_Cournot(dataset_train,  n_player, qmax, theta_0,
                                                 step_size, T_max_alg,
                                                 Theta=Theta_Prior,
                                                 step=step,
                                                 regularizer=regularizer,
                                                 reg_param=reg_param_alg,
                                                 squaring_param =squaring_param,
                                                 batch_type=batch,
                                                 callback=callback,
                                                 normalize_grad=normalize_grad)

    print(callback_results)
    callbacks_runs.append(callback_results)
    ASL_runs.append(ASL_Set)
    ## save all-thetas ##
    thetas_iter_name = save_path + '/prior1_thetas_run_' + str(r) + '_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy'
    np.save(thetas_iter_name, np.array(callback_results, dtype=object), allow_pickle=True)

thetas_ASL_name = save_path + '/prior1_loss_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.csv'
runs_LOSS_np = np.array(ASL_runs)
pd.DataFrame(runs_LOSS_np).to_csv(thetas_ASL_name, index = False)

print('After running 5 exps, time spent {} minutes'.format((time.time()-time_s)/60))

##### plot the average result for ASL LOSS #####
assert runs_LOSS_np.shape[0] == len(callbacks_runs)
runs_average = runs_LOSS_np.mean(axis=0)     # to take the mean of each col
runs_std = runs_LOSS_np.std(axis=0)

plt.rcParams["mathtext.fontset"] = 'cm'
plt.rcParams['font.family'] = 'serif'
plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]

plt.figure(0)
plt.plot(range(1, len(runs_average) + 1), runs_average, label='ASL', color='red', linewidth=2)
plt.fill_between(range(1, len(runs_average) + 1), runs_average-runs_std, runs_average+runs_std, alpha=0.25, edgecolor='#FF4500', facecolor='#FE420F')
# plt.plot(range(1, len(err_T) + 1), np.repeat(1.0710639067698995, len(err_T)), label='Bertsimas')
plt.ylabel(
    'Loss Value', fontsize=18
)
plt.xlabel(r'Iterations of $ \vartheta $', fontsize=14)
plt.xlim(0, len(runs_average))
# plt.ylim(40, 50)
plt.grid(visible=True)
plt.legend(fontsize='16', loc='upper right')
plt.tight_layout()
# saving the figure.
plt.savefig(save_path + '/prior1_avgLoss_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train)
     + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max) + '.png')
plt.show()

runs_error = []
for r_idx in range(len(run_set)): #range(n_runs):
    r = run_set[r_idx]
    callback_results = callbacks_runs[r_idx]
    Theta_estimated = callback_results[len(callback_results)-1][0]
    error = np.linalg.norm(np.array(Theta_true) - np.array(Theta_estimated))
    print('True theas is ', Theta_true)
    print('Estimated error is {}'.format(error)) #Estimated error is 2.9614639158104348

    Theta_norm = Theta_true / np.linalg.norm(Theta_true)
    Theta_estimated_norm = Theta_estimated/np.linalg.norm(Theta_estimated)
    error_norm = np.linalg.norm(np.array(Theta_norm) - np.array(Theta_estimated_norm))
    print('Estimated error (all normalize to l2-norm) is {}'.format(error_norm)) #Estimated error (all normalize to l2-norm) is 0.9603612684936694

    ##### plot all theta_t ######
    err_T = []
    for i in range(1, len(callback_results)):
        theta_t = callback_results[i][0]
        theta_t_norm = theta_t/np.linalg.norm(theta_t)
        error_t = np.linalg.norm(np.array(Theta_norm) - np.array(theta_t_norm))
        err_T.append(error_t)

        print('t is {}'.format(i))
        print('error_theta_t is {}'.format(error_t))

    runs_error.append(err_T)
    plt.rcParams["mathtext.fontset"] = 'cm'
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]

    plt.figure()
    plt.plot(range(1, len(err_T) + 1), err_T, label='ASL', color='red', linewidth=2)
    # plt.plot(range(1, len(err_T) + 1), np.repeat(1.0710639067698995, len(err_T)), label='Bertsimas')
    plt.ylabel(
        r'$\| \vartheta_{\mathrm{esti}} - \vartheta_{\mathrm{true}} \|_2$', fontsize=18
    )
    plt.xlabel(r'Iterations of $ \vartheta $', fontsize=14)
    plt.xlim(0, len(err_T))
    # plt.ylim(0.5, 1.2)
    plt.grid(visible=True)
    plt.legend(fontsize='16', loc='upper right')
    plt.tight_layout()
    # saving the figure.
    plt.savefig(save_path + '/prior1_run_' + str(r) + '_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max) +'.png')
    plt.show()
    plt.close()

##### plot the average result #####
runs_error_np = np.array(runs_error)
assert runs_error_np.shape[0] == len(runs_error)
runs_average = runs_error_np.mean(axis=0)     # to take the mean of each col
runs_std = runs_error_np.std(axis=0)

plt.rcParams["mathtext.fontset"] = 'cm'
plt.rcParams['font.family'] = 'serif'
plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]

plt.figure(1)
plt.plot(range(1, len(runs_average) + 1), runs_average, label='ASL', color='red', linewidth=2)
plt.fill_between(range(1, len(runs_average) + 1), runs_average-runs_std, runs_average+runs_std, alpha=0.25, edgecolor='#FF4500', facecolor='#FE420F')
# plt.plot(range(1, len(err_T) + 1), np.repeat(1.0710639067698995, len(err_T)), label='Bertsimas')
plt.ylabel(
    r'$\| \vartheta_{\mathrm{esti}} - \vartheta_{\mathrm{true}} \|_2$', fontsize=18
)
plt.xlabel(r'Iterations', fontsize=14)
plt.xlim(0, len(runs_average))
# plt.ylim(0.5, 1.2)
plt.grid(visible=True)
plt.legend(fontsize='16', loc='upper right')
plt.tight_layout()
# saving the figure.
plt.savefig(save_path +'/prior1_avg_ASL_squaring_' + str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max) + '.png')
plt.show()



