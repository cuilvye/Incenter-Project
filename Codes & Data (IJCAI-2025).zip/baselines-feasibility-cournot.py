#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""
import pandas as pd
import numpy as np
import gurobipy as gp
import os, sys
import time
from gurobipy import GRB, quicksum
from scipy.optimize import fsolve
import argparse
import itertools

from utils_cournot_incenter import phi_func_Cournot
from utils_cournot import firstOrderEq_givenXi_linearDemand
from utils_cournot import ProjectAlgEq_givenXi_linearDemand_Cournot


def utility_inference_func_feasibility_cournot(df_train, qmax, n_theta, verbose):
    # Compute the absolute difference between each element in the third column and the median #
    p1_actions = np.linspace(0, 1, num=10).tolist()
    # p2_actions = np.linspace(0, qmax, num=30).tolist()
    # p3_actions = np.linspace(0, qmax, num=30).tolist()
    # candidate_actions = list(itertools.product(p1_actions, p2_actions, p3_actions))
    arrays = []
    for i  in range(df_train.shape[0]):
        arrays.append(p1_actions)
    candidate_actions = list(itertools.product(*arrays))
    # the total number of variables

    # Initialize Gurobi model
    mdl = gp.Model()
    if not verbose:
        mdl.setParam('OutputFlag', 0)

    theta = mdl.addVars(n_theta, lb=-gp.GRB.INFINITY, vtype=gp.GRB.CONTINUOUS)

    # if Theta == 'nonnegative':
    #     mdl.addConstrs(theta[i] >= 0 for i in range(p))

    ## \theta_{i} should be >= 0
    # mdl.addConstrs(theta[i] >= 0.0001 for i in range(n_theta))
    mdl.addConstr(theta[0] >= 0.0001)


    ### Need to escape the case that thetas is equal to zeros!!!!!!!!!
    # Add constraints
    start_time = time.time()
    for j in range(df_train.shape[0]):
        qstar_j = df_train[j, :-1]
        xi_hat_j = df_train[j, -1]
        q1_hat_j, q2_hat_j, q3_hat_j =qstar_j[0], qstar_j[1], qstar_j[2]
        for k in range(len(candidate_actions)):
            x = candidate_actions[k]

            ## each constraint  ##
            phi_j, _, _, _ = phi_func_Cournot((q1_hat_j, q2_hat_j, q3_hat_j), xi_hat_j)
            temp_m = np.kron(np.ones(n_theta), (x - qstar_j))
            ma = temp_m.reshape(-1, order='F')  # The order='F' parameter ensures that the matrix is flattened in column-major (Fortran-style) order, meaning it concatenates column by column.

            assert len(phi_j) == len(ma)
            res_temp = phi_j * ma  # * means: element-wise multiplication

            mdl.addConstr(gp.quicksum(theta[i] * res_temp[i] for i in range(n_theta)) <= 0)

    mdl.setObjective(0, gp.GRB.MINIMIZE)
    mdl.optimize()

    print('time spend is {} minutes'.format((time.time() - start_time) / 60))
    print('model status is {}'.format(mdl.Status))
    if mdl.status == 4:
        mdl.computeIIS()
        mdl.write("model.ilp")

        # Print out the IIS constraints and variables
        print('\nThe following constraints and variables are in the IIS:')
        for c in mdl.getConstrs():
            if c.IISConstr: print(f'\t{c.constrname}: {mdl.getRow(c)} {c.Sense} {c.RHS}')

        for v in mdl.getVars():
            if v.IISLB: print(f'\t{v.varname} ≥ {v.LB}')
            if v.IISUB: print(f'\t{v.varname} ≤ {v.UB}')

    status = mdl.Status
    if status == gp.GRB.UNBOUNDED:
        print('The model cannot be solved because it is unbounded')
        # sys.exit(0)
    if status == gp.GRB.OPTIMAL:
        print('The optimal objective is %g' % mdl.ObjVal)
        theta_opt = np.array([theta[i].X for i in range(n_theta)])
        print('The optimal solution is:')
        print(theta_opt)
        # sys.exit(0)
    # if status != gp.GRB.INF_OR_UNBD and status != gp.GRB.INFEASIBLE:
    #     print('Optimization was stopped with status %d' % status)
    #     sys.exit(0)

    # Relax the bounds and try to make the model feasible
    print('The model is infeasible; relaxing the bounds')
    orignumvars = mdl.NumVars
    # relaxing only variable bounds #m.feasRelaxS(0, False, True, False)
    mdl.feasRelaxS(0, False, True, False)
    # for relaxing variable bounds and constraint bounds use
    # m.feasRelaxS(0, False, True, True)
    mdl.optimize()

    status = mdl.Status
    if status in (gp.GRB.INF_OR_UNBD, gp.GRB.INFEASIBLE, gp.GRB.UNBOUNDED):
        print('The relaxed model cannot be solved \
                because it is infeasible or unbounded')
        sys.exit(1)
    if status != gp.GRB.OPTIMAL:
        print('Optimization was stopped with status %d' % status)
        sys.exit(1)

    # print the values of the artificial variables of the relaxation
    print('\nSlack values:')
    slacks = mdl.getVars()[orignumvars:]
    for sv in slacks:
        if sv.X > 1e-9:
            print('%s = %g' % (sv.VarName, sv.X))

    theta_opt = np.array([theta[i].X for i in range(n_theta)])

    if mdl.status != 2:
        print(
            f'Optimal solution not found. Gurobi status code = {mdl.status}.'
            'Set the flag verbose=True for more details. Note: the IO'
            'optimization problem will always be infeasible if the data is not'
            'consistent.'
        )

    return theta_opt


# Example usage
args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/', help = 'the root of data', type = str)
args_parser.add_argument('--u_type', default = 'linear', help = 'the type of demand function', type = str)
# args_parser.add_argument('--seed', default = 0, help = 'the random index of dataset', type = int)
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args_parser.add_argument('--qmax', default = 6, help = 'upper bound of price', type = float)
args_parser.add_argument('--nPlayer', default = 3, help = 'the number of players', type = int)
args = args_parser.parse_args()

file_path  = args.file_root
utility_type = args.u_type
# seed = args.seed
qmax = args.qmax
N_train = args.N
n_player = args.nPlayer
print("pmax is {}".format(qmax))

save_path = './results/cournot/aaai_Baseline1/'
if not os.path.exists(save_path):
    os.makedirs(save_path)

seeds_theta_estimated = []
seeds_theta_estimated_normed = []
seeds_err_normed = []
seeds_equilibrium = []
seeds_equilibrium_approx = []
epsilon = 0.0001
for seed in range(10):
    print('Seed {}'.format(seed))
    Theta_true_normed =  np.load(file_path + 'parameter_' + str(seed) + '_n_' + str(n_player)+'.npy', allow_pickle=True)

    train_file_path = file_path + 'dataset_seed_'+str(seed)+'_train_n_' + str(n_player)+'_N_' + str(N_train) + '_firstOrder'+'.csv'
    dataset_train_df = pd.read_csv(train_file_path)
    test_file_path = file_path + 'dataset_seed_' + str(seed) + '_test_n_' + str(n_player) + '_N_' + str(N_train) + '_firstOrder'+'.csv'
    dataset_test_df = pd.read_csv(test_file_path)

    ######## start to estimate thetas ########
    Theta_estimated = utility_inference_func_feasibility_cournot(np.array(dataset_train_df),qmax, len(Theta_true_normed), 0)

    # error = np.linalg.norm(np.array(Theta_true_normed) - np.array(Theta_estimated))
    # # Estimated Theta is  [0.0, 0.6805791473995495, 0.0, 2.48023119594616, 1.3519388303126407, 0.0, 0.0, 0.0]
    # print('True theas is ', Theta_true_normed)
    # print('Estimated error is {}'.format(error)) #Estimated error is 2.9614639158104348

    Theta_estimated_normed = Theta_estimated / np.linalg.norm(Theta_estimated)
    error_normed = np.linalg.norm(np.array(Theta_true_normed) - np.array(Theta_estimated_normed))
    print('Estimated error (all normalize to l2-norm) is {}'.format(error_normed)) #Estimated error (all normalize to l2-norm) is 1.0710639067698995

    seeds_theta_estimated.append(Theta_estimated)
    seeds_theta_estimated_normed.append(Theta_estimated_normed)
    seeds_err_normed.append(error_normed)

    # ######## to evaluate the \| x_esti - x_true \|_{2} on out-of samples, i.e., testing dataset #######
    difference_set_test = []
    difference_set_test_approx = []
    dataset_test = np.array(dataset_test_df)
    for j in range(dataset_test.shape[0]):
        p_hat = dataset_test[j, 0:-1]
        assert len(p_hat) == dataset_test.shape[1] - 1
        xi_hat = dataset_test[j, -1]

        p_solution = firstOrderEq_givenXi_linearDemand(xi_hat, Theta_estimated_normed, qmax)
        p_solution_approx1 = ProjectAlgEq_givenXi_linearDemand_Cournot(xi_hat, Theta_estimated_normed, qmax, 1000, 0.01, epsilon)
        # print('Exact solution is {}'.format(p_solution))
        # print("Approximate {}-solution is {}".format(epsilon, p_solution_approximate))

        difference_j = np.linalg.norm(p_solution - p_hat)
        difference_set_test.append(difference_j)

        difference_j_approxi = np.linalg.norm(p_solution_approx1 - p_hat)
        difference_set_test_approx.append(difference_j_approxi)

    # print(difference_set_test)
    # print(np.mean(difference_set_test))
    # print(difference_set_test_approx)
    # print(np.mean(difference_set_test_approx))
    seeds_equilibrium.append(np.mean(difference_set_test))
    seeds_equilibrium_approx.append(np.mean(difference_set_test_approx))

#### save the results
result_dict = {
               'l2-norm-error-set': seeds_err_normed,
               'l2-norm-error-mean': np.mean(seeds_err_normed),
               'l2-norm-error-std': np.std(seeds_err_normed),
               'error-equilibrium': seeds_equilibrium,
               'error-equilibrium-mean': np.mean(seeds_equilibrium),
               'error-equilibrium-std': np.std(seeds_equilibrium),
               str(epsilon) +'-equilibrium-approx-mean': np.mean(seeds_equilibrium_approx),
               str(epsilon) +'-equilibrium-approx-std': np.std(seeds_equilibrium_approx),
               }

with open(save_path + 'Feasibility_u_' + utility_type +'_N_'+str(N_train)+'.txt', 'w') as f:
    print(result_dict, file = f)
    print(result_dict)


