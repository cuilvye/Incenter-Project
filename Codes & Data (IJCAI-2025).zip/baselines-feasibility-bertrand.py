#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""
import pandas as pd
import numpy as np
import gurobipy as gp
import os, sys
import time
from gurobipy import GRB, quicksum
from scipy.optimize import fsolve
import argparse
import itertools

from utils_bertrand_incenter import phi_func
from utils_bertrand import firstOrderEq_givenXi_linearDemand
from utils_bertrand import ProjectAlgEq_givenXi_linearDemand


def utility_inference_func_feasibility(df_train, pmax, n_player, n_theta_each, verbose):
    # Compute the absolute difference between each element in the third column and the median #
    p1_actions = np.linspace(0, pmax, num=200).tolist()
    p2_actions = np.linspace(0, pmax, num=200).tolist()
    candidate_actions = list(itertools.product(p1_actions, p2_actions))

    # the total number of variables
    p = n_player * n_theta_each

    # Initialize Gurobi model
    mdl = gp.Model()
    if not verbose:
        mdl.setParam('OutputFlag', 0)

    theta = mdl.addVars(p, lb=-gp.GRB.INFINITY, vtype=gp.GRB.CONTINUOUS)

    # if Theta == 'nonnegative':
    #     mdl.addConstrs(theta[i] >= 0 for i in range(p))

    ## \theta_{ii} should be  <= 0
    mdl.addConstrs(theta[i] <= - 1e-4 for i in [0, 5])
    # mdl.addConstrs(theta[i] >= -2 for i in [0, 5])

    # ### \theta_{i4} should be  <= 0
    # mdl.addConstrs(theta[(i + 1) * n - 2] <= 0 for i in range(n_player))
    # mdl.addConstrs(theta[(i + 1) * n - 2] >= -10 for i in range(n_player))
    ### \theta_{i5} = 1, for i =1, 2
    # mdl.addConstrs(theta[(i + 1) * n_theta_each - 1] == 1 for i in range(n_player))

    ## other elments should be in [-10, 2]
    # idx_rest = [1, 2, 3, 4, 6, 7]
    # mdl.addConstrs(theta[i] >= 1e-4 for i in idx_rest)
    mdl.addConstr(theta[3] == theta[6]) #\theta_{14}=\theta_{23}
    # # print(idx_rest): [1, 2, 3, 5, 7, 8]
    # mdl.addConstrs(theta[i] <= 2  for i in idx_rest)
    # mdl.addConstrs(theta[i] >= 0  for i in idx_rest)

    # mdl.addConstr(gp.quicksum(theta) == 1)
    # mdl.addConstrs(theta[i] >= -10 for i in range(len(theta)))
    # mdl.addConstrs(theta[i] <= 2 for i in range(len(theta)))

    ### Need to escape the case that thetas is equal to zeros!!!!!!!!!
    # Add constraints
    start_time = time.time()

    for j in range(df_train.shape[0]):
        pstar_j = df_train[j, :2]
        xi_j = df_train[j, -1]
        for k in range(len(candidate_actions)):
            x = candidate_actions[k]

            ## each constraint  ##
            phi_j, _, _  = phi_func(pstar_j, xi_j)
            temp_m = np.kron(np.ones(n_theta_each), (x - pstar_j))
            ma = temp_m.reshape(-1, order='F')  # The order='F' parameter ensures that the matrix is flattened in column-major (Fortran-style) order, meaning it concatenates column by column.

            assert len(phi_j) == len(ma)
            res_temp = phi_j * ma  # * means: element-wise multiplication

            mdl.addConstr(gp.quicksum(theta[i] * res_temp[i] for i in range(p)) <= 0)

    mdl.setObjective(0, gp.GRB.MINIMIZE)
    mdl.optimize()

    print('time spend is {} minutes'.format((time.time() - start_time) / 60))
    print('model status is {}'.format(mdl.Status))
    if mdl.status == 4:
        mdl.computeIIS()
        mdl.write("model.ilp")

        # Print out the IIS constraints and variables
        print('\nThe following constraints and variables are in the IIS:')
        for c in mdl.getConstrs():
            if c.IISConstr: print(f'\t{c.constrname}: {mdl.getRow(c)} {c.Sense} {c.RHS}')

        for v in mdl.getVars():
            if v.IISLB: print(f'\t{v.varname} ≥ {v.LB}')
            if v.IISUB: print(f'\t{v.varname} ≤ {v.UB}')

    status = mdl.Status
    if status == gp.GRB.UNBOUNDED:
        print('The model cannot be solved because it is unbounded')
        sys.exit(0)
    if status == gp.GRB.OPTIMAL:
        print('The optimal objective is %g' % mdl.ObjVal)
        theta_opt = np.array([theta[i].X for i in range(p)])
        print('The optimal solution is:')
        print(theta_opt)
        # sys.exit(0)
    # if status != gp.GRB.INF_OR_UNBD and status != gp.GRB.INFEASIBLE:
    #     print('Optimization was stopped with status %d' % status)
    #     sys.exit(0)

    # Relax the bounds and try to make the model feasible
    # print('The model is infeasible; relaxing the bounds')
    # orignumvars = mdl.NumVars
    # # relaxing only variable bounds #m.feasRelaxS(0, False, True, False)
    # mdl.feasRelaxS(0, False, True, False)
    # # for relaxing variable bounds and constraint bounds use
    # # m.feasRelaxS(0, False, True, True)
    # mdl.optimize()

    # status = mdl.Status
    # if status in (gp.GRB.INF_OR_UNBD, gp.GRB.INFEASIBLE, gp.GRB.UNBOUNDED):
    #     print('The relaxed model cannot be solved \
    #             because it is infeasible or unbounded')
    #     sys.exit(1)
    # if status != gp.GRB.OPTIMAL:
    #     print('Optimization was stopped with status %d' % status)
    #     sys.exit(1)

    # print the values of the artificial variables of the relaxation
    # print('\nSlack values:')
    # slacks = mdl.getVars()[orignumvars:]
    # for sv in slacks:
    #     if sv.X > 1e-9:
    #         print('%s = %g' % (sv.VarName, sv.X))
    #
    # theta_opt = np.array([theta[i].X for i in range(p)])
    #
    # if mdl.status != 2:
    #     print(
    #         f'Optimal solution not found. Gurobi status code = {mdl.status}.'
    #         'Set the flag verbose=True for more details. Note: the IO'
    #         'optimization problem will always be infeasible if the data is not'
    #         'consistent.'
    #     )

    return theta_opt


# Example usage
args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/', help = 'the root of data', type = str)
args_parser.add_argument('--u_type', default = 'linear', help = 'the type of demand function', type = str)
# args_parser.add_argument('--seed', default = 0, help = 'the random index of dataset', type = int)
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args_parser.add_argument('--pmax', default = 8, help = 'upper bound of price', type = float)
args_parser.add_argument('--nPlayer', default = 2, help = 'the number of players', type = int)
args = args_parser.parse_args()

file_path  = args.file_root
utility_type = args.u_type
# seed = args.seed
pmax = args.pmax
N_train = args.N
n_player = args.nPlayer
print("pmax is {}".format(pmax))

save_path = './results/bertrand/aaai_Baseline1/'
if not os.path.exists(save_path):
    os.makedirs(save_path)

seeds_theta_estimated = []
seeds_theta_estimated_normed = []
seeds_err_normed = []
seeds_equilibrium = []
seeds_equilibrium_approx = []
epsilon = 0.0001
for seed in range(10):
    print('Seed {}'.format(seed))
    Theta_true_normed =  np.load(file_path + 'Seed_' + str(seed) + '_parameters.npy', allow_pickle=True)
    theta_1 = Theta_true_normed[:4]
    theta_2 = Theta_true_normed[4:]

    train_file_path = file_path + 'Seed_' + str(seed) + '_SDP_train_u_' + utility_type + '_N_' + str(N_train) + '_firstOrder'+'.csv'
    dataset_train_df = pd.read_csv(train_file_path)
    test_file_path = file_path + 'Seed_' + str(seed) + '_SDP_test_u_' + utility_type + '_N_' + str(N_train) + '_firstOrder'+'.csv'
    dataset_test_df = pd.read_csv(test_file_path)

    ######## start to estimate thetas ########
    Theta_estimated = utility_inference_func_feasibility(np.array(dataset_train_df), pmax, n_player, len(theta_1), 0)

    # error = np.linalg.norm(np.array(Theta_true_normed) - np.array(Theta_estimated))
    # # Estimated Theta is  [0.0, 0.6805791473995495, 0.0, 2.48023119594616, 1.3519388303126407, 0.0, 0.0, 0.0]
    # print('True theas is ', Theta_true_normed)
    # print('Estimated error is {}'.format(error)) #Estimated error is 2.9614639158104348

    Theta_estimated_normed = Theta_estimated / np.linalg.norm(Theta_estimated)
    error_normed = np.linalg.norm(np.array(Theta_true_normed) - np.array(Theta_estimated_normed))
    print('Estimated error (all normalize to l2-norm) is {}'.format(error_normed)) #Estimated error (all normalize to l2-norm) is 1.0710639067698995

    seeds_theta_estimated.append(Theta_estimated)
    seeds_theta_estimated_normed.append(Theta_estimated_normed)
    seeds_err_normed.append(error_normed)

    # ######## to evaluate the \| x_esti - x_true \|_{2} on out-of samples, i.e., testing dataset #######
    difference_set_test = []
    difference_set_test_approx = []
    dataset_test = np.array(dataset_test_df)
    for j in range(dataset_test.shape[0]):
        p_hat = dataset_test[j, 0:2]
        assert len(p_hat) == 2
        xi_hat = dataset_test[j, 2]

        p_solution = firstOrderEq_givenXi_linearDemand(xi_hat, Theta_estimated_normed[:4], Theta_estimated_normed[4:], pmax)
        p_solution_approx1 = ProjectAlgEq_givenXi_linearDemand(xi_hat, Theta_estimated_normed[:4], Theta_estimated_normed[4:], pmax, 1000, 0.01, epsilon)
        # print('Exact solution is {}'.format(p_solution))
        # print("Approximate {}-solution is {}".format(epsilon, p_solution_approximate))

        difference_j = np.linalg.norm(p_solution - p_hat)
        difference_set_test.append(difference_j)

        difference_j_approxi = np.linalg.norm(p_solution_approx1 - p_hat)
        difference_set_test_approx.append(difference_j_approxi)

    # print(difference_set_test)
    # print(np.mean(difference_set_test))
    # print(difference_set_test_approx)
    # print(np.mean(difference_set_test_approx))
    seeds_equilibrium.append(np.mean(difference_set_test))
    seeds_equilibrium_approx.append(np.mean(difference_set_test_approx))

#### save the results
result_dict = {
               'l2-norm-error-set': seeds_err_normed,
               'l2-norm-error-mean': np.mean(seeds_err_normed),
               'l2-norm-error-std': np.std(seeds_err_normed),
               'error-equilibrium': seeds_equilibrium,
               'error-equilibrium-mean': np.mean(seeds_equilibrium),
               'error-equilibrium-std': np.std(seeds_equilibrium),
               str(epsilon) +'-equilibrium-approx-mean': np.mean(seeds_equilibrium_approx),
               str(epsilon) +'-equilibrium-approx-std': np.std(seeds_equilibrium_approx),
               }

with open(save_path + 'Feasibility_u_' + utility_type +'_N_'+str(N_train)+'.txt', 'w') as f:
    print(result_dict, file = f)
    print(result_dict)


