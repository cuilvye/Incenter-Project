#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""
# INCORPORATE KNOWLEDGE OF THETA #
import os
import argparse
import numpy as np
import pandas as pd
import time, math
import warnings
import gurobipy as gp
import matplotlib.pyplot as plt
from sklearn import preprocessing

from utils_traffic_incenter import ASL_traffic
from utils_traffic_incenter import check_Theta, check_reg_parameter
from utils_traffic_incenter import check_regularizer, warning_theta_hat_reg_param
from utils_traffic_incenter import FOP_game_Traffic, phi_func_traffic


def step_size(t):
    """Step size function."""
    return step_size_constant/np.sqrt(t+1)

def callback(theta):
    """Store input and current time."""
    return theta, time.time()

def FOM_Game_Traffic(
    dataset,
    np_capacities,
    n_arcs,
    p_set,
    theta_0,
    step_size,
    T,
    Theta=None,
    step='standard',
    regularizer='L2_squared',
    reg_param=0,
    squaring_param = 0.001,
    theta_hat=None,
    batch_type=1,
    averaged=0,
    callback=None,
    callback_resolution=1,
    normalize_grad=False,
    verbose=True
):
    pmin, pmax = p_set[0], p_set[1]
    # Check if the inputs are valid
    check_Theta(Theta)
    check_regularizer(regularizer)
    check_reg_parameter(reg_param)

    # Warnings
    warning_theta_hat_reg_param(theta_hat, reg_param)

    if (step == 'exponentiated') and (regularizer != 'L1') and (reg_param > 0):
        raise Exception(
            'To use step = \'exponentiated\' with reg_param > 0,'
            'regularizer = \'L1\' is required.'
        )

    if (step == 'exponentiated') and (theta_hat is not None):
        raise Exception(
            'When step=\'exponentiated\', theta_hat must be None.'
        )

    # Get the dimension of the problem: len(theta_0) and the number of samples #
    N = dataset.shape[0]
    if theta_hat is None:
        theta_hat = np.zeros(len(theta_0))

    theta_t = theta_0
    theta_avg = theta_0
    callback_list = []
    if callback is not None:
        # Evaluate theta_0
        callback_list.append(callback(theta_0))

    ASL_loss_set = []
    for t in range(T):
        if verbose:
            print(f'Iteration {t+1} out of {T}')
            print('')

        eta_t = step_size(t) #eta_t = 0.5/sqrt(t+1)
        if batch_type == 'reshuffled':
            arr = np.arange(N) #array([0, 1, ..., N])
            np.random.shuffle(arr)
            for i in arr:
                samples = [dataset[i]] ## dataset[i]: get i-row of the dataset
                reg_grad, loss_grad = compute_grad_games(n_player, pmax,
                    theta_t, samples, regularizer, reg_param, theta_hat)
                theta_t = grad_step(
                    theta_t, eta_t, reg_grad, loss_grad, reg_param, Theta,
                    step, normalize_grad
                )
        else:
            batch_size = int(np.ceil(batch_type * N)) #batch_type = 1
            sample_idxs = np.random.choice(N, batch_size, replace=False)
            samples = [dataset[i] for i in sample_idxs]
            # squaring_param = 0.001
            reg_grad, loss_grad = compute_grad_games_Traffic(np_capacities, n_arcs, pmax, pmin,
                theta_t, samples, regularizer, reg_param, squaring_param, theta_hat
            )
            # print('reg_grad', reg_grad)
            # print('loss_grad', loss_grad)
            theta_t = grad_step(
                theta_t, eta_t, reg_grad, loss_grad, reg_param, Theta, step,
                normalize_grad
            )
            # print('theta_t', theta_t)

            #### compute the ASL value for each theta
            theta_t_norm = theta_t / np.linalg.norm(theta_t)
            Loss_ASL = ASL_traffic(np_capacities, theta_t_norm, dataset, n_arcs, pmax, pmin, regularizer, reg_param, squaring_param, theta_hat=None)
            print('loss of ASL is : ', Loss_ASL)
            ASL_loss_set.append(Loss_ASL)

        if averaged == 0:
            theta_avg = theta_t
        elif averaged == 1:
            theta_avg = (1/(t+1))*theta_t + (t/(t+1))*theta_avg
        elif averaged == 2:
            theta_avg = (2/(t+2))*theta_t + (t/(t+2))*theta_avg

        if (callback is not None) and (np.mod(t+1, callback_resolution) == 0):
            callback_list.append(callback(theta_avg))

    # Check if the list callback_list is empty
    if callback_list:
        theta_T = callback_list
    else:
        theta_T = theta_avg

    return theta_T, ASL_loss_set


def gradient_regularizer(theta_t, regularizer, reg_param, theta_hat):
    """
    Compute (sub)gradient of the regularizer.

    Parameters
    ----------
    theta_t : 1D ndarray
        Vector where the gradient will be evaluated at.
    regularizer : {'L2_squared', 'L1'}
        Type of regularization on cost vector theta.
    reg_param : float
        Nonnegative regularization parameter..
    theta_hat : 1D ndarray
        A priory belief or estimate of the true cost vector.

    Returns
    -------
    reg_grad : 1D ndarray
        (Sub)gradient of the regularizer evaluated at theta_t.

    """
    if regularizer == 'L2_squared':
        grad = reg_param*(theta_t - theta_hat)
    elif regularizer == 'L1':
        grad = reg_param*np.sign(theta_t - theta_hat)

    return grad


def compute_grad_games_Traffic(np_capacities, n_arcs, pmax, pmin,  theta_t, samples,  regularizer, reg_param, squaring_param, theta_hat):
    aux = 0
    for i in range(len(samples)):
        # Check if the FOP is augmented
        # print(p1_hat, p2_hat, xi_hat)
        x_hat = samples[i]
        try:
            x_opt = FOP_game_Traffic(np_capacities, n_arcs, pmax, pmin, theta_t, x_hat, squaring_param)
            # print(x_opt)
            # print('distance between x and \hat{x} is', np.linalg.norm(x_opt - x_hat))
        except TypeError:
            print('there is sth wrong with the gradient computation..., please check them')


        phi_j = phi_func_traffic(np_capacities, x_hat)

        # n_player = 2
        each_theta_len = int(len(theta_t) / n_arcs)
        I_n = np.ones(each_theta_len)
        temp_m = np.kron(I_n, (x_opt - x_hat))

        aux += phi_j * temp_m.reshape(-1, order='F')# * means element-size multiplication

    # Subgradient of the sum of losses
    loss_grad = - (1/len(samples)) * aux

    # (Sub)gradient of the regularizer
    reg_grad = gradient_regularizer(theta_t, regularizer, reg_param, theta_hat)

    return reg_grad, loss_grad


def normalize(vec, norm):
    """
    Normalize nonzero array according to some norm.

    Parameters
    ----------
    vec : 1D ndarray
        Array to be normalized.
    norm : {non-zero int, inf, -inf},
        Order of the norm. See numpy.linalg.norm documentation for more
        details.

    Returns
    -------
    vec : 1D ndarray
        Normalized array.

    """
    norm_vec = np.linalg.norm(vec, norm)
    if norm_vec > 0:
        vec = vec/norm_vec
    return vec

def project_operator(theta):
    # Projection onto the feasible set Θ = {θ: θ[0]<0 and θ[5]<0}
    # print(theta)
    for i in range(len(theta)):
        theta[i] = max(theta[i], 1e-10)

    return theta

def grad_step(
    theta_t, eta_t, reg_grad, loss_grad, reg_param, Theta, step,
    normalize_grad
):
    """
    Perform a subgradient step.

    Parameters
    ----------
    theta_t : 1D ndarray
        Initial vector.
    eta_t : float
        Step-size constant.
    reg_grad : 1D ndarray
        (Sub)gradient of the regularizer.
    loss_grad : 1D ndarray
        (Sub)gradient of the sum of loss functions.
    reg_param : float, optional
        Nonnegative regularization parameter. The default is 0.
    Theta : {None, 'nonnegative'}
        Constraints on cost vector theta.
    step : {'standard', 'exponentiated'}
        Type of update step used for the first-order algorithm. If 'standard',
        uses standard "subgradient method" update steps:
        theta_{t+1} = theta_t - step_size(t)*subgradient. If 'exponentiated',
        uses exponentiated steps:
        theta_{t+1} = theta_t * exp{-step_size(t)*subgradient}.
    normalize_grad : bool
        If True, subgradient vectors are normalized before each iteration of
        the algorithm. If step='standard', the L2 norm of the subgradient is
        used. If step='standard', the L-infinity norm of the subgradient is
        used.

    Returns
    -------
    theta_t1 : 1D ndarray
        Vector subgradient step.

    """
    if step == 'standard':
        grad = reg_grad + loss_grad
        if normalize_grad:
            grad = normalize(grad, 2)
        theta_t1 = theta_t - eta_t*grad
        ## add projection operator ##
        # theta_t1 = project_operator(theta_t1)

    elif step == 'exponentiated':
        grad = loss_grad #why not adding term reg_grad because of equation (21) in Page-16
        if normalize_grad:
            grad = normalize(grad, np.inf)
        if Theta == 'nonnegative':
            theta_t1 = np.multiply(theta_t, np.exp(-eta_t*grad))
            norm_theta_t1 = np.sum(theta_t1)
        else:
            warnings.warn('The combination of  step = \'exponentiated\' and '
                          'Theta != \'nonnegative\' still need to be tested.')
            theta_pos_t = np.clip(theta_t, 0, None)
            theta_neg_t = np.clip(theta_t, None, 0)
            theta_pos_t1 = np.multiply(theta_pos_t, np.exp(-eta_t*grad))
            theta_neg_t1 = np.multiply(theta_neg_t, np.exp(eta_t*grad))
            theta_t1 = theta_pos_t1 - theta_neg_t1
            norm_theta_t1 = np.sum(theta_pos_t1) + np.sum(theta_neg_t1)

        # If outside the simplex, project onto it
        if reg_param*norm_theta_t1 > 1:
            theta_t1 = theta_t1/(reg_param*norm_theta_t1)

    # Projection onto Theta
    if Theta == 'nonnegative':
        theta_t1 = np.clip(theta_t1, 0, None)

    ## add projection operator ##
    theta_t1 = project_operator(theta_t1)

    return theta_t1


args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/traffic/', help = 'the root of data', type = str)
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args_parser.add_argument('--squaring', default = 10, help = 'random index', type = float)
args_parser.add_argument('--Epoch', default = 300, help = 'maximum of iterations in our algorithm', type = int)
args_parser.add_argument('--step', default = 'standard', help = 'the descent update method', type = str)
args_parser.add_argument('--regularizer', default = 'L2_squared', help = 'the regularizer term in our loss', type = str)
args_parser.add_argument('--normalize_grad', default = True, help = 'if gradient is normalized', type = bool)
args_parser.add_argument('--batch_ratio', default = 1.0, help = 'the batch size', type = float)
args_parser.add_argument('--time_limit', default = 0.05, help = 'the time limit in optimization', type = float)
args_parser.add_argument('--step_size_constant', default = 100, help = 'the step size constant in update', type = float)
args_parser.add_argument('--reg_param', default = 0.01, help = 'the coefficient of the regularizer loss', type = float)
args_parser.add_argument('--theta_prior', default = 'nonnegative', help = 'the prior of theta', type = str)
args = args_parser.parse_args()

file_path = args.file_root
# utility_type = args.u_type
N_train = args.N

Theta_true_file = pd.read_csv(os.path.join(file_path, "thetas-true-N-" + str(N_train) + ".csv"))
# print(list(Theta_true_file))
theta_true = np.array(Theta_true_file[['theta_0', 'theta_1']])
Theta_true = theta_true.flatten() #a=matrix([[1, 2],[3, 4]]), a.flatten() = matrix([[1, 2, 3, 4]])

np_capacities = np.array(Theta_true_file['capacity'])

dataset_train_df = pd.read_csv(file_path + "dataset_train_Flow_N_"+str(N_train)+".csv", header = 0)
# dataset_test_df = pd.read_csv(file_path + 'dataset_test_u_'+ utility_type +'_N_' + str(N_train) + '_firstOrder.csv')
dataset_train = np.array(dataset_train_df)
# dataset_test = np.array(dataset_test_df)
### only for this dataset
dataset_train  = preprocessing.normalize(dataset_train)
# n_player = 2 # player number is 2
n_arcs = dataset_train.shape[1]
n_theta = 2

# pmax = math.ceil(max(np.max(dataset_train[:, 0]), np.max(dataset_train[:, 1])))
pmax = np.max(dataset_train)
pmin = np.min(dataset_train)

normalize_grad = args.normalize_grad
batch_ratio = args.batch_ratio
time_limit = args.time_limit
step_size_constant = args.step_size_constant

epoch_max = args.Epoch
step = args.step #'exponentiated'
regularizer = args.regularizer
squaring_param = args.squaring

Theta_Prior = args.theta_prior
reg_param = args.reg_param
batch = args.batch_ratio
T_max_alg = int(epoch_max / batch)

if step == 'exponentiated':
    reg_param_alg = 1 / np.linalg.norm(np.array(Theta_true), 1) #theta_opt is computed based on the consistent algorithm
else:
    reg_param_alg = reg_param
# reg_param_alg = reg_param
save_path = './results/traffic/' + step + '_' + regularizer
if not os.path.exists(save_path):
    os.makedirs(save_path)

time_s = time.time()
# n_runs = 5
run_set = [0, 1, 2, 3, 4]#
callbacks_runs = []
ASL_runs = []
for r_idx in range(len(run_set)):#range(n_runs):
    #### runs -- r #####
    r = run_set[r_idx]
    # theta_0 = np.random.rand(n_theta * n_player)
    theta_0 = np.random.uniform(low=0, high=5, size=(len(Theta_true),))
    # theta_0[0] = - theta_0[0]
    # theta_0[5] = - theta_0[5]
    print('theta_0 is {}'.format(theta_0))
    print('sample number is {}'.format(dataset_train.shape[0]))
    # theta_0[0] = - theta_0[0]
    # theta_0[5] = - theta_0[5]
    # print('corrected theta_0 is {}'.format(theta_0))
    callback_results, ASL_Set = FOM_Game_Traffic(dataset_train, np_capacities, n_arcs, (pmin, pmax), theta_0,
                               step_size, T_max_alg,
                               Theta=Theta_Prior,
                               step=step,
                               regularizer=regularizer,
                               reg_param=reg_param_alg,
                               squaring_param =squaring_param,
                               batch_type=batch,
                               callback=callback,
                               normalize_grad=normalize_grad)

    print(callback_results)
    callbacks_runs.append(callback_results)
    ASL_runs.append(ASL_Set)
    ## save all-thetas ##
    thetas_iter_name = save_path + '/prior1_thetas_run_' + str(r) + '_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.npy'
    np.save(thetas_iter_name, np.array(callback_results, dtype=object), allow_pickle=True)

thetas_ASL_name = save_path + '/prior1_losses_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max)+'.csv'
runs_LOSS_np = np.array(ASL_runs)
pd.DataFrame(runs_LOSS_np).to_csv(thetas_ASL_name, index = False)

print('After running 5 exps, time spent {} minutes'.format((time.time()-time_s)/60))

##### plot the average result for ASL LOSS #####
assert runs_LOSS_np.shape[0] == len(callbacks_runs)
runs_average = runs_LOSS_np.mean(axis=0)     # to take the mean of each col
runs_std = runs_LOSS_np.std(axis=0)

plt.rcParams["mathtext.fontset"] = 'cm'
plt.rcParams['font.family'] = 'serif'
plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]

plt.figure(0)
plt.plot(range(1, len(runs_average) + 1), runs_average, label='ASL', color='red', linewidth=2)
plt.fill_between(range(1, len(runs_average) + 1), runs_average-runs_std, runs_average+runs_std, alpha=0.25, edgecolor='#FF4500', facecolor='#FE420F')
# plt.plot(range(1, len(err_T) + 1), np.repeat(1.0710639067698995, len(err_T)), label='Bertsimas')
plt.ylabel(
    'Loss Value', fontsize=18
)
plt.xlabel(r'Iterations of $ \vartheta $', fontsize=14)
plt.xlim(0, len(runs_average))
# plt.ylim(40, 80)
plt.grid(visible=True)
plt.legend(fontsize='16', loc='upper right')
plt.tight_layout()
# saving the figure.
plt.savefig(save_path + '/prior1_loss_avg_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train)
     + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max) + '.png')
plt.show()

runs_error = []
for r_idx in range(len(run_set)): #range(n_runs):
    r = run_set[r_idx]
    callback_results = callbacks_runs[r_idx]
    Theta_estimated = callback_results[len(callback_results)-1][0]
    # error = np.linalg.norm(np.array(Theta_true) - np.array(Theta_estimated))
    # print('True theas is ', Theta_true)
    # print('Estimated error is {}'.format(error)) #Estimated error is 2.9614639158104348

    Theta_norm = Theta_true / np.linalg.norm(Theta_true)
    # Theta_estimated_norm = Theta_estimated/np.linalg.norm(Theta_estimated)
    # error_norm = np.linalg.norm(np.array(Theta_norm) - np.array(Theta_estimated_norm))
    # print('Estimated error (all normalize to l2-norm) is {}'.format(error_norm)) #Estimated error (all normalize to l2-norm) is 0.9603612684936694

    ##### plot all theta_t ######
    err_T = []
    for i in range(1, len(callback_results)):
        theta_t = callback_results[i][0]
        theta_t_norm = theta_t/np.linalg.norm(theta_t)
        error_t = np.linalg.norm(np.array(Theta_norm) - np.array(theta_t_norm))
        err_T.append(error_t)

        print('t is {}'.format(i))
        print('error_theta_t is {}'.format(error_t))

    runs_error.append(err_T)
    plt.rcParams["mathtext.fontset"] = 'cm'
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]

    plt.figure()
    plt.plot(range(1, len(err_T) + 1), err_T, label='ASL', color='red', linewidth=2)
    # plt.plot(range(1, len(err_T) + 1), np.repeat(1.0710639067698995, len(err_T)), label='Bertsimas')
    plt.ylabel(
        r'$\| \vartheta_{\mathrm{esti}} - \vartheta_{\mathrm{true}} \|_2$', fontsize=18
    )
    plt.xlabel(r'Iterations of $ \vartheta $', fontsize=14)
    plt.xlim(0, len(err_T))
    # plt.ylim(0.5, 1.2)
    plt.grid(visible=True)
    plt.legend(fontsize='16', loc='upper right')
    plt.tight_layout()
    # saving the figure.
    plt.savefig(save_path + '/prior1_run_' + str(r) + '_ASL_squaring_'+str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max) +'.png')
    plt.show()
    plt.close()

##### plot the average result #####
runs_error_np = np.array(runs_error)
assert runs_error_np.shape[0] == len(runs_error)
runs_average = runs_error_np.mean(axis=0)     # to take the mean of each col
runs_std = runs_error_np.std(axis=0)

plt.rcParams["mathtext.fontset"] = 'cm'
plt.rcParams['font.family'] = 'serif'
plt.rcParams["figure.figsize"] = plt.rcParamsDefault["figure.figsize"]

plt.figure(1)
plt.plot(range(1, len(runs_average) + 1), runs_average, label='ASL', color='red', linewidth=2)
plt.fill_between(range(1, len(runs_average) + 1), runs_average-runs_std, runs_average+runs_std, alpha=0.25, edgecolor='#FF4500', facecolor='#FE420F')
# plt.plot(range(1, len(err_T) + 1), np.repeat(1.0710639067698995, len(err_T)), label='Bertsimas')
plt.ylabel(
    r'$\| \vartheta_{\mathrm{esti}} - \vartheta_{\mathrm{true}} \|_2$', fontsize=18
)
plt.xlabel(r'Iterations', fontsize=14)
plt.xlim(0, len(runs_average))
# plt.ylim(0.5, 1.2)
plt.grid(visible=True)
plt.legend(fontsize='16', loc='upper right')
plt.tight_layout()
# saving the figure.
plt.savefig(save_path + '/prior1_avg_ASL_squaring_' + str(squaring_param) + '_N_'+ str(N_train) + '_' + regularizer + '_' + step + '_epoch_' + str(epoch_max) + '.png')
plt.show()



