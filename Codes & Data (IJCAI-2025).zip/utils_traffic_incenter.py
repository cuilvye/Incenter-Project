#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

import numpy as np
import gurobipy as gp

def check_Theta(Theta):
    """Check if Theta is valid."""
    if Theta not in [None, 'nonnegative']:
        raise Exception(
            'Invalid Theta. Accepted values are: None (default)'
            'and \'nonnegative\'.'
        )

def check_regularizer(regularizer):
    """Check if regularizer is valid."""
    if regularizer not in ['L2_squared', 'L1']:
        raise Exception(
            'Invalid regularizer. Accepted values are:'
            ' \'L2_squared\' (default) and \'L1\'.'
        )

def check_reg_parameter(reg_param):
    """Check if reg_param is valid."""
    if reg_param < 0:
        raise Exception('reg_param must be nonnegative.')


def warning_theta_hat_reg_param(theta_hat, reg_param):
    """Warn user theta_hat is not used when reg_param=0."""
    if (theta_hat is not None) and (reg_param == 0):
        warnings.warn('theta_hat is not used when reg_param=0.')

def phi_func_traffic(np_capacity, x_j):

    # feas_1 = np.ones(len(x_j))#
    feas_2 = []
    for i in range(len(x_j)):
        capacity_i = np_capacity[i]
        x_i = x_j[i]
        val_i = (x_i / capacity_i) ** 4
        feas_2.append([1, val_i])

    phi_j = np.array(feas_2).flatten()

    return phi_j
    
def FOP_game_Traffic(np_capacity, n_arcs, pmax, pmin, theta, x_hat_j, squaring_param, gurobi_params=None):

    # n_player = 2
    each_theta_len = int(len(theta)/n_arcs)
    assert each_theta_len == 2
    # n = n_player

    mdl = gp.Model('FOP-Game-Traffic')
    mdl.setParam('OutputFlag', 0) ### should see the method

    x = mdl.addVars(n_arcs, vtype=gp.GRB.CONTINUOUS, name='x')

    phi_j = phi_func_traffic(np_capacity, x_hat_j)
    assert phi_j.shape[0] == (each_theta_len * n_arcs)

    theta_reshape = theta.reshape(each_theta_len, -1) #each_theta_len * n_Arc
    assert theta_reshape.shape[0] == each_theta_len
    phi_j_reshape = phi_j.reshape(each_theta_len, -1)#each_theta_len * n_Arc
    assert phi_j_reshape.shape[0] == each_theta_len

    res_1_phi = []
    for i in range(n_arcs):
        res_1_phi.append(np.inner(theta_reshape[:, i], phi_j_reshape[:, i]))

    res_2_phi = []
    for i in range(n_arcs):
        # print(i)
        res_2_phi.append(np.inner(phi_j_reshape[:, i], phi_j_reshape[:, i]))# np.linalg.norm(phi_j_reshape[:, i]
        # print(res_2_phi)
    # print(affff)
    objective_1 = gp.quicksum(res_1_phi[i] * (x[i] - x_hat_j[i]) for i in range(n_arcs))
    objective_2 = gp.quicksum(res_2_phi[i] * (x[i] - x_hat_j[i]) * (x[i] - x_hat_j[i]) for i in range(n_arcs))
    # objective_2_approxi = gp.quicksum((2 * res_2_phi[i] * x_hat_j[i] - 1) * x[i] for i in range(n_player))

    ##### be very careful with the objective for different applications #####
    mdl.setObjective(-objective_1 + squaring_param * objective_2, gp.GRB.MAXIMIZE) # be very careful with this!!

    mdl.addConstrs(x[i] >= pmin for i in range(n_arcs)) ### the constraints to equilibrium prices
    mdl.addConstrs(x[i] <= pmax for i in range(n_arcs))

    if gurobi_params is not None:
        for param, value in gurobi_params:
            mdl.setParam(param, value)

    # mdl.setParam(gp.GRB.Param.InfUnbdInfo, 1)
    mdl.optimize()
    # print(mdl.get('GRB_IntAttr_Status'))
    # print("status", mdl.Status)
    if mdl.status == 4:
        print("The model is infeasible or Unbounded; computing IIS")
        mdl.computeIIS() #Cannot compute IIS on a feasible model
        mdl.write("model.ilp")
        # print("IIS written to 'model.ilp'")
        # print("The model is unbounded.")
        print(mdl.getParamInfo(gp.GRB.Param.InfUnbdInfo))
        unbd_ray = mdl.getAttr("UnbdRay", x)
        print("Unbounded ray direction for x^j:", unbd_ray)

    # print(mdl.status)
    # print(afffff)
    if mdl.status == 2:
        x_opt = np.array([x[k].X for k in range(n_arcs)])
        # print(x_opt)
    elif mdl.status == 9:
        # Time limit reched. Return vector a all ones
        x_opt = np.ones(n_arcs)
        assert 1 == 0
    else:
        raise Exception(
            f'Optimal solution not found. Gurobi status code = {mdl.status}.'
        )
    # print(x_opt)
    # help(mdl)
    # print(x_opt)
    # print(mdl.getParamInfo('Method'))
    # #('Method', <class 'int'>, -1, -1, 5, -1) FOR QP, the default method is Method = 2 (barrier)
    # print(afffffff)
    return x_opt


def ASL_traffic(
    np_capacity,
    theta,
    dataset,
    n_arcs,
    pmax,
    pmin,
    regularizer='L2_squared',
    reg_param=0,
    squaring_param = 1,
    theta_hat=None,
    ):
    # Check if the inputs are valid
    check_regularizer(regularizer)
    check_reg_parameter(reg_param)

    if theta_hat is None:
        theta_hat = 0

    if regularizer == 'L2_squared':
        reg_term = (reg_param/2)*np.linalg.norm(theta - theta_hat)**2
    elif regularizer == 'L1':
        reg_term = reg_param*np.linalg.norm(theta - theta_hat, 1)

    N = len(dataset)
    loss = 0

    for i in range(N):
        # Check if the FOP is augmented

        x_hat = dataset[i]

        # solve a approximate solution to the original Incenter-loss-term
        x_opt = FOP_game_Traffic(np_capacity, n_arcs, pmax, pmin, theta, x_hat, squaring_param)

        phi_j = phi_func_traffic(np_capacity, x_hat)
        # n_player = 2
        each_theta_len = int(len(theta) / n_arcs)
        I_n = np.ones(each_theta_len)
        temp_m = np.kron(I_n, (x_opt - x_hat))
        loss_Euclidean = np.linalg.norm(phi_j * temp_m.reshape(-1, order='F'))# * means element-size multiplication
        # loss_Euclidean_squaring = loss_Euclidean ** 2

        theta_reshape = theta.reshape(each_theta_len, -1)  # each_theta_len * n_Player
        assert theta_reshape.shape[0] == each_theta_len
        phi_j_reshape = phi_j.reshape(each_theta_len, -1)  # each_theta_len * n_Player
        assert phi_j_reshape.shape[0] == each_theta_len
        res_1_phi = []
        for i in range(n_arcs):
            res_1_phi.append(np.inner(theta_reshape[:, i], phi_j_reshape[:, i]))
        loss_linear = np.inner(res_1_phi, (x_opt - x_hat))

        loss = loss + loss_Euclidean - loss_linear
        # loss = loss + loss_Euclidean_squaring * squaring_param + loss_linear

    return reg_term + (1/N)*loss
