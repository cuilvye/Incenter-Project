#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Lvye, Cui

"""

######## The Baseline is not tractable because of the huge global action space #######

import pandas as pd
import numpy as np
import gurobipy as gp
import os, sys
import time
from gurobipy import GRB, quicksum
from scipy.optimize import fsolve
import argparse
import itertools
import pickle
import networkx as nx

from utils_traffic import generate_arcs_from_network
from utils_traffic import add_costs_flows_to_dict_arcs
from utils_traffic import frank_wolfe_outOf_sample


def utility_inference_func_feasibility_traffic(df_train,  n_theta, verbose):
    # Compute the absolute difference between each element in the third column and the median
    N_arc = df_train.shape[1]
    p1_actions = np.linspace(0, 1, num=30).tolist()
    p2_actions = np.linspace(0, 1, num=30).tolist()
    p3_actions = np.linspace(0, 1, num=30).tolist()

    candidate_actions = list(itertools.product(p1_actions, p2_actions, p3_actions))

    # the total number of variables

    # Initialize Gurobi model
    mdl = gp.Model()
    if not verbose:
        mdl.setParam('OutputFlag', 0)

    theta = mdl.addVars(n_theta, lb=-gp.GRB.INFINITY, vtype=gp.GRB.CONTINUOUS)

    # if Theta == 'nonnegative':
    #     mdl.addConstrs(theta[i] >= 0 for i in range(p))

    ## \theta_{i} should be >= 0
    # mdl.addConstrs(theta[i] >= 0.0001 for i in range(n_theta))
    mdl.addConstr(theta[0] >= 0.0001)


    ### Need to escape the case that thetas is equal to zeros!!!!!!!!!
    # Add constraints
    start_time = time.time()
    for j in range(df_train.shape[0]):
        qstar_j = df_train[j, :-1]
        xi_hat_j = df_train[j, -1]
        q1_hat_j, q2_hat_j, q3_hat_j =qstar_j[0], qstar_j[1], qstar_j[2]
        for k in range(len(candidate_actions)):
            x = candidate_actions[k]

            ## each constraint  ##
            phi_j, _, _, _ = phi_func_traffic((q1_hat_j, q2_hat_j, q3_hat_j), xi_hat_j)
            temp_m = np.kron(np.ones(n_theta), (x - qstar_j))
            ma = temp_m.reshape(-1, order='F')  # The order='F' parameter ensures that the matrix is flattened in column-major (Fortran-style) order, meaning it concatenates column by column.

            assert len(phi_j) == len(ma)
            res_temp = phi_j * ma  # * means: element-wise multiplication

            mdl.addConstr(gp.quicksum(theta[i] * res_temp[i] for i in range(n_theta)) <= 0)

    mdl.setObjective(0, gp.GRB.MINIMIZE)
    mdl.optimize()

    print('time spend is {} minutes'.format((time.time() - start_time) / 60))
    print('model status is {}'.format(mdl.Status))
    if mdl.status == 4:
        mdl.computeIIS()
        mdl.write("model.ilp")

        # Print out the IIS constraints and variables#
        print('\nThe following constraints and variables are in the IIS:')
        for c in mdl.getConstrs():
            if c.IISConstr: print(f'\t{c.constrname}: {mdl.getRow(c)} {c.Sense} {c.RHS}')

        for v in mdl.getVars():
            if v.IISLB: print(f'\t{v.varname} ≥ {v.LB}')
            if v.IISUB: print(f'\t{v.varname} ≤ {v.UB}')

    status = mdl.Status
    if status == gp.GRB.UNBOUNDED:
        print('The model cannot be solved because it is unbounded')
        # sys.exit(0)
    if status == gp.GRB.OPTIMAL:
        print('The optimal objective is %g' % mdl.ObjVal)
        theta_opt = np.array([theta[i].X for i in range(n_theta)])
        print('The optimal solution is:')
        print(theta_opt)
        # sys.exit(0)
    # if status != gp.GRB.INF_OR_UNBD and status != gp.GRB.INFEASIBLE:
    #     print('Optimization was stopped with status %d' % status)
    #     sys.exit(0)

    # Relax the bounds and try to make the model feasible
    print('The model is infeasible; relaxing the bounds')
    orignumvars = mdl.NumVars
    # relaxing only variable bounds #m.feasRelaxS(0, False, True, False)
    mdl.feasRelaxS(0, False, True, False)
    # for relaxing variable bounds and constraint bounds use
    # m.feasRelaxS(0, False, True, True)
    mdl.optimize()

    status = mdl.Status
    if status in (gp.GRB.INF_OR_UNBD, gp.GRB.INFEASIBLE, gp.GRB.UNBOUNDED):
        print('The relaxed model cannot be solved \
                because it is infeasible or unbounded')
        sys.exit(1)
    if status != gp.GRB.OPTIMAL:
        print('Optimization was stopped with status %d' % status)
        sys.exit(1)

    # print the values of the artificial variables of the relaxation
    print('\nSlack values:')
    slacks = mdl.getVars()[orignumvars:]
    for sv in slacks:
        if sv.X > 1e-9:
            print('%s = %g' % (sv.VarName, sv.X))

    theta_opt = np.array([theta[i].X for i in range(n_theta)])

    if mdl.status != 2:
        print(
            f'Optimal solution not found. Gurobi status code = {mdl.status}.'
            'Set the flag verbose=True for more details. Note: the IO'
            'optimization problem will always be infeasible if the data is not'
            'consistent.'
        )

    return theta_opt


# Example usage
args_parser = argparse.ArgumentParser()
args_parser.add_argument('--file_root', default = './data/', help = 'the root of data', type = str)
args_parser.add_argument('--N', default = 500, help = 'the number of training dataset', type = int)
args = args_parser.parse_args()

file_path = args.file_root
N_train = args.N

save_path = './results/traffic/aaai_Baseline1/'
if not os.path.exists(save_path):
    os.makedirs(save_path)

# seeds_theta_estimated = []
seeds_theta_estimated_normed = []
seeds_err_normed = []
seeds_equilibrium = []

Theta_true_file = pd.read_csv(os.path.join(file_path, "thetas-true-N-" + str(N_train) + ".csv"))
theta_true = np.array(Theta_true_file[['theta_0', 'theta_1']])
Theta_true = theta_true.flatten()  # a=matrix([[1, 2],[3, 4]]), a.flatten() = matrix([[1, 2, 3, 4]])
np_capacities = np.array(Theta_true_file['capacity'])

Theta_true_normed = Theta_true / np.linalg.norm(Theta_true)

dataset_train_df = pd.read_csv(file_path + "dataset_train_Flow_N_"+str(N_train)+".csv", header = 0)
dataset_train = np.array(dataset_train_df)
dataset_test_df = pd.read_csv(file_path + "dataset_test_Flow_N_" + str(N_train) + ".csv", header=0)
dataset_test = np.array(dataset_test_df)

with open(file_path + 'dataset_test_demands_N_'+ str(N_train) +'.pkl', 'rb') as f:
    demand_data = pickle.load(f)
file_path = "./SiouxFalls/"
file_net = file_path + "SiouxFalls_net.tntp"
dict_arcs = generate_arcs_from_network(file_net)
################################### Read in the true costs ##################################
file_flow = file_path + "SiouxFalls_flow.tntp"
dict_arcs, tot_cost, test_cost = add_costs_flows_to_dict_arcs(dict_arcs, file_flow)
for key, arc in dict_arcs.items():
    print(key, arc)
print('computed cost using cost function is :', tot_cost)
print('the actual cost is:', test_cost)
############################################################# Generate the simulated data #############################################################
# Create a directed graph
G = nx.DiGraph()

for idx, arc in enumerate(dict_arcs.values()):
    arc.obsflow = arc.trueflow
    G.add_edge(arc.start_node, arc.end_node, index=idx)

for seed in range(10):
    print('Seed {}'.format(seed))

    ######## start to estimate thetas ########
    Theta_estimated = utility_inference_func_feasibility_traffic(dataset_train_df, len(Theta_true_normed), 0)

    # error = np.linalg.norm(np.array(Theta_true_normed) - np.array(Theta_estimated))
    # # Estimated Theta is  [0.0, 0.6805791473995495, 0.0, 2.48023119594616, 1.3519388303126407, 0.0, 0.0, 0.0]
    # print('True theas is ', Theta_true_normed)
    # print('Estimated error is {}'.format(error)) #Estimated error is 2.9614639158104348

    Theta_estimated_normed = Theta_estimated / np.linalg.norm(Theta_estimated)
    error_normed = np.linalg.norm(np.array(Theta_true_normed) - np.array(Theta_estimated_normed))
    print('Estimated error (all normalize to l2-norm) is {}'.format(error_normed)) #Estimated error (all normalize to l2-norm) is 1.0710639067698995

    seeds_theta_estimated_normed.append(Theta_estimated_normed)
    seeds_err_normed.append(error_normed)

    # ######## to evaluate the \| x_esti - x_true \|_{2} on out-of samples, i.e., testing dataset #######
    difference_set_test = []
    v_arcs_i = []
    for idx, arc in enumerate(dict_arcs.values()):
        arc.thetas_estimated = (Theta_estimated_normed[2 * idx], Theta_estimated_normed[2 * idx + 1])
        v_arcs_i.append(arc)

    dataset_test = np.array(dataset_test_df)
    for j in range(dataset_test.shape[0]):
        x_hat = dataset_test[j]
        #### the reason that why there is a line is because when we compute the equilibrium, we did not use the theta_t ####
        conv_tol, flow_solution = frank_wolfe_outOf_sample(G, v_arcs_i, demand_data, j)

        p_solution = flow_solution

        difference_j = np.linalg.norm(p_solution - x_hat)
        difference_set_test.append(difference_j)

    # print(difference_set_test)
    # print(np.mean(difference_set_test))
    # print(difference_set_test_approx)
    # print(np.mean(difference_set_test_approx))
    seeds_equilibrium.append(np.mean(difference_set_test))
    # seeds_equilibrium_approx.append(np.mean(difference_set_test_approx))

#### save the results
result_dict = {
               'l2-norm-error-set': seeds_err_normed,
               'l2-norm-error-mean': np.mean(seeds_err_normed),
               'l2-norm-error-std': np.std(seeds_err_normed),
               'error-equilibrium': seeds_equilibrium,
               'error-equilibrium-mean': np.mean(seeds_equilibrium),
               'error-equilibrium-std': np.std(seeds_equilibrium),
               # str(epsilon) +'-equilibrium-approx-mean': np.mean(seeds_equilibrium_approx),
               # str(epsilon) +'-equilibrium-approx-std': np.std(seeds_equilibrium_approx),
               }

with open(save_path + 'Feasibility_N_'+str(N_train)+'.txt', 'w') as f:
    print(result_dict, file = f)
    print(result_dict)

